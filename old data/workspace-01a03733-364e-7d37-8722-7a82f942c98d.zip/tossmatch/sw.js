const CACHE = "tossmatch-demo-1";
const CORE = ["./index.html","./admin.html","./css/app.css","./js/data.js","./js/core.js","./js/engine.js","./js/player.js","./js/admin.js","./img/logo.jpg","./img/coin-heads.jpg","./img/coin-tails.jpg"];
self.addEventListener("install", e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(CORE)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", e => e.waitUntil(self.clients.claim()));
self.addEventListener("fetch", e => {
  e.respondWith(caches.match(e.request).then(r => r || fetch(e.request)));
});
