window.TM = window.TM || {};
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

const NAV = [
  { g: "Command", items: [
    ["dash", "Overview"],
    ["ops", "Live Operations"],
    ["topups", "Top-ups"],
    ["withdraw", "Withdrawals"],
    ["people", "Players"]
  ]},
  { g: "Commercial", items: [
    ["rates", "Rates & Jackpot"],
    ["econ", "Economy"],
    ["promo", "Promotions"]
  ]},
  { g: "Engagement", items: [
    ["features", "Feature Hub"],
    ["dir", "Directory"],
    ["vip", "VIP & Levels"],
    ["trny", "Tournaments"]
  ]},
  { g: "Governance", items: [
    ["audit", "Audit & Data"],
    ["trust", "Trust Center"]
  ]}
];

let tab = "dash";
let page = {};
let filters = { dirQ: "", dirCat: "all", dirSt: "all", tuKind: "all", peopleQ: "", qGame: "all" };

TM.refresh = () => draw();

function go(t) {
  tab = t;
  page[t] = 0;
  location.hash = t;
  draw();
}

function pager(key, arr, n = 20) {
  const max = Math.max(0, Math.ceil(arr.length / n) - 1);
  const p = TM.clamp(page[key] || 0, 0, max);
  page[key] = p;
  const slice = arr.slice(p * n, p * n + n);
  const nav = arr.length > n ? `<div class="btn-row" style="margin-top:8px">
    <button class="btn" data-pg="${key}" data-d="-1">Prev</button>
    <span class="disclaimer">Page ${p + 1} / ${max + 1} · ${arr.length} rows</span>
    <button class="btn" data-pg="${key}" data-d="1">Next</button></div>` : "";
  return { slice, nav, p, max };
}

function kpi(l, v, s = "", cls = "") {
  return `<div class="card kpi ${cls}"><div class="lbl">${l}</div><div class="val">${v}</div><div class="sub">${s}</div></div>`;
}
function num(id, label, val, hint = "") {
  return `<div class="field"><span>${label}${hint ? ` · ${hint}` : ""}</span><input id="${id}" type="number" step="any" value="${val}"></div>`;
}
function spark(values, color = "var(--gold)") {
  if (!values.length) return `<div class="disclaimer">No samples yet.</div>`;
  const max = Math.max(...values, 1);
  return `<div class="spark">${values.map(v => `<i style="height:${Math.max(6, (v / max) * 64)}px;background:${color}"></i>`).join("")}</div>`;
}
function alerts() {
  const s = TM.S, m = TM.metrics(), out = [];
  if (s.config.maintenance) out.push(["rose", "Maintenance is on — new player bets are blocked."]);
  if (s.settings.rg.excludePerm) out.push(["rose", "Player self-exclusion is permanent. Admin cannot undo it."]);
  else if (s.settings.rg.excludeUntil > Date.now()) out.push(["rose", "Player self-exclusion is active."]);
  if (s.settings.turbo >= 100) out.push(["gold", "Turbo " + s.settings.turbo + "× is running. Use only for short stress tests."]);
  if (!s.jackpot.armed) out.push(["gold", "Jackpot is filling. Arms at " + s.config.jpArm + "."]);
  if (m.botLow > 12) out.push(["gold", m.botLow + " bots sit below the top-up trigger."]);
  if (m.ratio > 1.2) out.push(["rose", "Sink/tap ratio is hot (" + m.ratio.toFixed(2) + ")."]);
  if (!out.length) out.push(["mint", "Desk is quiet. Economy " + m.health.toLowerCase() + "."]);
  return out.map(([k, t]) => `<div class="banner ${k === "gold" ? "" : k}">${t}</div>`).join("");
}

function draw() {
  TM.applyTheme();
  const s = TM.S;
  const m = TM.metrics();
  if ($("#clock")) $("#clock").textContent = new Date().toLocaleString();
  if ($("#navSearch") && !$("#navSearch")._bound) {
    $("#navSearch")._bound = true;
    $("#navSearch").addEventListener("input", draw);
  }
  if ($("#chipHouse")) $("#chipHouse b").textContent = TM.fmt(m.houseNet);
  if ($("#chipTop")) $("#chipTop b").textContent = TM.fmt(m.tu.bot.total);
  if ($("#chipQ")) $("#chipQ b").textContent = String(s.waiting.length);
  const q = ($("#navSearch")?.value || "").toLowerCase();
  $("#nav").innerHTML = NAV.map(g => {
    const items = g.items.filter(([, n]) => !q || n.toLowerCase().includes(q) || g.g.toLowerCase().includes(q));
    if (!items.length) return "";
    return `<div class="nav-label">${g.g}</div>` + items.map(([id, n]) =>
      `<button class="nav-btn ${tab === id ? "active" : ""}" data-tab="${id}">${n}</button>`
    ).join("");
  }).join("");
  $("#mNav").innerHTML = NAV.flatMap(g => g.items).map(([id, n]) =>
    `<button class="btn ${tab === id ? "btn-gold" : "btn-ghost"}" data-tab="${id}">${n}</button>`
  ).join("");
  $("#view").innerHTML = (SCREENS[tab] || SCREENS.dash)();
  bind();
}

const SCREENS = {
  dash() {
    const s = TM.S, m = TM.metrics();
    const fees = (s.session.samples || []).map(x => x.fees || 0);
    const games = (s.session.samples || []).map(x => x.games || 0);
    return `<div class="view-head"><div><h2>Command Center</h2>
      <p>Local operations desk. Same play-coin ledger as the player app. Anyone on this origin can change it.</p></div>
      <div class="btn-row">
        <button class="btn ${s.config.maintenance ? "btn-rose" : ""}" id="maint">${s.config.maintenance ? "End maintenance" : "Start maintenance"}</button>
        <button class="btn" id="seedJp">Seed jackpot +50</button>
        <button class="btn" id="mkTr">Quick 8-seat</button>
        <button class="btn" id="topLow">Top up low bots</button>
        <button class="btn" id="exState">Export state</button>
      </div></div>
      ${alerts()}
      <div class="grid g4">
        ${kpi("House net", TM.fmt(m.houseNet), "gross " + TM.fmt(m.houseGross) + " · cost " + TM.fmt(m.houseCost), m.houseNet >= 0 ? "up" : "down")}
        ${kpi("Jackpot", TM.fmt(s.jackpot.pool), s.jackpot.armed ? "Armed · hits " + s.stats.jackpotHits : "Filling to " + s.config.jpArm)}
        ${kpi("Games completed", TM.fmt(s.stats.total), "Coin " + TM.fmt(s.stats.coin || 0) + " · Cat " + TM.fmt(s.stats.catalog || 0) + " · Arcade " + TM.fmt(s.stats.arcade || 0))}
        ${kpi("Live bots", s.bots.length, m.online + " appearing online · start bonus 1,000")}
      </div>
      <div class="grid g4" style="margin-top:14px">
        ${kpi("Coin Toss", TM.fmt(s.stats.coin || ((s.stats.heads||0)+(s.stats.tails||0))), s.stats.heads + "H / " + s.stats.tails + "T")}
        ${kpi("P2P Catalog", TM.fmt(s.stats.catalog || 0), "fees " + TM.fmt(s.house.catalogFees))}
        ${kpi("Arcade+", TM.fmt(s.stats.arcade || 0), "shop-path spend")}
        ${kpi("Cups / brackets", TM.fmt(s.stats.cups || 0) + " / " + TM.fmt(s.stats.trnys || 0))}
      </div>
      <div class="grid g4" style="margin-top:14px">
        ${kpi("Bot top-ups", TM.fmt(m.tu.bot.count), TM.fmt(m.tu.bot.total) + " coins created")}
        ${kpi("Bot top-up coins", TM.fmt(m.tu.bot.total), "base " + TM.fmt(m.tu.bot.base) + " · promo " + TM.fmt(m.tu.bot.bonus))}
        ${kpi("Player top-ups", TM.fmt(m.tu.player.count), TM.fmt(m.tu.player.amount) + " MAIN · bonus " + TM.fmt(m.tu.player.bonus))}
        ${kpi("Open queue", s.waiting.length, "Cups " + s.cups.filter(c => !c.b).length + " · events " + s.trnys.filter(t => t.status === "open").length)}
      </div>
      <div class="grid g4" style="margin-top:14px">
        ${kpi("Coin Toss fees", TM.fmt(s.house.fees))}
        ${kpi("Catalog fees", TM.fmt(s.house.catalogFees))}
        ${kpi("Cup + tournament rake", TM.fmt(s.house.cupRake + s.house.trnyRake))}
        ${kpi("Shop / transfer", TM.fmt(s.house.shop) + " / " + TM.fmt(s.house.transfers))}
      </div>
      <div class="grid g2" style="margin-top:14px">
        ${TM.gamesSheet()}
        ${TM.pnlSheet()}
      </div>
      <div class="grid g3" style="margin-top:14px">
        ${TM.playerTopupSheet()}
        ${TM.botTopupSheet()}
        ${TM.withdrawSheet()}
      </div>
      <div class="grid g2" style="margin-top:14px">
        <div class="card"><h3>House take over samples</h3>${spark(fees)}<p class="disclaimer">Local 5-second samples while a page is open.</p></div>
        <div class="card"><h3>Game count over samples</h3>${spark(games, "var(--teal)")}</div>
      </div>
      <div class="card" style="margin-top:14px"><h3>Live feed</h3>
        <div class="feed">${s.feed.slice(0, 14).map(f => `<div class="feed-item"><time>${TM.ago(f.t)}</time><span>${TM.esc(f.text)}</span></div>`).join("") || "<p class='disclaimer'>Waiting for activity.</p>"}</div>
      </div>
      <div class="card" style="margin-top:14px">
        <h3>Broadcast</h3>
        <div class="btn-row"><input id="bc" class="ctrl" maxlength="120" value="${TM.esc(s.config.broadcast)}" placeholder="120 characters across every player screen">
        <button class="btn btn-gold" id="bcGo">Push</button><button class="btn" id="bcClr">Clear</button></div>
      </div>`;
  },

  ops() {
    const s = TM.S, m = TM.metrics();
    let queue = s.waiting.slice();
    if (filters.qGame === "coin") queue = queue.filter(w => w.kind === "coin");
    else if (filters.qGame === "catalog") queue = queue.filter(w => w.kind === "catalog");
    const q = pager("q", queue);
    const xf = pager("xf", s.botTransfers);
    return `<div class="view-head"><div><h2>Live operations</h2><p>Maintenance, liquidity, the demo player, and the open P2P queue.</p></div></div>
      <div class="grid g4">
        ${kpi("Player MAIN", TM.fmt(s.wallet.main), "playable " + TM.fmt(TM.playable(s)))}
        ${kpi("Session net", TM.delta(s.session.net), s.player.games + " player games", s.session.net >= 0 ? "up" : "down")}
        ${kpi("Bot wealth", TM.fmt(m.botBal), "avg " + TM.fmt(m.botBal / Math.max(1, s.bots.length)))}
        ${kpi("Below trigger", m.botLow, "trigger " + s.config.botTopAt)}
      </div>
      <div class="card" style="margin-top:14px">
        <h3>Feature switches</h3>
        <div class="grid g3">
          <label class="disclaimer"><input type="checkbox" id="botsOn" ${s.config.botsOn ? "checked" : ""}> Autonomous bots</label>
          <label class="disclaimer"><input type="checkbox" id="growOn" ${s.config.growthOn ? "checked" : ""}> Roster growth</label>
          <label class="disclaimer"><input type="checkbox" id="autoOn" ${s.config.autoMatch ? "checked" : ""}> Auto-match queue</label>
          <label class="disclaimer"><input type="checkbox" id="questOn" ${s.config.questsOn ? "checked" : ""}> Quests</label>
          <label class="disclaimer"><input type="checkbox" id="loginOn" ${s.config.loginOn ? "checked" : ""}> Daily login</label>
          <label class="disclaimer"><input type="checkbox" id="maintOn" ${s.config.maintenance ? "checked" : ""}> Maintenance</label>
        </div>
        <div class="grid g3" style="margin-top:10px">
          ${num("topAt", "Bot top-up trigger", s.config.botTopAt, "0–10000")}
          ${num("growMax", "Max roster", s.config.growthMax, "99–1000")}
          ${num("mainShare", "MAIN share of each stake %", Math.round((s.config.mainShare || .85) * 100), "80–90")}
          ${num("wdMin", "Withdraw from MAIN", s.config.wdMin || 3000, "min trigger")}
          ${num("wdMax", "Withdraw up to MAIN", s.config.wdMax || 5000, "max trigger")}
        </div>
        <div class="btn-row" style="margin-top:10px">
          <button class="btn btn-gold" id="opsSave">Save operations</button>
          <button class="btn" id="topLow">Top up bots below trigger</button>
        </div>
      </div>
      <div class="card" style="margin-top:14px"><h3>Open P2P queue</h3>
        <div class="btn-row" style="margin-bottom:8px">
          ${[["all","All"],["coin","Coin Toss"],["catalog","Catalog"]].map(([id,n]) =>
            `<button class="btn ${filters.qGame===id?"btn-gold":""}" data-qf="${id}">${n}</button>`).join("")}
        </div>
        <div class="table-wrap"><table><tr><th>Game</th><th>Player</th><th>Pick</th><th>Stake</th><th>Wait</th></tr>
        ${q.slice.map(w => `<tr><td>${w.kind === "coin" ? "Coin Toss" : TM.esc(TM.catalogById(w.gameId)?.name || w.gameId)}</td>
          <td>${TM.esc(w.ownerName)}</td><td>${TM.esc(w.side || w.pick || "—")}</td><td>${TM.fmt(w.stake)}</td><td>${TM.ago(w.t)}</td></tr>`).join("") || "<tr><td colspan='5'>Empty queue.</td></tr>"}
        </table></div>${q.nav}
      </div>
      <div class="card" style="margin-top:14px"><h3>Bot transfers</h3>
        <div class="table-wrap"><table><tr><th>When</th><th>From</th><th>To</th><th>Amount</th><th>Fee</th></tr>
        ${xf.slice.map(x => `<tr><td>${TM.ago(x.t)}</td><td>${TM.esc(x.from)}</td><td>${TM.esc(x.to)}</td><td>${TM.fmt(x.amount)}</td><td>${TM.fmt(x.fee)}</td></tr>`).join("") || "<tr><td colspan='5'>None yet.</td></tr>"}
        </table></div>${xf.nav}
      </div>`;
  },

  topups() {
    const s = TM.S, tu = s.topups || TM.emptyTopups();
    let log = (tu.log || []).slice();
    if (filters.tuKind !== "all") log = log.filter(x => x.kind === filters.tuKind);
    const pg = pager("tu", log);
    const last20 = (tu.log || []).filter(x => x.kind === "bot").slice(0, 20).map(x => x.total).reverse();
    const botsWith = s.bots.filter(b => b.topups).sort((a, b) => (b.topupTotal || 0) - (a.topupTotal || 0)).slice(0, 8);
    return `<div class="view-head"><div><h2>Top-up desk</h2>
      <p>Bot top-ups are liquidity taps — never house revenue. First eligible bot top-up gets +50% when the promo is on.</p></div>
      <div class="btn-row">
        <button class="btn btn-gold" id="topLow">Top up low bots now</button>
        <button class="btn" id="exTop">Export CSV</button>
      </div></div>
      <div class="grid g2">
        ${TM.playerTopupSheet()}
        ${TM.botTopupSheet()}
      </div>
      <div class="grid g2" style="margin-top:14px">
        <div class="card"><h3>Recent bot top-up sizes</h3>${spark(last20, "var(--teal)")}</div>
        <div class="card"><h3>Heaviest bot recipients</h3>
          ${botsWith.map(b => `<div class="feed-item"><span>${b.glyph} ${TM.esc(b.name)}</span><span>${b.topups}× · ${TM.fmt(b.topupTotal || 0)}</span></div>`).join("") || "<p class='disclaimer'>No bot has been topped up yet. Leave the player app open or press the batch button.</p>"}
        </div>
      </div>
      <div class="card" style="margin-top:14px">
        <h3>Top-up ledger</h3>
        <div class="btn-row" style="margin-bottom:8px">
          ${[["all","All"],["bot","Bots"],["player","Player"]].map(([id,n]) =>
            `<button class="btn ${filters.tuKind===id?"btn-gold":""}" data-tuk="${id}">${n}</button>`).join("")}
        </div>
        <div class="table-wrap"><table>
          <tr><th>When</th><th>Who</th><th>Kind</th><th>Base</th><th>Bonus</th><th>Total</th><th>Reason</th><th>#</th></tr>
          ${pg.slice.map(x => `<tr>
            <td>${TM.ago(x.t)}</td><td>${TM.esc(x.name)}</td>
            <td><span class="pill ${x.kind === "bot" ? "live" : "split"}">${x.kind}</span></td>
            <td>${TM.fmt(x.base)}</td><td>${TM.fmt(x.bonus)}</td><td>${TM.fmt(x.total)}</td>
            <td>${TM.esc(x.reason)}</td><td>${x.count || "—"}</td>
          </tr>`).join("") || "<tr><td colspan='8'>No top-ups recorded yet.</td></tr>"}
        </table></div>${pg.nav}
      </div>`;
  },

  withdraw() {
    const s = TM.S;
    const w = s.withdrawals || { count: 0, amount: 0, log: [] };
    const log = (w.log || []).slice();
    const pg = pager("wd", log);
    const ripe = s.bots.filter(b => (b.bal || 0) >= (b.withdrawAt || s.config.wdMin || 3000));
    return `<div class="view-head"><div><h2>Bot withdrawals</h2>
      <p>When a bot’s MAIN hits its 3,000–5,000 trigger it files a cash-out. The amount leaves the bot and is deducted from house revenue.</p></div>
      <div class="btn-row">
        <button class="btn btn-gold" id="wdRun">Process eligible now</button>
        <button class="btn" id="exWd">Export CSV</button>
      </div></div>
      <div class="grid g2">
        ${TM.withdrawSheet()}
        ${TM.pnlSheet()}
      </div>
      <div class="grid g3" style="margin-top:14px">
        ${kpi("Paid requests", TM.fmt(w.count), TM.fmt(w.amount) + " taken from revenue")}
        ${kpi("Eligible now", ripe.length, "MAIN at or above personal trigger")}
        ${kpi("Trigger band", TM.fmt(s.config.wdMin || 3000) + "–" + TM.fmt(s.config.wdMax || 5000), "set in Live Operations")}
      </div>
      <div class="card" style="margin-top:14px">
        <h3>Withdrawal ledger</h3>
        <div class="table-wrap"><table>
          <tr><th>When</th><th>Bot</th><th>Amount</th><th>Kept MAIN</th><th>Status</th></tr>
          ${pg.slice.map(x => `<tr>
            <td>${TM.ago(x.t)}</td><td>${TM.esc(x.name)}</td>
            <td>${TM.fmt(x.amount)}</td><td>${TM.fmt(x.keep)}</td>
            <td><span class="pill win">${TM.esc(x.status || "paid")}</span></td>
          </tr>`).join("") || "<tr><td colspan='5'>No withdrawals yet. Bots cash out after MAIN reaches 3,000–5,000.</td></tr>"}
        </table></div>${pg.nav}
      </div>
      <div class="card" style="margin-top:14px">
        <h3>Closest to cash-out</h3>
        <div class="table-wrap"><table><tr><th>Bot</th><th>MAIN</th><th>Trigger</th><th>Gap</th></tr>
        ${s.bots.slice().sort((a,b)=> (b.bal||0)-(a.bal||0)).slice(0,12).map(b => `<tr>
          <td>${TM.esc(b.name)}</td><td>${TM.fmt(b.bal)}</td>
          <td>${TM.fmt(b.withdrawAt || s.config.wdMin || 3000)}</td>
          <td>${TM.fmt(Math.max(0, (b.withdrawAt || 3000) - (b.bal || 0)))}</td>
        </tr>`).join("")}
        </table></div>
      </div>`;
  },

  people() {
    const s = TM.S;
    const q = (filters.peopleQ || "").toLowerCase();
    const you = { name: s.player.name, you: true, bal: TM.playable(s), wins: s.player.wins, losses: s.player.losses, level: s.player.level, net: s.player.net, topups: s.topups?.player.count || 0, country: "YOU" };
    let rows = [you].concat(s.bots.map(b => ({ ...b, topups: b.topups || 0 })));
    if (q) rows = rows.filter(r => (r.name + (r.country || "") + (r.title || "")).toLowerCase().includes(q));
    const sort = filters.peopleSort || "bal";
    rows.sort((a, b) => (b[sort] || 0) - (a[sort] || 0));
    const pg = pager("pe", rows);
    return `<div class="view-head"><div><h2>Players</h2><p>Demo player plus the simulated roster. Bot count is not human MAU.</p></div></div>
      <div class="grid g4">
        ${kpi("Demo player", TM.fmt(TM.playable(s)), s.player.name + " · lv " + s.player.level)}
        ${kpi("Career net", TM.delta(s.player.net), TM.fmt(s.player.wagered) + " wagered", s.player.net >= 0 ? "up" : "down")}
        ${kpi("Roster", s.bots.length, s.bots.filter(b => b.online).length + " online")}
        ${kpi("Your referrals", s.player.referrals || 0, "new bots can join on your code")}
      </div>
      <div class="card" style="margin-top:14px">
        <div class="btn-row" style="margin-bottom:10px">
          <input class="ctrl" id="pq" placeholder="Search name or country" value="${TM.esc(filters.peopleQ)}" style="max-width:240px">
          ${[["bal","Balance"],["wins","Wins"],["net","Net"],["topups","Top-ups"],["level","Level"]].map(([id,n]) =>
            `<button class="btn ${sort===id?"btn-gold":""}" data-ps="${id}">${n}</button>`).join("")}
        </div>
        <div class="table-wrap"><table><tr><th>Name</th><th>Bal / playable</th><th>W–L</th><th>Net</th><th>Lv</th><th>Top-ups</th></tr>
        ${pg.slice.map(r => `<tr>
          <td>${TM.esc(r.name)}${r.you ? " · you" : " · " + (r.country || "")}</td>
          <td>${TM.fmt(r.bal)}</td><td>${r.wins}–${r.losses || 0}</td>
          <td>${TM.delta(r.net)}</td><td>${r.level}</td><td>${r.topups || 0}</td>
        </tr>`).join("")}
        </table></div>${pg.nav}
      </div>`;
  },

  features() {
    const s = TM.S;
    const byGame = {};
    (s.catalogLog || []).forEach(g => {
      const k = g.game;
      byGame[k] = byGame[k] || { n: 0, fee: 0, stake: 0 };
      byGame[k].n++; byGame[k].fee += g.fee || 0; byGame[k].stake += g.stake || 0;
    });
    const rows = Object.entries(byGame).sort((a, b) => b[1].n - a[1].n);
    return `<div class="view-head"><div><h2>Feature Hub</h2><p>Community, Arcade+, Progress+, Economy+ and catalog earnings.</p></div></div>
      <div class="grid g4">
        ${kpi("Catalog matches", s.player.catalogGames, "fees " + TM.fmt(s.house.catalogFees))}
        ${kpi("Arcade plays", s.player.arcadeGames)}
        ${kpi("Friends / rooms", (s.social.friends || []).length + " / " + (s.rooms || []).length, "chat " + s.player.chatSent)}
        ${kpi("Utilities", "tickets " + s.player.tickets, "crafts " + s.player.crafts + " · room " + s.player.roomTier)}
      </div>
      <div class="grid g4" style="margin-top:14px">
        ${kpi("Cups played", s.player.cupPlays, s.player.cupWins + " wins")}
        ${kpi("Tournaments", s.player.trnyPlays, s.player.trnyWins + " titles")}
        ${kpi("Clan treasury", TM.fmt(s.social.clan?.treasury || 0), s.social.clan ? s.social.clan.name : "no clan")}
        ${kpi("Carry pools", Object.values(s.carry).filter(Boolean).length, TM.fmt(Object.values(s.carry).reduce((a, b) => a + (b || 0), 0)) + " held")}
      </div>
      <div class="grid g2" style="margin-top:14px">
        <div class="card"><h3>Catalog earnings by title</h3>
          <div class="table-wrap"><table><tr><th>Game</th><th>Matches</th><th>Turnover</th><th>Fees</th></tr>
          ${rows.slice(0, 16).map(([id, r]) => `<tr><td>${TM.esc(TM.catalogById(id)?.name || id)}</td><td>${r.n}</td><td>${TM.fmt(r.stake * 2)}</td><td>${TM.fmt(r.fee)}</td></tr>`).join("") || "<tr><td colspan='4'>No catalog results yet.</td></tr>"}
          </table></div>
        </div>
        <div class="card"><h3>Open carry pools</h3>
          <table><tr><th>Game</th><th>Pool</th></tr>
          ${Object.entries(s.carry).filter(([, v]) => v).map(([k, v]) => `<tr><td>${TM.esc(TM.catalogById(k)?.name || k)}</td><td>${TM.fmt(v)}</td></tr>`).join("") || "<tr><td colspan='2'>None</td></tr>"}
          </table>
          <h3 style="margin-top:16px">Quick player links</h3>
          <div class="btn-row">
            <a class="btn" href="index.html#games">Catalog</a>
            <a class="btn" href="index.html#arcade">Arcade+</a>
            <a class="btn" href="index.html#community">Social</a>
            <a class="btn" href="index.html#econ">Economy+</a>
            <a class="btn" href="index.html#plus">Progress+</a>
          </div>
        </div>
      </div>`;
  },

  dir() {
    const cats = ["all", ...new Set(TM.DIRECTORY.map(d => d[0]))];
    const sts = ["all", "Implemented", "Partial", "Suggested"];
    let list = TM.DIRECTORY.slice();
    if (filters.dirCat !== "all") list = list.filter(d => d[0] === filters.dirCat);
    if (filters.dirSt !== "all") list = list.filter(d => d[3] === filters.dirSt);
    if (filters.dirQ) {
      const q = filters.dirQ.toLowerCase();
      list = list.filter(d => d.join(" ").toLowerCase().includes(q));
    }
    const counts = {
      Implemented: TM.DIRECTORY.filter(d => d[3] === "Implemented").length,
      Partial: TM.DIRECTORY.filter(d => d[3] === "Partial").length,
      Suggested: TM.DIRECTORY.filter(d => d[3] === "Suggested").length
    };
    return `<div class="view-head"><div><h2>Feature Directory</h2>
      <p>${TM.DIRECTORY.length} records · ${counts.Implemented} implemented · ${counts.Partial} partial · ${counts.Suggested} suggested.</p></div></div>
      <div class="card" style="margin-bottom:12px">
        <div class="grid g3">
          <input class="ctrl" id="dq" placeholder="Search code or name" value="${TM.esc(filters.dirQ)}">
          <select id="dc" class="ctrl">${cats.map(c => `<option ${filters.dirCat===c?"selected":""}>${c}</option>`).join("")}</select>
          <select id="ds" class="ctrl">${sts.map(c => `<option ${filters.dirSt===c?"selected":""}>${c}</option>`).join("")}</select>
        </div>
      </div>
      <div class="card table-wrap"><table><tr><th>Code</th><th>Feature</th><th>Status</th><th></th></tr>
      ${list.map(d => `<tr><td>${d[1]}</td><td><b>${TM.esc(d[2])}</b><div class="disclaimer">${d[0]} · ${TM.esc(d[4])}</div></td>
        <td><span class="pill ${d[3]==="Implemented"?"win":d[3]==="Suggested"?"carry":"split"}">${d[3]}</span></td>
        <td>${d[5] ? `<a class="btn" href="index.html#${d[5]}">Open</a>` : "—"}</td></tr>`).join("")}
      </table></div>`;
  },

  rates() {
    const c = TM.S.config, j = TM.S.jackpot;
    const pct = Math.min(100, Math.round(j.pool / Math.max(c.jpArm, 1) * 100));
    return `<div class="view-head"><div><h2>Rates & jackpot</h2><p>All values are local demo configuration. Ranges match the project rules.</p></div></div>
      <div class="card" style="margin-bottom:14px">
        <h3>Jackpot now · ${TM.fmt(j.pool)} ${j.armed ? "· ARMED" : ""}</h3>
        <div class="progress"><i style="width:${pct}%"></i></div>
        <p class="disclaimer">Funds from regular/catalog fees. Coin Toss byte 00 pays ${Math.round(c.jpPay * 100)}% when armed.</p>
      </div>
      <div class="card grid g3">
        ${num("fee", "Coin / catalog fee %", c.fee * 100, "0–25")}
        ${num("cupRake", "Cup rake %", c.cupRake * 100, "0–25")}
        ${num("trnyRake", "Tournament rake %", c.trnyRake * 100, "0–25")}
        ${num("xferFee", "Transfer fee %", c.xferFee * 100, "0–10")}
        ${num("jpFund", "Jackpot funding %", c.jpFund * 100, "0–50")}
        ${num("jpFloor", "Jackpot floor coins", c.jpFloor, "0–10")}
        ${num("jpArm", "Arm threshold", c.jpArm, "0–1000")}
        ${num("jpPay", "Payout %", c.jpPay * 100, "1–100")}
        ${num("nonMainCap", "Non-main stake cap %", c.nonMainCap * 100, "10–20")}
        ${num("xferMin", "Transfer minimum", c.xferMin)}
        ${num("xferCap", "Daily transfer cap", c.xferCap)}
      </div>
      <div class="btn-row" style="margin-top:12px">
        <button class="btn btn-gold" id="svRates">Save rates</button>
        <button class="btn" id="seedJp">Seed jackpot +50</button>
      </div>`;
  },

  econ() {
    const s = TM.S, m = TM.metrics();
    const simN = +(window._simN || 1000);
    const simStake = +(window._simStake || 50);
    const fee = Math.round(simN * simStake * 2 * s.config.fee);
    const jp = Math.round(fee * s.config.jpFund);
    return `<div class="view-head"><div><h2>Economy</h2><p>Taps create coins. Sinks remove them. Bot top-ups are liquidity, never deposit revenue.</p></div></div>
      <div class="grid g4">
        ${kpi("Taps", TM.fmt(s.taps), "created play coins")}
        ${kpi("Sinks", TM.fmt(s.sinks), "removed play coins")}
        ${kpi("Sink / tap", m.ratio.toFixed(2), m.health)}
        ${kpi("Net house", TM.fmt(m.houseNet), "cannot comp above this")}
      </div>
      <div class="grid g2" style="margin-top:14px">
        <div class="card">
          <h3>Revenue simulator</h3>
          <p class="disclaimer">What-if only. Does not change the ledger.</p>
          <div class="grid g2">
            <div class="field"><span>Hypothetical matches</span><input id="simN" type="number" value="${simN}"></div>
            <div class="field"><span>Average stake</span><input id="simStake" type="number" value="${simStake}"></div>
          </div>
          <p style="margin-top:10px">Projected fee ${TM.fmt(fee)} · jackpot share ${TM.fmt(jp)} · house ${TM.fmt(fee - jp)}</p>
          <button class="btn" id="simGo">Recalculate</button>
        </div>
        <div class="card">
          <h3>Revenue-funded comp</h3>
          <p class="disclaimer">Credits player BONUS. Cannot exceed available net house.</p>
          <div class="btn-row"><input id="compN" type="number" value="50" class="ctrl" style="max-width:120px">
          <button class="btn" id="compGo">Credit BONUS</button></div>
          <p class="disclaimer" style="margin-top:10px">Available ${TM.fmt(m.houseNet)}</p>
        </div>
      </div>
      <div class="card" style="margin-top:14px"><h3>Accounting map</h3>
        <table><tr><th>Flow</th><th>Treatment</th></tr>
          <tr><td>Coin / catalog fee</td><td>House + jackpot share · sink</td></tr>
          <tr><td>Cup / tournament rake</td><td>House rake · sink</td></tr>
          <tr><td>Shop, crates, tickets, room upgrades</td><td>House shop · sink</td></tr>
          <tr><td>Clan treasury</td><td>Sink only · not house revenue</td></tr>
          <tr><td>Bot top-ups</td><td>Tap · never deposit revenue</td></tr>
          <tr><td>Player top-up</td><td>Tap · MAIN (+ BONUS if first promo)</td></tr>
        </table>
      </div>`;
  },

  promo() {
    const s = TM.S;
    s.campaigns = s.campaigns || [];
    return `<div class="view-head"><div><h2>Promotions</h2><p>First top-up is the only paid path. Campaigns store metadata and can credit the player once.</p></div></div>
      <div class="grid g3">
        ${kpi("First top-up", s.config.firstTopup ? "Live" : "Paused", s.player.claimedFirstTopup ? "Player already claimed" : "Player still eligible")}
        ${kpi("Player promo BONUS", TM.fmt(s.topups?.player.bonus || 0))}
        ${kpi("Bot first-promo cost", TM.fmt(s.topups?.bot.bonus || 0), "same toggle")}
      </div>
      <div class="card" style="margin-top:14px">
        <label><input type="checkbox" id="ft" ${s.config.firstTopup ? "checked" : ""}> First top-up promo enabled for player and first bot top-up</label>
        <div class="field" style="margin-top:12px;max-width:220px">
          <span>Promo percent</span>
          <input id="ftPct" type="number" min="0" max="200" step="1" value="${s.config.firstTopupPct || 50}">
        </div>
        <p class="disclaimer">Current offer: +${s.config.firstTopupPct || 50}% BONUS on the first eligible top-up.</p>
        <button class="btn" style="margin-top:8px" id="svPromo">Save promo %</button>
      </div>
      <div class="card" style="margin-top:14px">
        <h3>Campaigns</h3>
        <div class="grid g3">
          <div class="field"><span>Name</span><input id="cn" placeholder="Weekend drop"></div>
          <div class="field"><span>Type</span><select id="ct"><option>deposit bonus</option><option>flat credit</option><option>cash drop</option></select></div>
          <div class="field"><span>Credit amount</span><input id="ca" type="number" value="100"></div>
        </div>
        <button class="btn" style="margin-top:10px" id="cAdd">Create campaign</button>
        ${(s.campaigns).map((c, i) => `<div class="banner" style="margin-top:8px">${TM.esc(c.name)} · ${TM.esc(c.type)} · ${c.amount || 0} · ${c.on ? "live" : "paused"} · claims ${c.claims || 0}
          <button class="btn" data-ctog="${i}">Toggle</button>
          <button class="btn" data-cclaim="${i}">Credit player once</button>
          <button class="btn" data-cdel="${i}">Delete</button></div>`).join("")}
      </div>
      <div class="card" style="margin-top:14px">
        <h3>Broadcast</h3>
        <div class="btn-row"><input id="bc" class="ctrl" maxlength="120" value="${TM.esc(s.config.broadcast)}">
        <button class="btn btn-gold" id="bcGo">Push</button><button class="btn" id="bcClr">Clear</button></div>
      </div>`;
  },

  vip() {
    const s = TM.S;
    const rows = s.config.vip;
    const lv = Object.entries(s.config.levelRewards || TM.LEVEL_REWARD);
    const q = (filters.lvQ || "").toLowerCase();
    const filtered = q ? lv.filter(([k]) => k.includes(q)) : lv;
    const pg = pager("lv", filtered);
    return `<div class="view-head"><div><h2>VIP & levels</h2>
      <p>Eight monthly tiers. Player is ${TM.vip(s).name} on ${TM.fmt(s.player.monthWagered)} wagered this UTC month.</p></div>
      <button class="btn" id="endMonth">End VIP month</button></div>
      <div class="grid g3">
        ${kpi("Current tier", TM.vip(s).name, TM.fmt(s.player.monthWagered) + " wagered")}
        ${kpi("Pending rakeback", TM.fmt(s.player.pendingRake))}
        ${kpi("Player level", s.player.level, TM.fmt(s.player.xp) + " XP")}
      </div>
      <div class="card table-wrap" style="margin-top:14px"><table><tr><th>Tier</th><th>Monthly wager</th><th>Rakeback %</th><th>Shop %</th></tr>
      ${rows.map((t, i) => `<tr>
        <td>${t.name}</td>
        <td><input data-vw="${i}" type="number" value="${t.wager}" class="ctrl"></td>
        <td><input data-vr="${i}" type="number" value="${t.rake}" class="ctrl"></td>
        <td>${t.shop}</td></tr>`).join("")}
      </table>
      <button class="btn" style="margin-top:8px" id="svVip">Save VIP table</button></div>
      <div class="card" style="margin-top:14px"><h3>Level rewards · ${lv.length} rows</h3>
        <input class="ctrl" id="lvQ" placeholder="Filter level" value="${TM.esc(filters.lvQ || "")}" style="max-width:200px;margin-bottom:8px">
        <table>${pg.slice.map(([lv, r]) => `<tr><td>Level ${lv}</td><td><input class="ctrl" data-lr="${lv}" value="${r}" style="max-width:120px"></td><td>BONUS</td></tr>`).join("")}</table>
        ${pg.nav}
        <button class="btn" style="margin-top:8px" id="svLv">Save visible rewards</button>
      </div>`;
  },

  trny() {
    const s = TM.S;
    const pg = pager("tr", s.trnys);
    return `<div class="view-head"><div><h2>Tournaments</h2><p>Bots fill all but one seat, then close the public window after ~4.5s. Champion 75% / runner-up 25% after rake.</p></div>
      <div class="btn-row">
        <select id="ts"><option>4</option><option selected>8</option><option>16</option></select>
        <select id="tf"><option value="single">Single flip</option><option value="Bo3">Bo3</option></select>
        <input id="te" type="number" value="100" class="ctrl" style="max-width:100px">
        <button class="btn btn-gold" id="tMake">Create</button>
      </div></div>
      <div class="grid g3">
        ${kpi("Open", s.trnys.filter(t => t.status === "open").length)}
        ${kpi("Live / done", s.trnys.filter(t => t.status !== "open").length)}
        ${kpi("Tournament rake", TM.fmt(s.house.trnyRake))}
      </div>
      <div class="card" style="margin-top:14px"><table><tr><th>When</th><th>Size</th><th>Entry</th><th>Seats</th><th>Status</th><th>Champ</th><th>Runner</th></tr>
      ${pg.slice.map(t => `<tr><td>${TM.ago(t.t)}</td><td>${t.size} ${t.format}</td><td>${t.entry}</td>
        <td>${t.seats.length}/${t.size}</td><td>${t.status}</td>
        <td>${TM.esc(t.champ?.name || "—")}</td><td>${TM.esc(t.runner?.name || "—")}</td></tr>`).join("") || "<tr><td colspan='7'>None yet.</td></tr>"}
      </table>${pg.nav}</div>`;
  },

  audit() {
    const s = TM.S;
    const a = pager("au", s.audit);
    const g = pager("cg", s.catalogLog);
    const gm = pager("gm", s.games);
    return `<div class="view-head"><div><h2>Audit & data</h2><p>Mutable local trail. Not tamper-evident.</p></div>
      <div class="btn-row">
        <button class="btn" id="exLed">Ledger CSV</button>
        <button class="btn" id="exGames">Games JSON</button>
        <button class="btn" id="exTop">Top-ups CSV</button>
        <button class="btn" id="exAll">Full state</button>
        <button class="btn btn-rose" id="wipe">Reset demo</button>
      </div></div>
      <div class="grid g3">
        ${kpi("Audit rows", s.audit.length, "cap 50")}
        ${kpi("Review flags", (s.reviews || []).length, "jackpots & 400+ payouts")}
        ${kpi("Catalog log", s.catalogLog.length)}
      </div>
      <div class="card" style="margin-top:14px"><h3>Audit trail</h3>
        ${a.slice.map(x => `<div class="feed-item"><time>${TM.ago(x.t)}</time><span>${TM.esc(x.text)}</span></div>`).join("") || "<p class='disclaimer'>Empty.</p>"}${a.nav}
      </div>
      <div class="card" style="margin-top:14px"><h3>Catalog results</h3>
        <table><tr><th>When</th><th>Game</th><th>Result</th><th>Δ</th><th>Detail</th></tr>
        ${g.slice.map(x => `<tr><td>${TM.ago(x.t)}</td><td>${x.game}</td><td>${x.result}</td><td>${x.delta}</td><td>${TM.esc(x.detail || "")}</td></tr>`).join("")}
        </table>${g.nav}
      </div>
      <div class="card" style="margin-top:14px"><h3>Player games</h3>
        <table><tr><th>When</th><th>Kind</th><th>Game</th><th>Stake</th><th>Result</th><th>Δ</th></tr>
        ${gm.slice.map(x => `<tr><td>${TM.ago(x.t)}</td><td>${x.kind}</td><td>${TM.esc(x.game)}</td><td>${x.stake}</td><td>${x.result}</td><td>${x.delta}</td></tr>`).join("")}
        </table>${gm.nav}
      </div>
      <div class="card" style="margin-top:14px"><h3>Review flags</h3>
        ${(s.reviews || []).map(r => `<div class="banner rose">${r.why} · ${r.amount} · ${TM.ago(r.t)}</div>`).join("") || "<p class='disclaimer'>None</p>"}
      </div>`;
  },

  trust() {
    const s = TM.S, m = TM.metrics();
    const flags = [];
    if (TM.playable(s) > 1e7) flags.push("Impossible playable balance");
    if (m.wr > .85 && s.player.games > 20) flags.push("Extreme win rate " + Math.round(m.wr * 100) + "%");
    if (s.settings.turbo >= 500) flags.push("Turbo stress active");
    const hashes = (s.games || []).map(g => g.proof?.finalHash).filter(Boolean);
    if (new Set(hashes).size !== hashes.length && hashes.length) flags.push("Duplicate proof hash");
    const samp = s.session.samples || [];
    const rg = s.settings.rg;
    return `<div class="view-head"><div><h2>Trust Center</h2><p>Local analytics, anti-cheat heuristics, RG posture. Not a production compliance suite.</p></div></div>
      <div class="grid g4">
        ${kpi("Anti-cheat flags", flags.length, flags.join(" · ") || "Clean")}
        ${kpi("Self-exclusion", rg.excludePerm ? "Permanent" : (rg.excludeUntil > Date.now() ? "Active" : "Off"))}
        ${kpi("Session samples", samp.length, "local series")}
        ${kpi("RNG z-score", m.z.toFixed(2), m.n + " H/T flips")}
      </div>
      <div class="card" style="margin-top:14px"><h3>Sampled house fees</h3>${spark(samp.map(x => x.fees || 0))}</div>
      <div class="grid g2" style="margin-top:14px">
        <div class="card">
          <h3>Responsible gaming</h3>
          <table>
            <tr><td>Loss limit</td><td>${rg.lossLimit}</td></tr>
            <tr><td>Session minutes</td><td>${rg.sessionMin || "off"}</td></tr>
            <tr><td>Daily top-up cap</td><td>${rg.depDay || "off"}</td></tr>
            <tr><td>Used today</td><td>${TM.fmt(rg.usedDay || 0)}</td></tr>
            <tr><td>Auto-rebet stop</td><td>${s.settings.autoRebetStop}</td></tr>
          </table>
          <p class="disclaimer">Admin cannot lift a durable player self-exclusion.</p>
        </div>
        <div class="card">
          <h3>Platform posture</h3>
          <p>PWA manifest present. Verifier is public. In-browser API / remote push / account TOTP are not wired in this demo.</p>
          <p class="disclaimer">Flags: ${flags.join("; ") || "none"}</p>
        </div>
      </div>`;
  }
};

function bind() {
  $$("[data-tab]").forEach(b => b.onclick = () => go(b.dataset.tab));
  $$("[data-pg]").forEach(b => b.onclick = () => {
    const k = b.dataset.pg;
    page[k] = Math.max(0, (page[k] || 0) + (+b.dataset.d));
    draw();
  });
  $$("[data-qf]").forEach(b => b.onclick = () => { filters.qGame = b.dataset.qf; page.q = 0; draw(); });
  $$("[data-tuk]").forEach(b => b.onclick = () => { filters.tuKind = b.dataset.tuk; page.tu = 0; draw(); });
  $$("[data-ps]").forEach(b => b.onclick = () => { filters.peopleSort = b.dataset.ps; draw(); });

  $("#maint") && ($("#maint").onclick = () => { TM.S.config.maintenance = !TM.S.config.maintenance; TM.audit("Maintenance " + TM.S.config.maintenance); TM.save(); draw(); });
  $("#seedJp") && ($("#seedJp").onclick = () => { TM.S.jackpot.pool += 50; if (TM.S.jackpot.pool >= TM.S.config.jpArm) TM.S.jackpot.armed = true; TM.audit("Jackpot seeded +50"); TM.save(); draw(); });
  $("#mkTr") && ($("#mkTr").onclick = () => { TM.createTrny({ size: 8, entry: 100, format: "single" }); TM.audit("Quick tournament"); draw(); });
  $("#exState") && ($("#exState").onclick = () => dl("tossmatch-state.json", JSON.stringify(TM.S), "application/json"));
  $("#topLow") && ($("#topLow").onclick = () => {
    const r = TM.topupLowBots();
    TM.toast(r.n ? `Topped up ${r.n} bots · ${TM.fmt(r.coins)} coins` : "No bots below trigger");
    draw();
  });
  $("#bcGo") && ($("#bcGo").onclick = () => { TM.S.config.broadcast = $("#bc").value.slice(0, 120); TM.audit("Broadcast set"); TM.save(); TM.toast("Broadcast live"); });
  $("#bcClr") && ($("#bcClr").onclick = () => { TM.S.config.broadcast = ""; TM.save(); draw(); });

  $("#opsSave") && ($("#opsSave").onclick = () => {
    const c = TM.S.config;
    c.botsOn = $("#botsOn").checked;
    c.growthOn = $("#growOn").checked;
    c.autoMatch = $("#autoOn").checked;
    c.questsOn = $("#questOn").checked;
    c.loginOn = $("#loginOn").checked;
    c.maintenance = $("#maintOn").checked;
    c.botTopAt = TM.clamp(+$("#topAt").value, 0, 10000);
    c.growthMax = TM.clamp(+$("#growMax").value, 99, 1000);
    if ($("#mainShare")) c.mainShare = TM.clamp(+$("#mainShare").value, 80, 90) / 100;
    if ($("#wdMin")) c.wdMin = TM.clamp(+$("#wdMin").value, 500, 20000);
    if ($("#wdMax")) c.wdMax = Math.max(c.wdMin || 3000, TM.clamp(+$("#wdMax").value, 500, 50000));
    TM.audit("Operations saved"); TM.save(); TM.toast("Operations saved");
  });

  $("#dq") && ($("#dq").oninput = e => { filters.dirQ = e.target.value; draw(); });
  $("#dc") && ($("#dc").onchange = e => { filters.dirCat = e.target.value; draw(); });
  $("#ds") && ($("#ds").onchange = e => { filters.dirSt = e.target.value; draw(); });
  $("#pq") && ($("#pq").oninput = e => { filters.peopleQ = e.target.value; page.pe = 0; draw(); });
  $("#lvQ") && ($("#lvQ").oninput = e => { filters.lvQ = e.target.value; page.lv = 0; draw(); });

  $("#svRates") && ($("#svRates").onclick = () => {
    const c = TM.S.config;
    c.fee = TM.clamp(+$("#fee").value, 0, 25) / 100;
    c.cupRake = TM.clamp(+$("#cupRake").value, 0, 25) / 100;
    c.trnyRake = TM.clamp(+$("#trnyRake").value, 0, 25) / 100;
    c.xferFee = TM.clamp(+$("#xferFee").value, 0, 10) / 100;
    c.jpFund = TM.clamp(+$("#jpFund").value, 0, 50) / 100;
    c.jpFloor = TM.clamp(+$("#jpFloor").value, 0, 10);
    c.jpArm = TM.clamp(+$("#jpArm").value, 0, 1000);
    c.jpPay = TM.clamp(+$("#jpPay").value, 1, 100) / 100;
    c.nonMainCap = TM.clamp(+$("#nonMainCap").value, 10, 20) / 100;
    c.xferMin = +$("#xferMin").value; c.xferCap = +$("#xferCap").value;
    if (TM.S.jackpot.pool >= c.jpArm) TM.S.jackpot.armed = true;
    TM.audit("Rates updated"); TM.save(); TM.toast("Rates saved");
  });

  $("#simGo") && ($("#simGo").onclick = () => { window._simN = +$("#simN").value; window._simStake = +$("#simStake").value; draw(); });
  $("#compGo") && ($("#compGo").onclick = () => {
    const n = +$("#compN").value;
    const m = TM.metrics();
    if (n > m.houseNet) return TM.toast("Exceeds net house", "bad");
    TM.S.wallet.bonus += n; TM.S.house.comps += n; TM.S.taps += n; TM.audit("Comp " + n); TM.save(); draw();
  });

  $("#ft") && ($("#ft").onchange = e => { TM.S.config.firstTopup = e.target.checked; TM.audit("First top-up " + e.target.checked); TM.save(); draw(); });
  $("#svPromo") && ($("#svPromo").onclick = () => {
    TM.S.config.firstTopupPct = TM.clamp(+$("#ftPct").value, 0, 200);
    TM.audit("Promo percent " + TM.S.config.firstTopupPct);
    TM.save();
    TM.toast("Promo set to " + TM.S.config.firstTopupPct + "%");
    draw();
  });
  $("#cAdd") && ($("#cAdd").onclick = () => {
    TM.S.campaigns = TM.S.campaigns || [];
    TM.S.campaigns.push({ name: $("#cn").value || "Campaign", type: $("#ct").value, amount: +$("#ca").value || 0, on: true, claims: 0 });
    TM.audit("Campaign created"); TM.save(); draw();
  });
  $$("[data-ctog]").forEach(b => b.onclick = () => { TM.S.campaigns[+b.dataset.ctog].on = !TM.S.campaigns[+b.dataset.ctog].on; TM.save(); draw(); });
  $$("[data-cdel]").forEach(b => b.onclick = () => { TM.S.campaigns.splice(+b.dataset.cdel, 1); TM.save(); draw(); });
  $$("[data-cclaim]").forEach(b => b.onclick = () => {
    const c = TM.S.campaigns[+b.dataset.cclaim];
    if (!c.on) return TM.toast("Campaign paused", "bad");
    if (c.claimedByPlayer) return TM.toast("Already claimed", "bad");
    const n = c.amount || 0;
    TM.S.wallet.bonus += n; TM.S.taps += n; TM.S.house.promo += n;
    c.claims = (c.claims || 0) + 1; c.claimedByPlayer = true;
    TM.audit("Campaign credit " + n); TM.save(); TM.toast("+" + n + " BONUS"); draw();
  });

  $("#endMonth") && ($("#endMonth").onclick = () => { TM.S.player.monthWagered = 0; TM.audit("VIP month ended"); TM.save(); draw(); });
  $("#svVip") && ($("#svVip").onclick = () => {
    $$("[data-vw]").forEach(i => TM.S.config.vip[+i.dataset.vw].wager = +i.value);
    $$("[data-vr]").forEach(i => TM.S.config.vip[+i.dataset.vr].rake = TM.clamp(+i.value, 0, 20));
    TM.audit("VIP table saved"); TM.save(); TM.toast("VIP saved");
  });
  $("#svLv") && ($("#svLv").onclick = () => {
    TM.S.config.levelRewards = TM.S.config.levelRewards || { ...TM.LEVEL_REWARD };
    $$("[data-lr]").forEach(i => TM.S.config.levelRewards[i.dataset.lr] = +i.value);
    TM.audit("Level rewards saved"); TM.save(); TM.toast("Rewards saved");
  });

  $("#tMake") && ($("#tMake").onclick = () => { TM.createTrny({ size: +$("#ts").value, entry: +$("#te").value, format: $("#tf").value }); TM.audit("Tournament created"); draw(); });
  $("#exLed") && ($("#exLed").onclick = () => {
    const csv = "t,type,delta,note,main\n" + TM.S.ledger.map(l => [l.t, l.type, l.delta, JSON.stringify(l.note), l.main].join(",")).join("\n");
    dl("ledger.csv", csv, "text/csv");
  });
  $("#exGames") && ($("#exGames").onclick = () => dl("games.json", JSON.stringify(TM.S.games, null, 2), "application/json"));
  $("#exAll") && ($("#exAll").onclick = () => dl("tossmatch-state.json", JSON.stringify(TM.S), "application/json"));
  $("#wdRun") && ($("#wdRun").onclick = () => {
    const r = TM.processBotWithdrawals();
    TM.audit("Processed bot withdrawals " + r.n + " / " + r.coins);
    TM.save();
    TM.toast(r.n ? ("Paid " + r.n + " withdrawals · −" + TM.fmt(r.coins) + " revenue") : "No bot is at the 3,000–5,000 trigger yet");
    draw();
  });
  $("#exWd") && ($("#exWd").onclick = () => {
    const log = TM.S.withdrawals?.log || [];
    const csv = "t,name,amount,keep,status\n" + log.map(x => [x.t, x.name, x.amount, x.keep, x.status].join(",")).join("\n");
    dl("withdrawals.csv", csv, "text/csv");
  });
  $("#exTop") && ($("#exTop").onclick = () => {
    const log = TM.S.topups?.log || [];
    const csv = "t,kind,name,base,bonus,total,reason,count\n" + log.map(x => [x.t, x.kind, x.name, x.base, x.bonus, x.total, x.reason, x.count].join(",")).join("\n");
    dl("topups.csv", csv, "text/csv");
  });
  $("#wipe") && ($("#wipe").onclick = () => { if (confirm("Reset all local demo state?")) { TM.reset(); draw(); } });
}

function dl(name, text, type) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([text], { type: type || "application/json" }));
  a.download = name; a.click();
}

document.addEventListener("DOMContentLoaded", () => {
  TM.load();
  TM.bootBankrolls();
  const h = (location.hash || "#dash").slice(1);
  if (NAV.flatMap(g => g.items).some(([id]) => id === h)) tab = h;
  draw();
  window.addEventListener("hashchange", () => {
    const id = location.hash.slice(1);
    if (NAV.flatMap(g => g.items).some(([x]) => x === id)) { tab = id; draw(); }
  });
  setInterval(() => {
    TM.botTick().then(() => {
      if (document.hidden) return;
      const ae = document.activeElement;
      if (ae && /^(INPUT|SELECT|TEXTAREA)$/.test(ae.tagName)) return;
      draw();
    });
  }, 1000);
});
