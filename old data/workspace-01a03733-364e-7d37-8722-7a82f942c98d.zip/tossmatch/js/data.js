window.TM = window.TM || {};

TM.PAT3 = ["HHH","HHT","HTH","HTT","THH","THT","TTH","TTT"];
TM.PAT5 = ["HHHHH","TTTTH","HTHTH","THTHT","HHHTT","TTTHH","HTHTT","THTHH"];
TM.BITS = ["HHH","HHT","HTH","HTT","THH","THT","TTH","TTT"];

TM.CATS = [
  {id:"side", name:"Side Picks"},
  {id:"numbers", name:"Numbers & Dice"},
  {id:"patterns", name:"Patterns & Territory"},
  {id:"cards", name:"Cards"}
];
TM.ARCADE_CATS = [
  {id:"classic", name:"Classic & Chance"},
  {id:"p2p", name:"P2P Duels"},
  {id:"puzzle", name:"Puzzle & Picks"},
  {id:"daily", name:"Daily & Collection"}
];

function opp(list){ return {type:"opposite", list}; }
function diff(list){ return {type:"different", list}; }
function none(){ return {type:"none"}; }
function num(min,max){ return {type:"number", min, max}; }

TM.CATALOG = [
  {id:"overunder", code:"CAT01", name:"Over / Under", cat:"side", pick:opp(["HIGH","LOW"]),
    blurb:"Byte 0 ≥ 128 is HIGH. Opposite sides only.", edge:"No tie."},
  {id:"speed", code:"CAT02", name:"Speed Round", cat:"side", pick:opp(["HEADS","TAILS"]),
    blurb:"First five proof bytes become flips. Majority side wins.", edge:"Five flips cannot tie."},
  {id:"tug", code:"CAT03", name:"Tug of War", cat:"side", pick:opp(["LEFT","RIGHT"]),
    blurb:"HEADS pulls left, TAILS pulls right. First to ±3 wins.", edge:"Fallback to final direction."},
  {id:"evenodd", code:"CAT04", name:"Even / Odd Sum", cat:"side", pick:opp(["EVEN","ODD"]),
    blurb:"Bytes 0 and 1 are added. Sum parity wins.", edge:"No tie."},
  {id:"blind", code:"CAT05", name:"Blind Pick", cat:"side", pick:{type:"sameok", list:["HEADS","TAILS"]},
    blurb:"Same pick can split or carry. Different picks play the flip.", edge:"Split if both match; carry if both miss."},
  {id:"chain", code:"CAT06", name:"Chain Reaction", cat:"side", pick:opp(["HEADS","TAILS"]),
    blurb:"Callers alternate for up to 10 flips. First miss loses.", edge:"Both survive 10 → split."},
  {id:"ladder", code:"CAT07", name:"Elimination Ladder", cat:"side", pick:opp(["HEADS","TAILS"]),
    blurb:"First selected side to appear three times reaches rung 3.", edge:"No formal tie."},
  {id:"mirror", code:"CAT08", name:"Mirrored Coins", cat:"side", pick:opp(["HEADS","TAILS"]),
    blurb:"Your coin is byte 0, theirs is byte 1. Match your own pick.", edge:"Matching coins carry."},
  {id:"rps", code:"CAT18", name:"Rock Paper Scissors", cat:"side", pick:diff(["ROCK","PAPER","SCISSORS"]),
    blurb:"Standard dominance. Identical choices split.", edge:"All pairs compatible; same choice splits."},
  {id:"triple", code:"CAT20", name:"Triple Coin Majority", cat:"side", pick:opp(["HEADS","TAILS"]),
    blurb:"Majority of three proof flips wins.", edge:"Opposite sides only."},
  {id:"prime", code:"CAT24", name:"Prime vs Composite", cat:"side", pick:opp(["PRIME","COMPOSITE"]),
    blurb:"A proof integer from 2–251 is classified.", edge:"1 is unused; 2 is prime."},
  {id:"streak", code:"CAT26", name:"Streak Survivor", cat:"side", pick:opp(["HEADS","TAILS"]),
    blurb:"First side to four consecutive proof flips wins.", edge:"No streak in the window carries."},
  {id:"closest", code:"CAT09", name:"Closest Number", cat:"numbers", pick:num(0,255),
    blurb:"Different picks. Smallest distance to byte 0 wins.", edge:"Equal distance splits."},
  {id:"lucky", code:"CAT10", name:"Lucky Number Battle", cat:"numbers", pick:num(0,255),
    blurb:"Exact hit is highlighted; otherwise closest to byte 0.", edge:"Equal distance carries."},
  {id:"sumpred", code:"CAT11", name:"Sum Prediction", cat:"numbers", pick:num(0,510),
    blurb:"Closest prediction to byte 0 + byte 1.", edge:"Equal distance splits."},
  {id:"higher", code:"CAT12", name:"Higher Byte", cat:"numbers", pick:none(),
    blurb:"You receive byte 0, opponent receives byte 1. Higher wins.", edge:"Equal values split."},
  {id:"c21", code:"CAT19", name:"Closest to 21", cat:"numbers", pick:none(),
    blurb:"Two proof cards each. Closest total ≤ 21 wins.", edge:"Equal totals or both bust split."},
  {id:"dicesum", code:"CAT22", name:"Dice Sum Duel", cat:"numbers", pick:none(),
    blurb:"Two proof dice each. Higher sum wins.", edge:"Equal sums split."},
  {id:"median", code:"CAT25", name:"Median Number Battle", cat:"numbers", pick:num(0,255),
    blurb:"Two distinct picks plus a proof number. Nearest the median wins.", edge:"Equal distance splits."},
  {id:"mod4", code:"CAT28", name:"Modulo Four Duel", cat:"numbers", pick:diff(["0","1","2","3"]),
    blurb:"Proof byte modulo four. Unclaimed remainder carries.", edge:"Different remainders only."},
  {id:"threedice", code:"CAT30", name:"Three Dice Poker", cat:"numbers", pick:none(),
    blurb:"Triple beats pair, then higher total / high die.", edge:"Exact ties split."},
  {id:"lastdigit", code:"CAT31", name:"Last Digit Duel", cat:"numbers", pick:diff(["0","1","2","3","4","5","6","7","8","9"]),
    blurb:"Compete for the last digit of a proof number.", edge:"Unclaimed digits carry."},
  {id:"coinbal", code:"CAT33", name:"Coin Balance Battle", cat:"numbers", pick:diff(["2","3","4","5","6","7","8"]),
    blurb:"Predict HEADS in ten proof flips. Closest wins.", edge:"Equal distance splits."},
  {id:"pattern", code:"CAT13", name:"Pattern Race", cat:"patterns", pick:diff(TM.PAT3),
    blurb:"First selected 3-flip string to appear wins.", edge:"Neither in 32 bytes carries."},
  {id:"parlay", code:"CAT14", name:"Parlay Duel", cat:"patterns", pick:diff(TM.PAT3),
    blurb:"Three flips. Most position-by-position matches wins.", edge:"Equal match count carries."},
  {id:"pstreak", code:"CAT15", name:"Prediction Streak", cat:"patterns", pick:diff(TM.PAT5),
    blurb:"Five flips. Most correct positions wins.", edge:"Equal count splits."},
  {id:"rangewar", code:"CAT16", name:"Range War", cat:"patterns", pick:diff(["0–63","64–127","128–191","192–255"]),
    blurb:"Byte 0 inside a claimed quarter wins.", edge:"Unclaimed quarter carries."},
  {id:"bullseye", code:"CAT17", name:"Bullseye", cat:"patterns", pick:diff(["N","E","S","W"]),
    blurb:"Same numeric quarters as target wedges.", edge:"Unclaimed wedge carries."},
  {id:"sequence", code:"CAT21", name:"Sequence Builder", cat:"patterns", pick:diff(["HH","HT","TH","TT"]),
    blurb:"First different two-symbol starter to appear wins.", edge:"None in the window carries."},
  {id:"colour", code:"CAT23", name:"Colour Spectrum Duel", cat:"patterns", pick:diff(["CRIMSON","AMBER","TEAL","VIOLET"]),
    blurb:"Non-overlapping colour bands. Claimed band wins.", edge:"Unclaimed band carries."},
  {id:"territory", code:"CAT27", name:"Territory Capture", cat:"patterns", pick:diff(["NORTH","SOUTH"]),
    blurb:"Nine proof bytes capture sectors. Higher count wins.", edge:"Equal nonzero splits; 0–0 carries."},
  {id:"binary", code:"CAT32", name:"Binary Code Duel", cat:"patterns", pick:diff(TM.BITS),
    blurb:"Lowest Hamming distance to a 3-bit proof code wins.", edge:"Equal distance splits."},
  {id:"poker", code:"CAT29", name:"Poker High Duel", cat:"cards", pick:none(),
    blurb:"Five proof cards each. Standard category plus kickers.", edge:"Exact ties split."}
];

TM.ARCADE = [
  {id:"wheel", code:"G01", name:"Lucky Wheel", cat:"classic", stakeDefault:50,
    blurb:"Daily free spin plus 50-coin paid spins. Coin and cosmetic prizes."},
  {id:"scratch", code:"G02", name:"Scratch Cards", cat:"classic", stakeChoices:[25,75,200],
    blurb:"Common / Rare / Epic. Reveal 9 cells. 3+ matches pay."},
  {id:"dice", code:"G03", name:"Dice Roll", cat:"classic",
    blurb:"Exact double pays 30×. Low or high sum pays 1.8×."},
  {id:"plinko", code:"G07", name:"Plinko Drop", cat:"classic",
    blurb:"Nine slots: 0×, 0.5×, 1×, 2×, 5×, 2×, 1×, 0.5×, 0×."},
  {id:"slots", code:"G08", name:"Mini Slots", cat:"classic",
    blurb:"Pair 2×. Triple 5×. Triple 7 pays 10×."},
  {id:"dropball", code:"G13", name:"Drop Ball", cat:"classic",
    blurb:"Seven columns bounce into 0× / 0.5× / 1× / 3× pockets."},
  {id:"pusher", code:"G17", name:"Coin Pusher", cat:"classic",
    blurb:"Five proof drops push stacks into 0×–6× trays."},
  {id:"tower", code:"G18", name:"Tower Builder", cat:"classic",
    blurb:"Survive every floor. Target 3 / 5 / 7 pays 1.6× / 3× / 7×."},
  {id:"ladder", code:"G05", name:"Multiplier Ladder", cat:"p2p",
    blurb:"P2P climb. Higher surviving rung takes the pot."},
  {id:"war", code:"G06", name:"War Card", cat:"p2p",
    blurb:"Ranks 2–Ace. Automatic war on ties."},
  {id:"keno", code:"G09", name:"Quick Keno", cat:"puzzle",
    blurb:"Pick five numbers 1–20. 2/3/4/5 hits pay 0.5× / 1.5× / 5× / 20×."},
  {id:"bingo", code:"G10", name:"Bingo Rush", cat:"puzzle",
    blurb:"3×3 card, six draws. Any line pays 3×."},
  {id:"treasure", code:"G11", name:"Treasure Hunt", cat:"puzzle",
    blurb:"Choose a tile. Traps, coins, chests and a key. 0×–5×."},
  {id:"memory", code:"G12", name:"Memory Match", cat:"puzzle",
    blurb:"Eight proof-driven moves. Pair counts pay 1× / 2× / 4× / 8×."},
  {id:"penalty", code:"G16", name:"Penalty Shootout", cat:"puzzle",
    blurb:"Five kicks vs a proof goalkeeper. 3 / 4 / 5 goals pay 1.5× / 3× / 8×."},
  {id:"match3", code:"G19", name:"Match-3 Rush", cat:"puzzle",
    blurb:"Proof 5×5 gem board. 2 / 4 / 6+ matches pay 1.5× / 4× / 10×."},
  {id:"vault", code:"G20", name:"Mystery Vault", cat:"puzzle",
    blurb:"Choose one of five keys. The proof key pays 4.5×."},
  {id:"raffle", code:"G04", name:"Weekly Raffle", cat:"daily",
    blurb:"10-coin tickets. Immediate demo draw. 80 / 20 winner / house."},
  {id:"trivia", code:"G14", name:"Daily Trivia", cat:"daily",
    blurb:"One attempt per local day. Correct answer pays 3×."},
  {id:"fishing", code:"G15", name:"Fishing Reel", cat:"daily",
    blurb:"Bait shifts rarity. Common 0.5× through Legendary 10×."}
];

TM.VIP = [
  {id:"starter", name:"Starter", wager:0, rake:0, shop:0, color:"#8b93a7", perk:"Basic access, quests, jackpot."},
  {id:"silver", name:"Silver", wager:1000, rake:4, shop:0, color:"#b9c4d6", perk:"Blue chat colour · 1 premium emoji."},
  {id:"gold", name:"Gold", wager:3000, rake:6, shop:0, color:"#f5c15d", perk:"Gold frame · queue priority · 2 emojis."},
  {id:"plat", name:"Platinum", wager:8000, rake:8, shop:0, color:"#d7dff2", perk:"Platinum coin skin · 2 emojis."},
  {id:"dia", name:"Diamond", wager:20000, rake:12, shop:0, color:"#7ad7ff", perk:"Diamond skin · 5% cup/entry cut · 3 emojis."},
  {id:"bdia", name:"Black Diamond", wager:50000, rake:15, shop:10, color:"#c5b4ff", perk:"Animated frame · shop −10% · 5 emojis."},
  {id:"royal", name:"Royal", wager:75000, rake:17, shop:20, color:"#ffb27a", perk:"Royal Crown · shop −20% · 8 emojis."},
  {id:"legend", name:"Legend", wager:100000, rake:20, shop:30, color:"#39ffb6", perk:"Legend Prism · shop −30% · gold name."}
];

TM.LEVEL_REWARD = {};
for (let lv = 2; lv <= 50; lv++) TM.LEVEL_REWARD[lv] = lv * 50;

TM.ACHIEVEMENTS = [
  {id:"first", name:"First Flip", test:s=>s.player.games>=1, reward:30, hint:"Settle your first game."},
  {id:"fire", name:"On Fire", test:s=>s.player.streak>=3, reward:75, hint:"A 3-win streak."},
  {id:"unstop", name:"Unstoppable", test:s=>s.player.streak>=5, reward:150, hint:"A 5-win streak."},
  {id:"volcanic", name:"Volcanic", test:s=>s.player.bestStreak>=10, reward:500, hint:"A 10-win streak."},
  {id:"untouch", name:"Untouchable", test:s=>s.player.bestStreak>=15, reward:1000, hint:"A 15-win streak."},
  {id:"jack", name:"Jackpot!", test:s=>s.player.jackpots>=1, reward:300, hint:"Hit the armed jackpot."},
  {id:"cup", name:"Cup Winner", test:s=>s.player.cupWins>=1, reward:100, hint:"Win a Series Cup."},
  {id:"cups5", name:"Cup Specialist", test:s=>s.player.cupWins>=5, reward:300, hint:"Win 5 Cups."},
  {id:"cups10", name:"Cup Legend", test:s=>s.player.cupWins>=10, reward:600, hint:"Win 10 Cups."},
  {id:"champ", name:"Champion", test:s=>s.player.trnyWins>=1, reward:300, hint:"Win a tournament."},
  {id:"boss", name:"Bracket Boss", test:s=>s.player.trnyWins>=3, reward:500, hint:"Win 3 tournaments."},
  {id:"royalty", name:"Tournament Royalty", test:s=>s.player.trnyWins>=5, reward:750, hint:"Win 5 tournaments."},
  {id:"baller", name:"Big Baller", test:s=>s.player.biggestStake>=500, reward:100, hint:"Stake 500+."},
  {id:"owl", name:"Night Owl", test:s=>s.player.games>=10, reward:50, hint:"Play 10 games."},
  {id:"freq", name:"Frequent Flipper", test:s=>s.player.games>=25, reward:100, hint:"Play 25 games."},
  {id:"century", name:"Century Club", test:s=>s.player.games>=100, reward:250, hint:"Settle 100 games."},
  {id:"vet", name:"Veteran", test:s=>s.player.games>=250, reward:500, hint:"Settle 250 games."},
  {id:"dd", name:"Double Digits", test:s=>s.player.wins>=10, reward:100, hint:"Win 10 games."},
  {id:"qc", name:"Quarter Century", test:s=>s.player.wins>=25, reward:250, hint:"Win 25 games."},
  {id:"wm", name:"Winning Machine", test:s=>s.player.wins>=100, reward:750, hint:"Win 100 games."},
  {id:"lv5", name:"High Roller", test:s=>s.player.level>=5, reward:100, hint:"Reach level 5."},
  {id:"lv10", name:"Double-Digit Level", test:s=>s.player.level>=10, reward:300, hint:"Reach level 10."},
  {id:"lv20", name:"Elite Level", test:s=>s.player.level>=20, reward:750, hint:"Reach level 20."},
  {id:"lv30", name:"Master Level", test:s=>s.player.level>=30, reward:1000, hint:"Reach level 30."},
  {id:"lv40", name:"Mythic Level", test:s=>s.player.level>=40, reward:1500, hint:"Reach level 40."},
  {id:"lv50", name:"Level Summit", test:s=>s.player.level>=50, reward:2500, hint:"Reach level 50."},
  {id:"comeback", name:"Comeback Kid", test:s=>!!s.player.flags.comeback, reward:75, hint:"Win after two losses."},
  {id:"explore", name:"Game Explorer", test:s=>Object.keys(s.player.catalogPlayed||{}).length>=5, reward:150, hint:"Play 5 catalog games."},
  {id:"cmaster", name:"Catalog Master", test:s=>Object.keys(s.player.catalogPlayed||{}).length>=17, reward:750, hint:"Play 17 catalog games."},
  {id:"cveteran", name:"Catalog Veteran", test:s=>s.player.catalogGames>=50, reward:500, hint:"50 catalog matches."},
  {id:"col5", name:"Collector", test:s=>ownedPaid(s)>=5, reward:150, hint:"Own 5 paid cosmetics."},
  {id:"col15", name:"Super Collector", test:s=>ownedPaid(s)>=15, reward:400, hint:"Own 15 paid cosmetics."},
  {id:"vault", name:"Wardrobe Vault", test:s=>ownedPaid(s)>=25, reward:750, hint:"Own 25 paid cosmetics."},
  {id:"silver", name:"Silver Status", test:s=>TM.vipIndex(s)>=1, reward:100, hint:"Reach Silver VIP."},
  {id:"goldst", name:"Gold Status", test:s=>TM.vipIndex(s)>=2, reward:250, hint:"Reach Gold VIP."},
  {id:"profit", name:"Profit Maker", test:s=>s.player.net>=1000, reward:300, hint:"+1,000 career net."},
  {id:"gift", name:"Generous", test:s=>s.player.transfers>=5, reward:150, hint:"Complete 5 transfers."},
  {id:"banker", name:"Community Banker", test:s=>s.player.transfers>=10, reward:300, hint:"Complete 10 transfers."},
  {id:"friends5", name:"Friendly Five", test:s=>(s.social.friends||[]).length>=5, reward:125, hint:"5 friends."},
  {id:"friends10", name:"Social Circle", test:s=>(s.social.friends||[]).length>=10, reward:250, hint:"10 friends."},
  {id:"chat10", name:"Lobby Regular", test:s=>s.player.chatSent>=10, reward:100, hint:"10 chat messages."},
  {id:"rooms3", name:"Room Host", test:s=>s.player.roomsCreated>=3, reward:150, hint:"Create 3 private rooms."},
  {id:"gifts3", name:"Gift Giver", test:s=>s.player.gifts>=3, reward:150, hint:"Send 3 gifts."},
  {id:"arc10", name:"Arcade Starter", test:s=>s.player.arcadeGames>=10, reward:150, hint:"10 Arcade+ games."},
  {id:"arc50", name:"Arcade Ace", test:s=>s.player.arcadeGames>=50, reward:500, hint:"50 Arcade+ games."},
  {id:"pay1k", name:"Four-Figure Payout", test:s=>s.player.maxPayout>=1000, reward:300, hint:"A 1,000+ payout."},
  {id:"vol", name:"Volume Player", test:s=>s.player.wagered>=10000, reward:300, hint:"Wager 10,000."},
  {id:"clan5", name:"Clan Loyalist", test:s=>s.player.clanGames>=5, reward:300, hint:"5 clan games."},
  {id:"allr", name:"All-Rounder", test:s=>s.player.catalogGames>=1 && s.player.cupPlays>=1 && s.player.trnyPlays>=1 && s.player.friendGames>=1 && s.player.arcadeGames>=1, reward:500, hint:"Play every family once."}
];
function ownedPaid(s){
  return (s.player.owned||[]).filter(id => {
    const it = TM.SHOP.find(x=>x.id===id);
    return it && it.price>0;
  }).length;
}

TM.QUESTS = [
  {id:"settle3", name:"Settle 3 games", target:3, key:"qGames", reward:50},
  {id:"win1", name:"Win a game", target:1, key:"qWins", reward:75},
  {id:"cup1", name:"Play a Series Cup", target:1, key:"qCups", reward:50}
];

TM.SHOP = [
  {id:"skin-classic", cat:"skins", name:"Classic", price:0, swatch:"linear-gradient(135deg,#d7a247,#f5c15d)"},
  {id:"skin-silver", cat:"skins", name:"Silver", price:80, swatch:"linear-gradient(135deg,#9aa4b8,#e8eef8)"},
  {id:"skin-neon", cat:"skins", name:"Neon", price:150, swatch:"linear-gradient(135deg,#12c98a,#66f0ff)"},
  {id:"skin-galaxy", cat:"skins", name:"Galaxy", price:250, swatch:"linear-gradient(135deg,#2b1b5e,#c5b4ff)"},
  {id:"skin-rainbow", cat:"skins", name:"Rainbow", price:400, swatch:"conic-gradient(#ff6b8a,#f5c15d,#5ee4a3,#7aa2ff,#b38cff,#ff6b8a)"},
  {id:"skin-obsidian", cat:"skins", name:"Obsidian", price:300, swatch:"linear-gradient(135deg,#111,#555)"},
  {id:"skin-solar", cat:"skins", name:"Solar Flare", price:350, swatch:"linear-gradient(135deg,#ff7a18,#ffd36a)"},
  {id:"skin-frost", cat:"skins", name:"Frostfire", price:350, swatch:"linear-gradient(135deg,#7ad7ff,#ff6b8a)"},
  {id:"skin-quantum", cat:"skins", name:"Quantum Shift", price:500, swatch:"linear-gradient(135deg,#39ffb6,#7aa2ff)"},
  {id:"skin-jade", cat:"skins", name:"Jade Fortune", price:280, swatch:"linear-gradient(135deg,#0b6,#9bf0c5)"},
  {id:"skin-lunar", cat:"skins", name:"Lunar Halo", price:320, swatch:"linear-gradient(135deg,#c9d4e8,#fff)"},
  {id:"skin-prism", cat:"skins", name:"Legend Prism", price:2000, vip:"legend", swatch:"linear-gradient(135deg,#39ffb6,#f5c15d,#c5b4ff)"},
  {id:"flag-earth", cat:"flags", name:"Earth", price:0, glyph:"🌍"},
  {id:"flag-in", cat:"flags", name:"India", price:40, glyph:"🇮🇳"},
  {id:"flag-us", cat:"flags", name:"United States", price:40, glyph:"🇺🇸"},
  {id:"flag-gb", cat:"flags", name:"United Kingdom", price:40, glyph:"🇬🇧"},
  {id:"flag-jp", cat:"flags", name:"Japan", price:40, glyph:"🇯🇵"},
  {id:"flag-kr", cat:"flags", name:"Korea", price:40, glyph:"🇰🇷"},
  {id:"flag-br", cat:"flags", name:"Brazil", price:40, glyph:"🇧🇷"},
  {id:"flag-sg", cat:"flags", name:"Singapore", price:60, glyph:"🇸🇬"},
  {id:"flag-ae", cat:"flags", name:"UAE", price:60, glyph:"🇦🇪"},
  {id:"flag-au", cat:"flags", name:"Australia", price:60, glyph:"🇦🇺"},
  {id:"flag-za", cat:"flags", name:"South Africa", price:60, glyph:"🇿🇦"},
  {id:"flag-pt", cat:"flags", name:"Portugal", price:60, glyph:"🇵🇹"},
  {id:"pers-hero", cat:"personas", name:"Hero", price:0, glyph:"🦸"},
  {id:"pers-ninja", cat:"personas", name:"Ninja", price:120, glyph:"🥷"},
  {id:"pers-robot", cat:"personas", name:"Robot", price:120, glyph:"🤖"},
  {id:"pers-royal", cat:"personas", name:"Royal", price:180, glyph:"🤴"},
  {id:"pers-dragon", cat:"personas", name:"Dragon", price:220, glyph:"🐉"},
  {id:"pers-alien", cat:"personas", name:"Alien", price:160, glyph:"👽"},
  {id:"pers-fox", cat:"personas", name:"Fox", price:140, glyph:"🦊"},
  {id:"pers-panda", cat:"personas", name:"Panda", price:140, glyph:"🐼"},
  {id:"pers-uni", cat:"personas", name:"Unicorn", price:200, glyph:"🦄"},
  {id:"fr-thin", cat:"frames", name:"Thin", price:0, swatch:"linear-gradient(#445,#889)"},
  {id:"fr-gold", cat:"frames", name:"Gold", price:150, swatch:"linear-gradient(#d7a247,#f5c15d)"},
  {id:"fr-fire", cat:"frames", name:"Fire", price:180, swatch:"linear-gradient(#ff7a18,#ff3d3d)"},
  {id:"fr-ice", cat:"frames", name:"Ice", price:180, swatch:"linear-gradient(#7ad7ff,#e8f6ff)"},
  {id:"fr-neon", cat:"frames", name:"Neon", price:200, swatch:"linear-gradient(#39ffb6,#66f0ff)"},
  {id:"fr-rain", cat:"frames", name:"Rainbow", price:260, swatch:"conic-gradient(red,orange,yellow,green,blue,purple)"},
  {id:"fr-emerald", cat:"frames", name:"Emerald Orbit", price:240, swatch:"linear-gradient(#0b6,#9bf0c5)"},
  {id:"fr-cosmic", cat:"frames", name:"Cosmic Halo", price:280, swatch:"linear-gradient(#2b1b5e,#c5b4ff)"},
  {id:"fr-crown", cat:"frames", name:"Crown Aura", price:320, swatch:"linear-gradient(#f5c15d,#fff3c4)"},
  {id:"cc-white", cat:"chat", name:"Pearl White", price:0, swatch:"#eef1f7"},
  {id:"cc-gold", cat:"chat", name:"Gold", price:80, swatch:"#f5c15d"},
  {id:"cc-pink", cat:"chat", name:"Pink", price:80, swatch:"#ff8aa8"},
  {id:"cc-cyan", cat:"chat", name:"Cyan", price:80, swatch:"#66f0ff"},
  {id:"cc-crimson", cat:"chat", name:"Crimson", price:80, swatch:"#ff6b8a"},
  {id:"cc-pearl", cat:"chat", name:"Pearl", price:90, swatch:"#f4efe4"},
  {id:"fx-confetti", cat:"fx", name:"Confetti", price:0, glyph:"🎊"},
  {id:"fx-coins", cat:"fx", name:"Coin Rain", price:120, glyph:"🪙"},
  {id:"fx-fire", cat:"fx", name:"Fireworks", price:140, glyph:"🎆"},
  {id:"fx-phoenix", cat:"fx", name:"Phoenix", price:220, glyph:"🔥"},
  {id:"fx-blossom", cat:"fx", name:"Cherry Blossom", price:180, glyph:"🌸"},
  {id:"fx-thunder", cat:"fx", name:"Thunder Storm", price:180, glyph:"⚡"},
  {id:"fx-aurora", cat:"fx", name:"Aurora Burst", price:200, glyph:"🌌"},
  {id:"fx-trophy", cat:"fx", name:"Trophy Shower", price:200, glyph:"🏆"},
  {id:"th-midnight", cat:"themes", name:"Midnight", price:0, theme:""},
  {id:"th-ocean", cat:"themes", name:"Ocean", price:150, theme:"theme-ocean"},
  {id:"th-forest", cat:"themes", name:"Forest", price:150, theme:"theme-forest"},
  {id:"th-sunset", cat:"themes", name:"Sunset", price:150, theme:"theme-sunset"},
  {id:"th-space", cat:"themes", name:"Space", price:180, theme:"theme-space"},
  {id:"th-casino", cat:"themes", name:"Casino", price:180, theme:"theme-casino"},
  {id:"th-aurora", cat:"themes", name:"Aurora", price:200, theme:"theme-aurora"},
  {id:"th-cyber", cat:"themes", name:"Cyber", price:220, theme:"theme-cyber"},
  {id:"snd-std", cat:"sound", name:"Standard", price:0},
  {id:"snd-8bit", cat:"sound", name:"8-bit", price:80},
  {id:"snd-orch", cat:"sound", name:"Orchestral", price:120},
  {id:"snd-dj", cat:"sound", name:"DJ", price:120},
  {id:"snd-synth", cat:"sound", name:"Synthwave", price:140},
  {id:"snd-crystal", cat:"sound", name:"Crystal Chime", price:140},
  {id:"em-fire", cat:"emoji", name:"Fire", price:40, glyph:"🔥"},
  {id:"em-100", cat:"emoji", name:"100", price:40, glyph:"💯"},
  {id:"em-rocket", cat:"emoji", name:"Rocket", price:50, glyph:"🚀"},
  {id:"em-trophy", cat:"emoji", name:"Trophy", price:50, glyph:"🏆"},
  {id:"em-robot", cat:"emoji", name:"Robot", price:50, glyph:"🤖"},
  {id:"em-alien", cat:"emoji", name:"Alien", price:50, glyph:"👽"},
  {id:"em-fox", cat:"emoji", name:"Fox", price:50, glyph:"🦊"},
  {id:"em-panda", cat:"emoji", name:"Panda", price:50, glyph:"🐼"},
  {id:"em-crown", cat:"emoji", name:"Crown", price:60, glyph:"👑"},
  {id:"em-gem", cat:"emoji", name:"Gem", price:60, glyph:"💎"}
];
TM.SHOP_CATS = [
  {id:"skins", name:"Coin skins"},
  {id:"flags", name:"Flags"},
  {id:"personas", name:"Personas"},
  {id:"frames", name:"Frames"},
  {id:"chat", name:"Chat colours"},
  {id:"fx", name:"Victory FX"},
  {id:"themes", name:"Themes"},
  {id:"sound", name:"Sound packs"},
  {id:"emoji", name:"Premium emojis"}
];

TM.BOT_SEED = [
  ["NovaK","IN","Night Captain","Chases late-night jackpots from Delhi."],
  ["LuckyRani","IN","Festival Flip","Never skips a Diwali spin."],
  ["PixelAce","US","Queue Sprinter","Lives in the waiting room."],
  ["NightFlip","GB","After Hours","Only posts after midnight."],
  ["DelhiKing","IN","Old Fort","Claims the table like a terrace."],
  ["CoinWolf","DE","Silent Stake","Talks with the wager."],
  ["Sapphire","SG","Clean Books","Tracks every fee by hand."],
  ["EmberFox","JP","Warm Streak","Smiles through a five-loss hole."],
  ["JadeSpin","KR","Green Room","Collects jade coin skins."],
  ["TurboTom","AU","Stress Tester","Runs the 1000× like a gym."],
  ["MiraByte","IN","Proof Reader","Verifies every hash twice."],
  ["Goldfinch","BR","Carnival","Dances when the jackpot arms."],
  ["ShadowRye","CA","Low Profile","Tiny stakes, long nights."],
  ["QuinFlip","FR","Salon","Posts private rooms with etiquette."],
  ["AriaVolt","AE","Skyline","Bets between tower lights."],
  ["KiteRunner","PK","Open Field","Loves Range War more than sleep."],
  ["NeonNix","US","Club Floor","Equips neon everything."],
  ["RajaCoin","IN","Table Host","Opens Cups for the lobby."],
  ["FrostByte","SE","Cool Ledger","Never tilts. Allegedly."],
  ["LunaWager","MX","Moon Desk","Tracks streaks on graph paper."],
  ["VegaPulse","ES","Fast Hands","Speed Round specialist."],
  ["OrionMint","IT","Gallery","Collects frames like paintings."],
  ["BlazeKit","NG","Heat Check","All-in personality, mid stakes."],
  ["IvoryDice","ZA","Quiet Math","Counts dice aloud."],
  ["CobaltRex","PH","Night Shift","Fills every empty seat."],
  ["SageHopper","TH","Temple Steps","Climbs the multiplier ladder."],
  ["RubyAnte","VN","Red Desk","Transfers friends surprise stacks."],
  ["ZincArrow","PL","Straight Line","Never changes a pick mid-queue."],
  ["HaloMint","PT","Coastal","Fishes the reel between Cups."],
  ["DriftKai","NZ","Long Tide","Patient with carry pools."]
];

TM.COUNTRIES = ["IN","US","GB","JP","KR","BR","DE","FR","AU","SG","AE","ZA","CA","IT","ES","MX","NG","PH","TH","VN","PK","SE","PL","NZ","PT","NL","ID","MY","AR","EG"];
TM.GLYPHS = ["🦊","🐺","🐯","🦁","🐼","🐲","🦄","🤖","🥷","🦸","👑","⚡","🌙","🔥","💎","🪙","🎯","🎲","🧿","🌟"];
TM.TITLES = ["Scout","Regular","Grinder","Captain","Analyst","Host","Collector","Sprinter","Archivist","Rival"];

TM.TRIVIA = [
  {q:"How many sides does a fair coin have?", a:["1","2","3","4"], ok:1},
  {q:"SHA-256 produces a digest of how many bits?", a:["128","160","256","512"], ok:2},
  {q:"In cricket, how many legal deliveries are in a standard over?", a:["5","6","8","10"], ok:1},
  {q:"What is 2⁸?", a:["128","256","512","64"], ok:1},
  {q:"Which city is the capital of India?", a:["Mumbai","Kolkata","New Delhi","Bengaluru"], ok:2},
  {q:"A standard die has how many faces?", a:["4","6","8","12"], ok:1},
  {q:"Which byte value is the Coin Toss jackpot trigger?", a:["0x00","0x7F","0x80","0xFF"], ok:0},
  {q:"Bo3 means first to how many wins?", a:["1","2","3","4"], ok:1}
];

TM.NAV = [
  {g:"Overview", items:[
    {id:"home", name:"Home", ico:"⌂"},
    {id:"lobby", name:"Lobby", ico:"◎"},
    {id:"updates", name:"What's New", ico:"✦"}
  ]},
  {g:"Play", items:[
    {id:"play", name:"Coin Toss", ico:"◐"},
    {id:"games", name:"P2P Catalog", ico:"▣"},
    {id:"arcade", name:"Arcade+", ico:"◇"},
    {id:"series", name:"Series & Cups", ico:"🏆"}
  ]},
  {g:"Community", items:[
    {id:"leaderboard", name:"Leaderboard", ico:"☰"},
    {id:"players", name:"Players", ico:"☺"},
    {id:"community", name:"Social Hub", ico:"✉"}
  ]},
  {g:"Progress & Economy", items:[
    {id:"season", name:"VIP & Season", ico:"★"},
    {id:"shop", name:"Shop", ico:"✦"},
    {id:"plus", name:"Progress+", ico:"▲"},
    {id:"econ", name:"Economy+", ico:"⬡"}
  ]},
  {g:"Account", items:[
    {id:"wallet", name:"Wallet", ico:"▭"},
    {id:"stats", name:"Statistics", ico:"▦"},
    {id:"history", name:"History", ico:"◷"},
    {id:"verify", name:"Verifier", ico:"☑"},
    {id:"services", name:"Safety & Services", ico:"⚙"}
  ]}
];

TM.I18N = {
  en: {
    home:"Home", lobby:"Lobby", play:"Coin Toss", games:"P2P Catalog", arcade:"Arcade+",
    series:"Series & Cups", leaderboard:"Leaderboard", players:"Players", community:"Social Hub",
    season:"VIP & Season", shop:"Shop", plus:"Progress+", econ:"Economy+", wallet:"Wallet",
    stats:"Statistics", history:"History", verify:"Verifier", services:"Safety & Services",
    updates:"What's New", tag:"Play-coin P2P arena",
    playcoins:"Play coins only. This is a local demonstration — not real-money gambling."
  },
  hi: {
    home:"होम", lobby:"लॉबी", play:"कॉइन टॉस", games:"पी2पी कैटलॉग", arcade:"आर्केड+",
    series:"सीरीज़ और कप", leaderboard:"लीडरबोर्ड", players:"खिलाड़ी", community:"सोशल हब",
    season:"वीआईपी और सीज़न", shop:"दुकान", plus:"प्रोग्रेस+", econ:"इकॉनमी+", wallet:"वॉलेट",
    stats:"आँकड़े", history:"इतिहास", verify:"सत्यापन", services:"सुरक्षा सेवाएँ",
    updates:"नया क्या है", tag:"प्ले-कॉइन पी2पी अखाड़ा",
    playcoins:"केवल प्ले कॉइन। यह स्थानीय डेमो है — असली पैसे का जुआ नहीं।"
  }
};

TM.DIRECTORY = [
  ["Core","CORE-1","Coin Toss","Implemented","Escrowed HEADS/TAILS with fee, jackpot and proof.","play"],
  ["Core","CORE-2","P2P Catalog","Implemented","33 proof-driven waiting-room games.","games"],
  ["Core","CORE-3","Series Cups","Implemented","Bo3 / Bo5 / Bo7 / Advantage.","series"],
  ["Core","CORE-4","Tournaments","Implemented","Single-flip and Bo3 brackets, 75/25 prizes.","series"],
  ["Core","CORE-5","Jackpot","Implemented","Fee-funded, armed at threshold, byte 00.","play"],
  ["Core","CORE-6","Fairness Verifier","Implemented","Local SHA-256 recomputation.","verify"],
  ["Social","S1","Friends","Implemented","Add bots, challenge, friend-first queue.","community"],
  ["Social","S2","Private Rooms","Implemented","Invite codes and stake rules.","community"],
  ["Social","S3","Profiles","Implemented","Public stats, cosmetics, form.","players"],
  ["Social","S4","Spectator","Implemented","Watch live pots, picks and proof.","community"],
  ["Social","S5","Gifting","Implemented","MAIN or cosmetics to friends.","community"],
  ["Social","S6","Lobby Chat","Implemented","Bot replies, mute, premium emoji.","community"],
  ["Social","S7","Clans","Implemented","Create, score, treasury.","community"],
  ["UX","UX1","Accessibility","Implemented","Contrast, motion, type scale, colour vision.","services"],
  ["UX","UX2","Dashboard","Implemented","Reorder Home KPI cards.","home"],
  ["UX","UX3","Presets","Implemented","Named stake presets, no auto-wager.","services"],
  ["UX","UX4","Discovery","Implemented","Explainable game recommendations.","home"],
  ["RG","RG1","Deposit Limits","Implemented","Daily / weekly / monthly top-up caps.","services"],
  ["RG","RG2","Session Limits","Implemented","Duration cool-off.","services"],
  ["RG","RG3","Self-exclusion","Implemented","Timed or permanent lock.","services"],
  ["RG","RG4","Reality Check","Implemented","Reminders and session P/L graph.","services"],
  ["Roadmap","LIVE1","Event Calendar","Suggested","Timezone-aware Cups and promos.",""],
  ["Roadmap","TRUST1","Identity & KYC","Suggested","Age gate and jurisdiction checks.",""]
];
