window.TM = window.TM || {};

const ZONES = {
  "0–63":[0,63], "64–127":[64,127], "128–191":[128,191], "192–255":[192,255],
  N:[0,63], E:[64,127], S:[128,191], W:[192,255],
  CRIMSON:[0,63], AMBER:[64,127], TEAL:[128,191], VIOLET:[192,255]
};

function handScore(cards) {
  const ranks = cards.slice().sort((a,b)=>b-a);
  const counts = {};
  ranks.forEach(r => counts[r] = (counts[r]||0)+1);
  const groups = Object.entries(counts).map(([r,c]) => [+r,c]).sort((a,b)=> b[1]-a[1] || b[0]-a[0]);
  const uniq = ranks.filter((v,i,a)=>a.indexOf(v)===i).sort((a,b)=>b-a);
  const isFlushish = false;
  let straight = false, highS = 0;
  const u = uniq.slice().sort((a,b)=>a-b);
  if (u.length >= 5) {
    for (let i=0;i<=u.length-5;i++){
      if (u[i+4]-u[i]===4) { straight = true; highS = u[i+4]; }
    }
    if (u.includes(14) && u.includes(2) && u.includes(3) && u.includes(4) && u.includes(5)) { straight = true; highS = 5; }
  }
  if (groups[0][1]===4) return [7, groups[0][0], groups[1][0]];
  if (groups[0][1]===3 && groups[1] && groups[1][1]>=2) return [6, groups[0][0], groups[1][0]];
  if (straight) return [4, highS];
  if (groups[0][1]===3) return [3, groups[0][0], ...uniq];
  if (groups[0][1]===2 && groups[1] && groups[1][1]===2) return [2, Math.max(groups[0][0],groups[1][0]), Math.min(groups[0][0],groups[1][0]), groups[2]?.[0]||0];
  if (groups[0][1]===2) return [1, groups[0][0], ...uniq];
  return [0, ...uniq];
}
function cmpScore(a,b){
  for (let i=0;i<Math.max(a.length,b.length);i++){
    const d = (a[i]||0)-(b[i]||0);
    if (d) return d;
  }
  return 0;
}
function diceHand(d){
  const s = d.slice().sort((a,b)=>b-a);
  const trip = s[0]===s[1] && s[1]===s[2];
  const pair = s[0]===s[1] || s[1]===s[2];
  const total = s[0]+s[1]+s[2];
  return [trip?2:pair?1:0, total, s[0]];
}

TM.resolveCatalog = (g, bytes, aPick, bPick) => {
  const F = TM.flips(bytes, 32);
  const b0 = bytes[0], b1 = bytes[1] ?? 0;
  const side = b0 % 2 === 0 ? "HEADS" : "TAILS";
  const decide = (condA, condB, splitOnBoth, carryOnNone, detail) => {
    if (condA && condB) return { winner: splitOnBoth ? "split" : "a", detail };
    if (condA) return { winner: "a", detail };
    if (condB) return { winner: "b", detail };
    return { winner: carryOnNone ? "carry" : "split", detail };
  };

  switch (g.id) {
    case "overunder": {
      const res = b0 >= 128 ? "HIGH" : "LOW";
      return { winner: aPick===res ? "a" : "b", detail: "Byte 0 = "+b0+" → "+res, values:{res,b0} };
    }
    case "speed": {
      const flips = TM.flips(bytes, 5);
      const h = flips.filter(x=>x==="H").length;
      const res = h >= 3 ? "HEADS" : "TAILS";
      return { winner: aPick===res?"a":"b", detail: flips.join(" ")+" · "+h+"H", values:{flips} };
    }
    case "tug": {
      let pos = 0, hit = null;
      const path = [];
      for (const by of bytes.slice(0, 24)) {
        pos += (by % 2 === 0) ? -1 : 1;
        path.push(pos);
        if (pos <= -3) { hit = "LEFT"; break; }
        if (pos >= 3) { hit = "RIGHT"; break; }
      }
      if (!hit) hit = pos < 0 ? "LEFT" : "RIGHT";
      return { winner: aPick===hit?"a":"b", detail: "Rope → "+hit+" (path "+path.slice(-6).join(",")+")", values:{path,hit} };
    }
    case "evenodd": {
      const sum = b0 + b1;
      const res = sum % 2 === 0 ? "EVEN" : "ODD";
      return { winner: aPick===res?"a":"b", detail: b0+" + "+b1+" = "+sum+" → "+res };
    }
    case "blind": {
      const matchA = aPick === side, matchB = bPick === side;
      if (aPick !== bPick) return { winner: matchA ? "a" : "b", detail: "Flip "+side };
      if (matchA) return { winner: "split", detail: "Both picked "+aPick+" and hit "+side };
      return { winner: "carry", detail: "Both picked "+aPick+", flip "+side };
    }
    case "chain": {
      for (let i=0;i<10;i++){
        const fl = bytes[i]%2===0 ? "HEADS":"TAILS";
        const call = i%2===0 ? aPick : bPick;
        if (call !== fl) return { winner: i%2===0 ? "b" : "a", detail: "Caller "+(i%2===0?"A":"B")+" missed "+fl+" on beat "+(i+1) };
      }
      return { winner: "split", detail: "Both survived 10 calls" };
    }
    case "ladder": {
      let h=0,t=0, n=0;
      for (const by of bytes) {
        n++;
        if (by%2===0) h++; else t++;
        if (h===3 || t===3) {
          const res = h===3?"HEADS":"TAILS";
          return { winner: aPick===res?"a":"b", detail: res+" reached rung 3 in "+n+" flips" };
        }
      }
      const res = h>t?"HEADS":"TAILS";
      return { winner: aPick===res?"a":"b", detail: "Window end "+h+"H "+t+"T" };
    }
    case "mirror": {
      const pc = b0%2===0?"HEADS":"TAILS";
      const bc = b1%2===0?"HEADS":"TAILS";
      if (pc === bc) return { winner: "carry", detail: "Both coins "+pc };
      const aHit = pc===aPick, bHit = bc===bPick;
      if (aHit && !bHit) return { winner:"a", detail:"Your coin "+pc+" matches "+aPick };
      if (bHit && !aHit) return { winner:"b", detail:"Their coin "+bc+" matches "+bPick };
      return { winner:"split", detail:"Mirror stalemate "+pc+" / "+bc };
    }
    case "rps": {
      const beat = {ROCK:"SCISSORS", PAPER:"ROCK", SCISSORS:"PAPER"};
      if (aPick===bPick) return { winner:"split", detail: aPick+" vs "+bPick };
      return { winner: beat[aPick]===bPick?"a":"b", detail: aPick+" vs "+bPick };
    }
    case "triple": {
      const flips = TM.flips(bytes, 3);
      const h = flips.filter(x=>x==="H").length;
      const res = h>=2?"HEADS":"TAILS";
      return { winner: aPick===res?"a":"b", detail: flips.join(" ")+" → "+res };
    }
    case "prime": {
      const n = (b0 % 250) + 2;
      const res = TM.isPrime(n) ? "PRIME" : "COMPOSITE";
      return { winner: aPick===res?"a":"b", detail: n+" is "+res };
    }
    case "streak": {
      let run = 1, cur = F[0];
      for (let i=1;i<F.length;i++){
        if (F[i]===cur) run++; else { cur=F[i]; run=1; }
        if (run>=4) {
          const res = cur==="H"?"HEADS":"TAILS";
          return { winner: aPick===res?"a":"b", detail: "Streak "+res+" at flip "+(i+1) };
        }
      }
      return { winner:"carry", detail:"No 4-streak in 32 flips" };
    }
    case "closest": {
      const da = Math.abs((+aPick) - b0), db = Math.abs((+bPick) - b0);
      if (da===db) return { winner:"split", detail:"Byte 0 = "+b0+" · both "+da+" away" };
      return { winner: da<db?"a":"b", detail:"Target "+b0+" · you "+da+" vs "+db };
    }
    case "lucky": {
      if (+aPick===b0) return { winner:"a", detail:"Exact hit "+b0 };
      if (+bPick===b0) return { winner:"b", detail:"Opponent exact "+b0 };
      const da = Math.abs((+aPick)-b0), db = Math.abs((+bPick)-b0);
      if (da===db) return { winner:"carry", detail:"Equal miss on "+b0 };
      return { winner: da<db?"a":"b", detail:"Closest to "+b0 };
    }
    case "sumpred": {
      const sum = b0+b1;
      const da = Math.abs((+aPick)-sum), db = Math.abs((+bPick)-sum);
      if (da===db) return { winner:"split", detail:"Sum "+sum };
      return { winner: da<db?"a":"b", detail:"Sum "+sum+" · Δ "+da+" vs "+db };
    }
    case "higher": {
      if (b0===b1) return { winner:"split", detail:b0+" vs "+b1 };
      return { winner: b0>b1?"a":"b", detail:"You "+b0+" · them "+b1 };
    }
    case "c21": {
      const ca = [bytes[0]%10+2, bytes[1]%10+2], cb = [bytes[2]%10+2, bytes[3]%10+2];
      const sa = ca[0]+ca[1], sb = cb[0]+cb[1];
      const score = s => s>21 ? 99 : 21-s;
      if ((sa>21 && sb>21) || sa===sb) return { winner:"split", detail: sa+" vs "+sb };
      return { winner: score(sa)<score(sb)?"a":"b", detail: ca.join("+")+"="+sa+" vs "+cb.join("+")+"="+sb };
    }
    case "dicesum": {
      const da = [bytes[0]%6+1, bytes[1]%6+1], db = [bytes[2]%6+1, bytes[3]%6+1];
      const sa = da[0]+da[1], sb = db[0]+db[1];
      if (sa===sb) return { winner:"split", detail: sa+" vs "+sb };
      return { winner: sa>sb?"a":"b", detail: da.join("+")+" vs "+db.join("+") };
    }
    case "median": {
      const vals = [+aPick, +bPick, b0].slice().sort((x,y)=>x-y);
      const med = vals[1];
      if (+aPick===med && +bPick!==med) return { winner:"a", detail:"Median "+med };
      if (+bPick===med && +aPick!==med) return { winner:"b", detail:"Median "+med };
      const da = Math.abs(+aPick-b0), db = Math.abs(+bPick-b0);
      if (da===db) return { winner:"split", detail:"Proof "+b0+" is median" };
      return { winner: da<db?"a":"b", detail:"Proof "+b0+" · nearest pick" };
    }
    case "mod4": {
      const r = String(b0 % 4);
      if (aPick===r) return { winner:"a", detail:b0+" mod 4 = "+r };
      if (bPick===r) return { winner:"b", detail:b0+" mod 4 = "+r };
      return { winner:"carry", detail:"Unclaimed remainder "+r };
    }
    case "threedice": {
      const da = [0,1,2].map(i=>bytes[i]%6+1), db = [3,4,5].map(i=>bytes[i]%6+1);
      const c = cmpScore(diceHand(da), diceHand(db));
      if (!c) return { winner:"split", detail: da.join("-")+" vs "+db.join("-") };
      return { winner: c>0?"a":"b", detail: da.join("-")+" vs "+db.join("-") };
    }
    case "lastdigit": {
      const n = b0*256 + b1;
      const d = String(n % 10);
      if (aPick===d) return { winner:"a", detail:n+" ends with "+d };
      if (bPick===d) return { winner:"b", detail:n+" ends with "+d };
      return { winner:"carry", detail:"Unclaimed digit "+d };
    }
    case "coinbal": {
      const heads = TM.flips(bytes,10).filter(x=>x==="H").length;
      const da = Math.abs(+aPick-heads), db = Math.abs(+bPick-heads);
      if (da===db) return { winner:"split", detail:heads+" HEADS" };
      return { winner: da<db?"a":"b", detail:heads+" HEADS · Δ "+da+" vs "+db };
    }
    case "pattern": {
      const seq = F.join("");
      let hitA = -1, hitB = -1;
      for (let i=0;i<=seq.length-3;i++){
        const w = seq.slice(i,i+3);
        if (hitA<0 && w===aPick) hitA=i;
        if (hitB<0 && w===bPick) hitB=i;
      }
      if (hitA<0 && hitB<0) return { winner:"carry", detail:"Neither pattern in 32 flips" };
      if (hitB<0 || (hitA>=0 && hitA<=hitB)) return { winner:"a", detail:aPick+" at "+hitA };
      return { winner:"b", detail:bPick+" at "+hitB };
    }
    case "parlay": {
      const flips = TM.flips(bytes,3).join("");
      const ca = [...aPick].filter((c,i)=>c===flips[i]).length;
      const cb = [...bPick].filter((c,i)=>c===flips[i]).length;
      if (ca===cb) return { winner:"carry", detail:flips+" · "+ca+"–"+cb };
      return { winner: ca>cb?"a":"b", detail:flips+" · "+ca+" vs "+cb };
    }
    case "pstreak": {
      const flips = TM.flips(bytes,5).join("");
      const ca = [...aPick].filter((c,i)=>c===flips[i]).length;
      const cb = [...bPick].filter((c,i)=>c===flips[i]).length;
      if (ca===cb) return { winner:"split", detail:flips+" · "+ca+"–"+cb };
      return { winner: ca>cb?"a":"b", detail:flips+" · "+ca+" vs "+cb };
    }
    case "rangewar":
    case "bullseye":
    case "colour": {
      const za = ZONES[aPick], zb = ZONES[bPick];
      const inA = za && b0>=za[0] && b0<=za[1];
      const inB = zb && b0>=zb[0] && b0<=zb[1];
      if (inA) return { winner:"a", detail:"Byte "+b0+" in "+aPick };
      if (inB) return { winner:"b", detail:"Byte "+b0+" in "+bPick };
      return { winner:"carry", detail:"Byte "+b0+" unclaimed" };
    }
    case "sequence": {
      const seq = F.join("");
      let hitA=-1, hitB=-1;
      for (let i=0;i<=seq.length-2;i++){
        const w = seq.slice(i,i+2);
        if (hitA<0 && w===aPick) hitA=i;
        if (hitB<0 && w===bPick) hitB=i;
      }
      if (hitA<0 && hitB<0) return { winner:"carry", detail:"No starter appeared" };
      if (hitB<0 || (hitA>=0 && hitA<=hitB)) return { winner:"a", detail:aPick+" first" };
      return { winner:"b", detail:bPick+" first" };
    }
    case "territory": {
      let na=0, nb=0;
      for (let i=0;i<9;i++){
        const sec = bytes[i] % 8;
        if (aPick==="NORTH" ? sec<4 : sec>=4) na++; else nb++;
      }
      if (na===0 && nb===0) return { winner:"carry", detail:"Empty board" };
      if (na===nb) return { winner:"split", detail:na+"–"+nb+" sectors" };
      return { winner: na>nb?"a":"b", detail: na+" vs "+nb+" sectors" };
    }
    case "binary": {
      const code = TM.flips(bytes,3).join("");
      const ham = (x,y) => [...x].filter((c,i)=>c!==y[i]).length;
      const da = ham(aPick, code), db = ham(bPick, code);
      if (da===db) return { winner:"split", detail:"Code "+code };
      return { winner: da<db?"a":"b", detail:"Code "+code+" · Hamming "+da+" vs "+db };
    }
    case "poker": {
      const ca = bytes.slice(0,5).map(TM.cardRank);
      const cb = bytes.slice(5,10).map(TM.cardRank);
      const c = cmpScore(handScore(ca), handScore(cb));
      const show = arr => arr.map(TM.rankName).join(" ");
      if (!c) return { winner:"split", detail: show(ca)+" vs "+show(cb) };
      return { winner: c>0?"a":"b", detail: show(ca)+" vs "+show(cb) };
    }
    default:
      return { winner: b0%2===0?"a":"b", detail:"Fallback parity" };
  }
};

TM.compatible = (g, aPick, bPick) => {
  if (!g.pick || g.pick.type === "none") return true;
  if (g.pick.type === "opposite") return aPick && bPick && aPick !== bPick;
  if (g.pick.type === "sameok") return !!aPick && !!bPick;
  return aPick !== "" && bPick !== "" && String(aPick) !== String(bPick);
};

TM.complement = (g, pick) => {
  if (!g.pick || g.pick.type === "none") return "";
  const list = g.pick.list || [];
  if (g.pick.type === "opposite" || g.id === "blind") {
    return list.find(x => x !== pick) || list[0];
  }
  const opts = list.filter(x => String(x) !== String(pick));
  if (opts.length) return TM.pick(opts);
  if (g.pick.type === "number") {
    let n;
    do { n = g.pick.min + Math.floor(Math.random() * (g.pick.max - g.pick.min + 1)); }
    while (String(n) === String(pick));
    return n;
  }
  return pick;
};

function feeOf(pot, rate){ return Math.round(pot * rate); }

TM.settleP2P = ({ kind, gameId, catalog, stake, a, b, aPick, bPick, proof, resolved, playerIsA }) => {
  const s = TM.S;
  const pot = stake * 2;
  const fee = feeOf(pot, s.config.fee);
  let net = pot - fee;
  const carryKey = catalog || "cointoss";
  const carry = s.carry[carryKey] || 0;
  if (resolved.winner !== "carry") {
    net += carry;
    s.carry[carryKey] = 0;
  }
  const jpAdd = Math.max(s.config.jpFloor || 0, Math.round(fee * s.config.jpFund));
  const houseFee = Math.max(0, fee - jpAdd);
  s.jackpot.pool += jpAdd;
  if (s.jackpot.pool >= s.config.jpArm) s.jackpot.armed = true;
  if (catalog) s.house.catalogFees += houseFee; else s.house.fees += houseFee;
  s.sinks += fee;

  let jackpotHit = 0;
  if (!catalog && proof.first === 0 && s.jackpot.armed) {
    jackpotHit = Math.round(s.jackpot.pool * s.config.jpPay);
    s.jackpot.pool -= jackpotHit;
    s.jackpot.armed = s.jackpot.pool >= s.config.jpArm;
    s.stats.jackpotHits++;
  }

  const pay = { a:0, b:0 };
  if (resolved.winner === "carry") {
    s.carry[carryKey] = (s.carry[carryKey]||0) + net;
  } else if (resolved.winner === "split") {
    pay.a = Math.floor(net/2);
    pay.b = net - pay.a;
  } else {
    pay[resolved.winner] = net;
  }

  const creditBot = (bot, n) => { if (bot) bot.bal += n; };
  if (a.kind === "bot") creditBot(a.ref, pay.a);
  if (b.kind === "bot") creditBot(b.ref, pay.b);

  let delta = 0, payout = 0, result = "lose";
  if (playerIsA) {
    payout = pay.a + (jackpotHit || 0);
    if (payout) TM.S.wallet.main += payout;
    delta = payout - stake;
    result = resolved.winner === "carry" ? "carry" : resolved.winner === "split" ? "split" : resolved.winner === "a" ? "win" : "lose";
    if (jackpotHit) {
      s.player.jackpots++;
      TM.feed("JACKPOT · +"+jackpotHit, "ok");
      TM.capPush(s.reviews, { t:Date.now(), why:"jackpot", amount:jackpotHit }, 40);
    }
    if (payout >= 400) TM.capPush(s.reviews, { t:Date.now(), why:"payout", amount:payout }, 40);
    TM.accrueRake(fee);
    TM.addXP(stake);
    if (!catalog) {
      if (proof.first % 2 === 0) s.stats.heads++; else s.stats.tails++;
    } else {
      s.player.catalogGames++;
      s.player.catalogPlayed[catalog] = true;
    }
    const rec = {
      t: Date.now(), kind: kind || (catalog?"catalog":"coin"), game: catalog || "cointoss",
      opp: b.name, stake, fee, payout, delta, result, detail: resolved.detail,
      aPick, bPick, proof, jackpotHit
    };
    TM.recordGame(rec);
    if (catalog) TM.capPush(s.catalogLog, rec, 100);
    TM.ledger("settle", delta, (catalog || "Coin Toss") + " · " + result);
    TM.feed((catalog ? TM.catalogById(catalog)?.name : "Coin Toss") + " · " + result.toUpperCase() + " · " + TM.delta(delta), result==="win"?"ok":"info");
  } else {
    // bot vs bot — only economy
  }
  return { fee, net, pay, jackpotHit, result, delta, payout };
};

TM.postCoin = async ({ side, stake, priv, taunt }) => {
  const err = TM.guard(stake);
  if (err) return { err };
  const plan = TM.planEscrow(stake);
  if (!plan) return { err: "MAIN cannot cover the remainder under the non-main cap." };
  TM.applyEscrow(plan);
  const rec = {
    id: TM.uid(), kind: "coin", side, stake, priv: !!priv, taunt: (taunt||"").slice(0,24),
    owner: "player", ownerName: TM.S.player.name, plan, t: Date.now()
  };
  TM.S.waiting.push(rec);
  TM.S.session.bets.push(Date.now());
  TM.save();
  if (!priv && TM.S.config.autoMatch) {
    setTimeout(() => { TM.takeWaiting(rec.id, "bot"); TM.refresh && TM.refresh(); }, TM.S.settings.instant ? 120 : 800);
  }
  return { ok: true, rec };
};

TM.postCatalog = async ({ gameId, pick, stake }) => {
  const g = TM.catalogById(gameId);
  if (!g) return { err: "Unknown game." };
  if (TM.S.waiting.some(w => w.kind==="catalog" && w.gameId===gameId && w.owner==="player"))
    return { err: "You already have an open bet in this game." };
  if (g.pick.type !== "none" && (pick===undefined || pick==="")) return { err: "Choose a pick." };
  const err = TM.guard(stake);
  if (err) return { err };
  const plan = TM.planEscrow(stake);
  if (!plan) return { err: "MAIN cannot cover the remainder under the non-main cap." };
  TM.applyEscrow(plan);
  const rec = {
    id: TM.uid(), kind:"catalog", gameId, pick, stake,
    owner:"player", ownerName: TM.S.player.name, plan, t: Date.now()
  };
  TM.S.waiting.push(rec);
  TM.S.session.bets.push(Date.now());
  TM.save();
  if (TM.S.config.autoMatch) {
    setTimeout(() => { TM.takeWaiting(rec.id, "bot"); TM.refresh && TM.refresh(); }, TM.S.settings.instant ? 80 : 500);
  }
  return { ok:true, rec };
};

TM.cancelWaiting = (id) => {
  const s = TM.S;
  const i = s.waiting.findIndex(w => w.id === id);
  if (i < 0) return { err: "Bet not found." };
  const w = s.waiting[i];
  if (w.owner === "player") TM.refund(w.plan);
  else if (w.owner === "bot") {
    const bot = TM.botById(w.botId);
    if (bot) bot.bal += w.stake;
  }
  s.waiting.splice(i, 1);
  TM.save();
  return { ok:true };
};

TM.takeWaiting = async (id, who) => {
  const s = TM.S;
  if (TM.busy.get()) { setTimeout(() => TM.takeWaiting(id, who), 180); return; }
  const i = s.waiting.findIndex(w => w.id === id);
  if (i < 0) return { err: "Gone." };
  const w = s.waiting[i];
  s.waiting.splice(i, 1);

  const bot = TM.pick(s.bots.filter(b => b.bal >= w.stake)) || s.bots[0];
  if (who === "bot") {
    if (!TM.botFund(bot, w.stake)) { s.waiting.push(w); return { err: "Bot cannot cover." }; }
  } else {
    const err = TM.guard(w.stake);
    if (err) { s.waiting.push(w); return { err }; }
    const plan = TM.planEscrow(w.stake);
    if (!plan) { s.waiting.push(w); return { err: "Cannot cover stake." }; }
    TM.applyEscrow(plan);
    w.takerPlan = plan;
  }

  const gameId = TM.uid();
  const catalog = w.kind === "catalog" ? w.gameId : null;
  const g = catalog ? TM.catalogById(catalog) : null;
  let aPick, bPick, a, b, playerIsA;
  if (w.owner === "player") {
    a = { kind:"player", name:s.player.name };
    b = { kind:"bot", name:bot.name, ref:bot };
    aPick = w.kind==="coin" ? w.side : w.pick;
    bPick = w.kind==="coin" ? (w.side==="HEADS"?"TAILS":"HEADS") : TM.complement(g, w.pick);
    playerIsA = true;
  } else {
    // player taking a bot post
    a = { kind:"bot", name: bot.name, ref: TM.botById(w.botId) || bot };
    b = { kind:"player", name:s.player.name };
    aPick = w.kind==="coin" ? w.side : w.pick;
    bPick = w.kind==="coin" ? (w.side==="HEADS"?"TAILS":"HEADS") : (who==="player" ? (w._takePick ?? TM.complement(g, w.pick)) : TM.complement(g, w.pick));
    playerIsA = false;
    // normalize so player is A for settlement math
    const tmp = { a, b, aPick, bPick };
    a = tmp.b; b = tmp.a; aPick = tmp.bPick; bPick = tmp.aPick;
    playerIsA = true;
    b.ref = TM.botById(w.botId) || bot;
  }

  const proof = await TM.proofBundle({
    makerSeed: TM.randHex(), takerSeed: TM.randHex(), serverSeed: TM.randHex(),
    gameId, stake: w.stake, makerSide: aPick, takerSide: bPick,
    catalog, pick: aPick, oppPick: bPick
  });
  proof.gameId = gameId;

  let resolved;
  if (w.kind === "coin") {
    const res = proof.first % 2 === 0 ? "HEADS" : "TAILS";
    resolved = { winner: aPick === res ? "a" : "b", detail: "First byte "+proof.first+" → "+res };
  } else {
    resolved = TM.resolveCatalog(g, proof.bytes, aPick, bPick);
  }

  const out = TM.settleP2P({
    kind: w.kind, gameId, catalog, stake: w.stake,
    a, b, aPick, bPick, proof, resolved, playerIsA
  });
  s.lastResult = {
    kind: w.kind, catalog, stake: w.stake, aPick, bPick, opp: b.name,
    resolved, proof, ...out, t: Date.now()
  };
  if (w.kind === "coin" && playerIsA) {
    s.x2 = { stake: Math.min(w.stake * 2, TM.maxStake(s)), from: w.stake, t: Date.now() + 10*60*1000, side: aPick };
  }
  TM.save();
  TM.sound(out.result === "win" ? "win" : out.result === "lose" ? "lose" : "flip");
  return { ok:true, out };
};

TM.postBotBet = (kind, gameId) => {
  const s = TM.S;
  const bot = TM.pick(s.bots) || s.bots[0];
  const stake = [10,20,50,100,150][Math.floor(Math.random()*5)];
  if (!TM.botFund(bot, stake)) return;
  if (kind === "coin") {
    s.waiting.push({
      id: TM.uid(), kind:"coin", side: Math.random()<.5?"HEADS":"TAILS",
      stake, priv:false, owner:"bot", ownerName: bot.name, botId: bot.id, t: Date.now()
    });
  } else {
    const g = TM.catalogById(gameId);
    if (!g) return;
    let pick = "";
    if (g.pick.type === "none") pick = "";
    else if (g.pick.type === "number") pick = g.pick.min + Math.floor(Math.random()*(g.pick.max-g.pick.min+1));
    else pick = TM.pick(g.pick.list);
    s.waiting.push({
      id: TM.uid(), kind:"catalog", gameId, pick, stake,
      owner:"bot", ownerName: bot.name, botId: bot.id, t: Date.now()
    });
  }
};

TM.botVsBotCoin = async () => TM.botVsBotCoinFast();

TM.botVsBotCoinFast = () => {
  const s = TM.S;
  if (s.bots.length < 2) return;
  const a = TM.pick(s.bots), b = TM.pick(s.bots.filter(x => x.id !== a.id));
  if (!b) return;
  const stake = [10,20,50,100][Math.floor(Math.random()*4)];
  if (!TM.botFund(a, stake) || !TM.botFund(b, stake)) return;
  const first = crypto.getRandomValues(new Uint8Array(1))[0];
  const pot = stake*2, fee = feeOf(pot, s.config.fee), net = pot - fee;
  const jpAdd = Math.max(s.config.jpFloor||0, Math.round(fee * s.config.jpFund));
  s.jackpot.pool += jpAdd;
  if (s.jackpot.pool >= s.config.jpArm) s.jackpot.armed = true;
  s.house.fees += Math.max(0, fee - jpAdd);
  s.sinks += fee;
  if (first % 2 === 0) { s.stats.heads++; a.bal += net; a.wins++; a.net += net-stake; b.losses++; b.net -= stake; }
  else { s.stats.tails++; b.bal += net; b.wins++; b.net += net-stake; a.losses++; a.net -= stake; }
  s.stats.total++;
  s.stats.coin = (s.stats.coin || 0) + 1;
};

TM.botVsBotCatalog = async (gameId) => TM.botVsBotCatalogFast(gameId);

TM.botVsBotCatalogFast = (gameId) => {
  const s = TM.S;
  const g = TM.catalogById(gameId || TM.pick(TM.CATALOG).id);
  if (s.bots.length < 2 || !g) return;
  const a = TM.pick(s.bots), b = TM.pick(s.bots.filter(x => x.id !== a.id));
  if (!b) return;
  const stake = [10,20,50][Math.floor(Math.random()*3)];
  if (!TM.botFund(a, stake) || !TM.botFund(b, stake)) return;
  let aPick="", bPick="";
  if (g.pick.type === "number") {
    aPick = g.pick.min + Math.floor(Math.random()*(g.pick.max-g.pick.min+1));
    bPick = TM.complement(g, aPick);
  } else if (g.pick.type !== "none") {
    aPick = TM.pick(g.pick.list);
    bPick = TM.complement(g, aPick);
  }
  const bytes = [...crypto.getRandomValues(new Uint8Array(32))];
  const resolved = TM.resolveCatalog(g, bytes, aPick, bPick);
  const pot = stake*2, fee = feeOf(pot, s.config.fee);
  let net = pot - fee;
  const ck = g.id;
  if (resolved.winner !== "carry") { net += (s.carry[ck]||0); s.carry[ck]=0; }
  else s.carry[ck] = (s.carry[ck]||0) + net;
  const jpAdd = Math.max(s.config.jpFloor||0, Math.round(fee * s.config.jpFund));
  s.jackpot.pool += jpAdd;
  s.house.catalogFees += Math.max(0, fee-jpAdd);
  s.sinks += fee;
  if (resolved.winner === "a") a.bal += net;
  else if (resolved.winner === "b") b.bal += net;
  else if (resolved.winner === "split") { a.bal += Math.floor(net/2); b.bal += net-Math.floor(net/2); }
  s.stats.total++;
  s.stats.catalog = (s.stats.catalog || 0) + 1;
};

TM.botArcadeFast = (gameId) => {
  const s = TM.S;
  const bot = TM.pick(s.bots);
  if (!bot) return;
  const stake = [10,20,50][Math.floor(Math.random()*3)];
  if (!TM.botFund(bot, stake)) return;
  bot._lastArcade = gameId || TM.pick(TM.ARCADE).id;
  s.house.shop += stake;
  s.sinks += stake;
  const mults = [0, 0, 0.5, 1, 1, 1.5, 2];
  const pay = Math.round(stake * TM.pick(mults));
  if (pay) { bot.bal += pay; s.taps += pay; s.house.promo += pay; }
  s.stats.total++;
  s.stats.arcade = (s.stats.arcade || 0) + 1;
};

TM.recordTopup = (entry) => {
  const s = TM.S;
  if (!s.topups) s.topups = TM.emptyTopups();
  TM.capPush(s.topups.log, entry, 200);
};

TM.botTopup = (bot, reason = "auto-liquidity") => {
  const s = TM.S;
  if (!bot) return null;
  if (s._lastTopBot === bot.id) return null;
  const trigger = bot.bal;
  const base = 400 + Math.floor(Math.random() * 1201);
  let bonus = 0;
  if (s.config.firstTopup && !bot.topups) bonus = Math.round(base * ((s.config.firstTopupPct || 50) / 100));
  const add = base + bonus;
  bot.bal += add;
  bot.topups = (bot.topups || 0) + 1;
  bot.topupTotal = (bot.topupTotal || 0) + add;
  s.taps += add;
  if (bonus) s.house.promo += bonus;
  if (!s.topups) s.topups = TM.emptyTopups();
  s.topups.bot.count++;
  s.topups.bot.base += base;
  s.topups.bot.bonus += bonus;
  s.topups.bot.total += add;
  s._lastTopBot = bot.id;
  TM.recordTopup({
    t: Date.now(), kind: "bot", who: bot.id, name: bot.name,
    base, bonus, total: add, reason, trigger, count: bot.topups
  });
  return { base, bonus, total: add };
};

TM.topupLowBots = () => {
  const s = TM.S;
  let n = 0, coins = 0;
  s._lastTopBot = null;
  s.bots.forEach(b => {
    if (b.bal < (s.config.botTopAt || 500)) {
      const r = TM.botTopup(b, "admin-batch");
      if (r) { n++; coins += r.total; s._lastTopBot = null; }
    }
  });
  TM.audit("Admin topped up " + n + " bots · " + coins + " coins");
  TM.save();
  return { n, coins };
};

TM.createCup = ({ format, entry, by }) => {
  const s = TM.S;
  const err = by==="player" ? TM.guard(entry) : null;
  if (err) return { err };
  if (by==="player") {
    const plan = TM.planEscrow(entry);
    if (!plan) return { err: "Cannot fund Cup entry." };
    TM.applyEscrow(plan);
  } else {
    const bot = TM.pick(s.bots) || s.bots[0];
    if (!TM.botFund(bot, entry)) return { err: "Bot cannot fund Cup." };
    by = bot;
  }
  const cup = {
    id: TM.uid(), format, entry, t: Date.now(),
    a: by==="player" || by==="You" ? { kind:"player", name:s.player.name } : { kind:"bot", id:by.id, name:by.name },
    b: null, status: "open"
  };
  s.cups.push(cup);
  if (cup.a.kind==="player") setTimeout(()=>TM.joinCup(cup.id, "bot"), 220);
  TM.save();
  return { ok:true, cup };
};

TM.joinCup = async (id, who) => {
  const s = TM.S;
  const cup = s.cups.find(c => c.id===id && !c.b);
  if (!cup) return { err:"Cup gone." };
  if (who==="player") {
    const err = TM.guard(cup.entry);
    if (err) return { err };
    const plan = TM.planEscrow(cup.entry);
    if (!plan) return { err:"Cannot fund entry." };
    TM.applyEscrow(plan);
    cup.b = { kind:"player", name:s.player.name };
  } else {
    const bot = TM.pick(s.bots) || s.bots[0];
    if (!TM.botFund(bot, cup.entry)) return { err:"Bot cannot join." };
    cup.b = { kind:"bot", id:bot.id, name:bot.name, ref:bot };
  }
  await TM.settleCup(cup);
  TM.save();
  return { ok:true };
};

TM.settleCup = async (cup) => {
  const s = TM.S;
  const need = { Bo3:2, Bo5:3, Bo7:4, Advantage:2 }[cup.format] || 2;
  const cap = { Bo3:3, Bo5:5, Bo7:7, Advantage:9 }[cup.format] || 3;
  let a=0,b=0, flips=[];
  const seed = TM.randHex();
  for (let i=0;i<cap;i++){
    const h = await TM.sha256(seed+":"+cup.id+":"+i);
    const side = parseInt(h.slice(0,2),16)%2===0 ? "H":"T";
    flips.push(side);
    if (side==="H") a++; else b++;
    if (cup.format==="Advantage") {
      if (i>=2 && Math.abs(a-b)>=2) break;
    } else if (a>=need || b>=need) break;
  }
  const pot = cup.entry*2, rake = feeOf(pot, s.config.cupRake), net = pot-rake;
  s.house.cupRake += rake; s.sinks += rake;
  const awin = a>b;
  cup.status = "done"; cup.score = a+"–"+b; cup.flips = flips; cup.winner = awin ? cup.a.name : cup.b.name;
  const pay = (ent, won) => {
    if (ent.kind==="bot") {
      const bot = TM.botById(ent.id) || ent.ref;
      if (bot && won) bot.bal += net;
    } else if (ent.kind==="player") {
      s.player.cupPlays++;
      s.player.qCups = (s.player.qCups||0)+1;
      if (won) {
        s.wallet.main += net;
        s.player.cupWins++;
        TM.recordGame({ t:Date.now(), kind:"cup", game:cup.format, opp: (awin?cup.b:cup.a).name, stake:cup.entry, fee:rake, payout:net, delta:net-cup.entry, result:"win", detail:cup.score });
      } else {
        TM.recordGame({ t:Date.now(), kind:"cup", game:cup.format, opp: (awin?cup.b:cup.a).name, stake:cup.entry, fee:rake, payout:0, delta:-cup.entry, result:"lose", detail:cup.score });
      }
      TM.addXP(cup.entry);
    }
  };
  pay(cup.a, awin); pay(cup.b, !awin);
  if (cup.a.kind !== "player" && cup.b.kind !== "player") {
    s.stats.total++;
    s.stats.cups = (s.stats.cups || 0) + 1;
  }
  TM.feed("Cup "+cup.format+" · "+cup.winner+" "+cup.score, "ok");
};

TM.createTrny = ({ size, entry, format, auto }) => {
  const s = TM.S;
  const tr = {
    id: TM.uid(), size, entry, format: format || "single", t: Date.now(),
    seats: [], status: "open", champ: null, runner: null
  };
  s.trnys.unshift(tr);
  // fill all but one
  const bots = TM.shuffle(s.bots).slice(0, size-1);
  bots.forEach(bot => {
    if (bot.bal < entry) TM.botTopup(bot);
    bot.bal -= entry;
    tr.seats.push({ kind:"bot", id:bot.id, name:bot.name });
  });
  setTimeout(() => TM.closeTrny(tr.id), 4500);
  TM.save();
  return tr;
};

TM.joinTrny = (id) => {
  const s = TM.S;
  const tr = s.trnys.find(t => t.id===id && t.status==="open");
  if (!tr) return { err:"Closed." };
  if (tr.seats.some(x=>x.kind==="player")) return { err:"Already in." };
  let cost = tr.entry;
  const vip = TM.vip(s);
  if (vip.name==="Diamond") cost = Math.round(cost*.95);
  if (vip.name==="Black Diamond" || vip.name==="Royal") cost = Math.round(cost*.90);
  if (vip.name==="Legend") cost = Math.round(cost*.85);
  const err = TM.guard(cost);
  if (err) return { err };
  const plan = TM.planEscrow(cost);
  if (!plan) return { err:"Cannot fund entry." };
  TM.applyEscrow(plan);
  tr.seats.push({ kind:"player", name:s.player.name });
  s.player.trnyPlays++;
  TM.save();
  return { ok:true };
};

TM.closeTrny = async (id) => {
  const s = TM.S;
  const tr = s.trnys.find(t => t.id===id);
  if (!tr || tr.status!=="open") return;
  while (tr.seats.length < tr.size) {
    const bot = TM.pick(s.bots);
    if (!TM.botFund(bot, tr.entry)) { TM.botTopup(bot, "trny-topup"); if (!TM.botFund(bot, tr.entry)) continue; }
    tr.seats.push({ kind:"bot", id:bot.id, name:bot.name });
  }
  tr.status = "live";
  let field = TM.shuffle(tr.seats);
  const seed = TM.randHex();
  let nonce = 0;
  const playMatch = async (p, q) => {
    let pw=0, qw=0, need = tr.format==="Bo3"?2:1, cap = tr.format==="Bo3"?3:1;
    for (let i=0;i<cap;i++){
      const h = await TM.sha256(seed+":"+tr.id+":"+(nonce++));
      if (parseInt(h.slice(0,2),16)%2===0) pw++; else qw++;
      if (pw>=need || qw>=need) break;
    }
    return pw>=qw ? p : q;
  };
  while (field.length > 1) {
    const next = [];
    for (let i=0;i<field.length;i+=2){
      if (!field[i+1]) { next.push(field[i]); continue; }
      next.push(await playMatch(field[i], field[i+1]));
    }
    if (field.length===2) tr.runner = field[0]===next[0] ? field[1] : field[0];
    field = next;
  }
  tr.champ = field[0];
  tr.status = "done";
  const pool = tr.size * tr.entry;
  const rake = feeOf(pool, s.config.trnyRake);
  s.house.trnyRake += rake; s.sinks += rake;
  const rest = pool - rake;
  const cPay = Math.round(rest * .75), rPay = rest - cPay;
  const payEnt = (ent, n, place) => {
    if (!ent) return;
    if (ent.kind==="bot") {
      const bot = TM.botById(ent.id);
      if (bot) { bot.bal += n; if (place===1) bot.wins++; }
    } else {
      s.wallet.main += n;
      if (place===1) {
        s.player.trnyWins++;
        TM.recordGame({ t:Date.now(), kind:"trny", game:tr.format, opp:"bracket", stake:tr.entry, fee:rake, payout:n, delta:n-tr.entry, result:"win", detail:"Champion" });
      } else {
        TM.recordGame({ t:Date.now(), kind:"trny", game:tr.format, opp:"bracket", stake:tr.entry, fee:rake, payout:n, delta:n-tr.entry, result:"split", detail:"Runner-up" });
      }
    }
  };
  payEnt(tr.champ, cPay, 1);
  payEnt(tr.runner, rPay, 2);
  if (!tr.seats.some(x => x.kind === "player")) {
    s.stats.total++;
    s.stats.trnys = (s.stats.trnys || 0) + 1;
  }
  TM.feed("Tournament · "+tr.champ.name+" champion", "ok");
  TM.save();
  TM.refresh && TM.refresh();
};

TM.playArcade = async (id, opts = {}) => {
  const s = TM.S;
  const g = TM.arcadeById(id);
  if (!g) return { err:"Unknown Arcade game." };
  let stake = opts.stake ?? 50;
  if (id === "wheel" && opts.free) stake = 0;
  if (id === "raffle") stake = 10;
  if (id === "scratch") stake = opts.stake || 25;
  const err = stake ? TM.guard(stake) : TM.guard(null);
  if (err) return { err };
  if (stake) {
    if (!TM.debitMain(stake, g.name+" stake")) return { err:"MAIN only for Arcade stakes." };
    s.house.shop += stake; s.sinks += stake;
  }
  const proof = await TM.sha256(TM.randHex()+":"+id+":"+Date.now());
  const bytes = TM.bytes(proof);
  let payout = 0, detail = "", extra = {};

  const payx = m => Math.round(stake * m);

  switch (id) {
    case "wheel": {
      if (opts.free) {
        if (s.feature.wheelDay === new Date().toDateString()) return { err:"Free spin already used today." };
        s.feature.wheelDay = new Date().toDateString();
        stake = 50;
      }
      const slots = [0,25,50,100,200,0,75,500];
      const hit = slots[bytes[0] % slots.length];
      payout = hit;
      detail = "Landed on "+hit;
      break;
    }
    case "scratch": {
      const symbols = ["★","●","◆","▲","♦"];
      const cells = bytes.slice(0,9).map(b => symbols[b%symbols.length]);
      extra.cells = cells;
      const counts = {};
      cells.forEach(c => counts[c]=(counts[c]||0)+1);
      const best = Math.max(...Object.values(counts));
      const mult = best>=5?8:best>=4?4:best>=3?2:0;
      payout = payx(mult);
      detail = "Best match "+best+" · "+mult+"×";
      break;
    }
    case "dice": {
      const d1 = bytes[0]%6+1, d2 = bytes[1]%6+1, sum = d1+d2;
      extra.dice = [d1,d2];
      const mode = opts.mode || "HIGH";
      if (mode==="DOUBLE") payout = d1===d2 ? payx(30) : 0;
      else if (mode==="LOW") payout = sum<=6 ? Math.round(stake*1.8) : 0;
      else payout = sum>=8 ? Math.round(stake*1.8) : 0;
      detail = d1+"+"+d2+"="+sum+" · "+mode;
      break;
    }
    case "plinko": {
      const slots = [0,.5,1,2,5,2,1,.5,0];
      let pos = 4;
      for (let i=0;i<8;i++) pos += bytes[i]%2===0 ? -1 : 1;
      pos = TM.clamp(pos, 0, 8);
      payout = payx(slots[pos]);
      extra.slot = pos;
      detail = "Slot "+pos+" · "+slots[pos]+"×";
      break;
    }
    case "slots": {
      const reels = [bytes[0]%8, bytes[1]%8, bytes[2]%8];
      extra.reels = reels;
      let m = 0;
      if (reels[0]===reels[1] && reels[1]===reels[2]) m = reels[0]===7 ? 10 : 5;
      else if (reels[0]===reels[1] || reels[1]===reels[2] || reels[0]===reels[2]) m = 2;
      payout = payx(m);
      detail = reels.join(" · ")+" → "+m+"×";
      break;
    }
    case "dropball": {
      const pockets = [0,.5,1,3,1,.5,0];
      let col = TM.clamp(+(opts.col||4),1,7) - 1;
      for (let i=0;i<7;i++) col = TM.clamp(col + (bytes[i]%2?1:-1), 0, 6);
      payout = payx(pockets[col]);
      detail = "Pocket "+(col+1)+" · "+pockets[col]+"×";
      break;
    }
    case "pusher": {
      const tray = [0,.5,1,2,3,6,0,1];
      const hit = tray[bytes[4] % tray.length];
      payout = payx(hit);
      detail = "Tray "+hit+"× after 5 drops";
      break;
    }
    case "tower": {
      const floor = +opts.floor || 3;
      const need = floor;
      let ok = true;
      for (let i=0;i<need;i++) if (bytes[i] < 50) ok = false;
      const m = floor===7?7:floor===5?3:1.6;
      payout = ok ? payx(m) : 0;
      detail = ok ? "Cleared floor "+floor : "Busted on the climb";
      break;
    }
    case "ladder": {
      const rung = TM.clamp(+opts.rung || 3, 1, 8);
      let survive = 0;
      for (let i=0;i<rung;i++) { if (bytes[i] > 70) survive++; else break; }
      const botR = 1 + (bytes[8]%6);
      if (survive > botR) payout = stake*2;
      else if (survive === botR) payout = stake;
      else payout = 0;
      detail = "You rung "+survive+" vs bot "+botR;
      // P2P pot accounting: opponent is a bot
      break;
    }
    case "war": {
      const you = TM.cardRank(bytes[0]), them = TM.cardRank(bytes[1]);
      extra.cards = [you, them];
      if (you===them) {
        const y2 = TM.cardRank(bytes[2]), t2 = TM.cardRank(bytes[3]);
        payout = y2>=t2 ? stake*2 : 0;
        if (y2===t2) payout = stake;
        detail = "War "+TM.rankName(you)+" → "+TM.rankName(y2)+" vs "+TM.rankName(t2);
      } else {
        payout = you>them ? stake*2 : 0;
        detail = TM.rankName(you)+" vs "+TM.rankName(them);
      }
      break;
    }
    case "keno": {
      const picks = (opts.picks || []).map(Number).slice(0,5);
      if (picks.length !== 5) return { err:"Pick five distinct numbers 1–20." };
      if (new Set(picks).size !== 5 || picks.some(n=>n<1||n>20)) return { err:"Invalid Keno card." };
      const draw = [];
      let i=0;
      while (draw.length<5) {
        const n = (bytes[i++ % bytes.length] % 20) + 1;
        if (!draw.includes(n)) draw.push(n);
      }
      extra.draw = draw;
      const hits = picks.filter(n => draw.includes(n)).length;
      const m = {2:.5,3:1.5,4:5,5:20}[hits] || 0;
      payout = payx(m);
      detail = hits+" hits · "+m+"×";
      break;
    }
    case "bingo": {
      const card = bytes.slice(0,9).map((b,i)=> (b%20)+1+i);
      extra.card = card;
      const draw = [];
      let i=9;
      while (draw.length<6) { const n = (bytes[i++%bytes.length]%40)+1; if (!draw.includes(n)) draw.push(n); }
      extra.draw = draw;
      const mark = card.map(n => draw.includes(n));
      const lines = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
      const bingo = lines.some(L => L.every(i => mark[i]));
      payout = bingo ? payx(3) : 0;
      detail = bingo ? "Line complete" : "No line";
      break;
    }
    case "treasure": {
      const tile = TM.clamp(+opts.tile||1,1,9)-1;
      const kinds = ["trap","coin","coin","chest","gem","key","crown","trap","coin"];
      const map = TM.shuffle(kinds);
      extra.map = map;
      const hit = map[tile];
      const m = {trap:0, coin:1, chest:2, gem:3, key:4, crown:5}[hit];
      payout = payx(m);
      detail = hit+" · "+m+"×";
      break;
    }
    case "memory": {
      const pairs = 1 + (bytes[0] % 6);
      const m = pairs>=5?8:pairs===4?4:pairs===3?2:pairs>=2?1:0;
      payout = payx(m);
      detail = pairs+" pairs in 8 moves · "+m+"×";
      break;
    }
    case "penalty": {
      const dirs = ["LEFT","CENTER","RIGHT"];
      const shot = opts.dir || "CENTER";
      let goals = 0;
      for (let i=0;i<5;i++){
        const keep = dirs[bytes[i]%3];
        if (keep !== shot) goals++;
      }
      const m = goals>=5?8:goals===4?3:goals===3?1.5:0;
      payout = payx(m);
      detail = goals+" goals · "+m+"×";
      break;
    }
    case "match3": {
      let matches = 0;
      for (let i=0;i<25;i++) if (bytes[i]%6 === bytes[(i+1)%25]%6 && bytes[i]%6 === bytes[(i+2)%25]%6) matches++;
      const m = matches>=6?10:matches>=4?4:matches>=2?1.5:0;
      payout = payx(m);
      detail = matches+" lines · "+m+"×";
      break;
    }
    case "vault": {
      const key = TM.clamp(+opts.key||1,1,5);
      const win = (bytes[0]%5)+1;
      payout = key===win ? payx(4.5) : 0;
      detail = "Winning key "+win;
      extra.win = win;
      break;
    }
    case "raffle": {
      const pool = 10 * (8 + (bytes[1]%12));
      const house = Math.round(pool * .2);
      payout = bytes[0] < 40 ? pool - house : 0;
      if (payout) { s.house.fees += house; } else { s.house.fees += 10; }
      detail = payout ? "Ticket drawn · pot "+pool : "Not this draw";
      break;
    }
    case "trivia": {
      if (s.feature.triviaDay === new Date().toDateString()) return { err:"Already attempted today's trivia." };
      s.feature.triviaDay = new Date().toDateString();
      const q = TM.TRIVIA[bytes[0] % TM.TRIVIA.length];
      extra.q = q;
      const choice = +opts.choice;
      const correct = choice === q.ok;
      payout = correct ? payx(3) : 0;
      detail = correct ? "Correct" : "Answer was "+q.a[q.ok];
      extra.correct = correct;
      break;
    }
    case "fishing": {
      const bait = opts.bait || "Basic";
      const roll = bytes[0];
      let rarity = "common";
      const bias = bait==="Legend"?40:bait==="Shiny"?20:0;
      if (roll+bias > 240) rarity = "legend";
      else if (roll+bias > 190) rarity = "rare";
      else if (roll+bias > 120) rarity = "uncommon";
      s.feature.fish[rarity] = (s.feature.fish[rarity]||0)+1;
      const m = {common:.5, uncommon:1.2, rare:3, legend:10}[rarity];
      payout = payx(m);
      detail = bait+" bait · "+rarity+" · "+m+"×";
      break;
    }
  }

  if (payout) {
    s.wallet.main += payout;
    s.taps += payout;
    s.house.promo += payout;
  }
  const delta = payout - (opts.free ? 0 : stake);
  s.player.arcadeGames++;
  const rec = { t:Date.now(), kind:"arcade", game:id, stake: opts.free?0:stake, payout, delta, result: delta>0?"win":delta===0?"split":"lose", detail, proof, extra };
  TM.recordGame(rec);
  TM.capPush(s.arcadeLog, rec, 100);
  TM.addXP(Math.max(10, stake||10));
  TM.save();
  TM.sound(delta>0?"win":"flip");
  return { ok:true, rec };
};

TM.buyItem = (id) => {
  const s = TM.S;
  const it = TM.shopById(id);
  if (!it) return { err:"Unknown item." };
  if (s.player.owned.includes(id)) {
    s.player.equip[it.cat] = id;
    if (it.cat==="themes") TM.applyTheme();
    TM.save();
    return { ok:true, equipped:true };
  }
  if (it.vip && TM.vip(s).id !== it.vip && TM.vipIndex(s) < TM.VIP.findIndex(v=>v.id===it.vip))
    return { err:"Requires "+it.vip+" VIP." };
  let price = it.price;
  price = Math.round(price * (1 - (TM.vip(s).shop||0)/100));
  if (price && !TM.debitMain(price, "Shop · "+it.name)) return { err:"Need "+price+" MAIN." };
  if (price) { s.house.shop += price; s.sinks += price; }
  s.player.owned.push(id);
  s.player.equip[it.cat] = id;
  if (it.cat==="themes") TM.applyTheme();
  TM.feed("Bought "+it.name, "ok");
  TM.checkAchievements();
  TM.save();
  return { ok:true };
};

TM.transferTo = (botId, amount) => {
  const s = TM.S;
  amount = Math.round(+amount);
  if (amount < s.config.xferMin) return { err:"Minimum transfer is "+s.config.xferMin+"." };
  const today = s.ledger.filter(l => l.type==="transfer" && Date.now()-l.t < 86400000).reduce((a,l)=>a+Math.abs(l.delta),0);
  if (today + amount > s.config.xferCap) return { err:"Daily transfer cap reached." };
  const fee = Math.max(1, Math.round(amount * s.config.xferFee));
  if (!TM.debitMain(amount, "Transfer")) return { err:"Not enough MAIN." };
  const bot = TM.botById(botId);
  if (!bot) return { err:"Player not found." };
  bot.bal += amount - fee;
  s.house.transfers += fee; s.sinks += fee;
  s.player.transfers++;
  TM.capPush(s.botTransfers, { t:Date.now(), from:s.player.name, to:bot.name, amount, fee }, 100);
  TM.checkAchievements();
  TM.save();
  return { ok:true };
};

TM.topup = (amount) => {
  const s = TM.S;
  amount = Math.round(+amount);
  if (amount < 100) return { err:"Minimum top-up is 100." };
  const rg = s.settings.rg;
  const addUsed = n => { rg.usedDay+=n; rg.usedWeek+=n; rg.usedMonth+=n; };
  if (rg.depDay && rg.usedDay+amount > rg.depDay) return { err:"Daily deposit limit." };
  if (rg.depWeek && rg.usedWeek+amount > rg.depWeek) return { err:"Weekly deposit limit." };
  if (rg.depMonth && rg.usedMonth+amount > rg.depMonth) return { err:"Monthly deposit limit." };
  s.wallet.main += amount;
  s.taps += amount;
  addUsed(amount);
  let bonus = 0;
  if (s.config.firstTopup && !s.player.claimedFirstTopup) {
    bonus = Math.round(amount * .5);
    s.wallet.bonus += bonus;
    s.taps += bonus;
    s.house.promo += bonus;
    s.player.claimedFirstTopup = true;
  }
  TM.ledger("topup", amount, "Play-coin top-up"+(bonus?" +"+bonus+" BONUS":""));
  TM.audit("Player top-up "+amount);
  TM.save();
  return { ok:true, bonus };
};

TM.claimRake = () => {
  const s = TM.S;
  const n = s.player.pendingRake;
  if (!n) return { err:"Nothing to claim." };
  s.player.pendingRake = 0;
  s.wallet.rakeback += n;
  TM.ledger("rakeback", n, "VIP rakeback claimed");
  TM.save();
  return { ok:true, n };
};

TM.claimQuest = (id) => {
  const s = TM.S;
  const q = TM.QUESTS.find(x=>x.id===id);
  if (!q) return { err:"Unknown quest." };
  if (s.player.claimedQ && s.player.claimedQ[id]) return { err:"Already claimed." };
  if ((s.player[q.key]||0) < q.target) return { err:"Not complete." };
  s.player.claimedQ = s.player.claimedQ || {};
  s.player.claimedQ[id] = true;
  s.wallet.bonus += q.reward;
  s.taps += q.reward;
  TM.save();
  return { ok:true };
};

TM.park = (n) => {
  n = Math.round(+n);
  if (n < 1 || TM.S.wallet.main < n) return { err:"Not enough MAIN." };
  TM.S.wallet.main -= n; TM.S.wallet.bank += n;
  TM.ledger("bank", -n, "Parked to BANK");
  TM.save(); return { ok:true };
};
TM.unpark = (n) => {
  n = Math.round(+n);
  if (n < 1 || TM.S.wallet.bank < n) return { err:"Not enough BANK." };
  TM.S.wallet.bank -= n; TM.S.wallet.main += n;
  TM.ledger("bank", n, "Returned from BANK");
  TM.save(); return { ok:true };
};

TM.verifyProof = async ({ serverSeed, makerHash, takerHash, gameId }) => {
  if (!serverSeed || !makerHash || !takerHash || !gameId) return { err:"Need all four values." };
  const commit = await TM.sha256(serverSeed);
  const combined = (BigInt("0x"+makerHash) + BigInt("0x"+takerHash) + BigInt("0x"+commit)).toString(16);
  const finalHash = await TM.sha256(combined+":"+gameId);
  const first = parseInt(finalHash.slice(0,2),16);
  return {
    commit, combined, finalHash, first,
    result: first%2===0 ? "HEADS" : "TAILS",
    jackpot: first===0
  };
};

TM.requestBotWithdraw = (bot) => {
  const s = TM.S;
  if (!bot) return null;
  const lo = s.config.wdMin || 3000;
  const hi = Math.max(lo, s.config.wdMax || 5000);
  if (!bot.withdrawAt) bot.withdrawAt = lo + Math.floor(Math.random() * (hi - lo + 1));
  if ((bot.bal || 0) < bot.withdrawAt) return null;
  if (bot.wdCool && Date.now() < bot.wdCool) return null;
  const keep = 400 + Math.floor(Math.random() * 800);
  let amount = Math.floor((bot.bal - keep) / 50) * 50;
  if (amount < 500) return null;
  bot.bal -= amount;
  s.house.withdrawals = (s.house.withdrawals || 0) + amount;
  s.sinks += amount;
  if (!s.withdrawals) s.withdrawals = { count: 0, amount: 0, log: [] };
  s.withdrawals.count++;
  s.withdrawals.amount += amount;
  bot.withdraws = (bot.withdraws || 0) + 1;
  bot.withdrawTotal = (bot.withdrawTotal || 0) + amount;
  bot.withdrawAt = lo + Math.floor(Math.random() * (hi - lo + 1));
  bot.wdCool = Date.now() + 20000;
  TM.capPush(s.withdrawals.log, {
    t: Date.now(), botId: bot.id, name: bot.name,
    amount, keep: bot.bal, trigger: bot.withdrawAt, status: "paid"
  }, 200);
  TM.feed(bot.name + " withdrew " + amount + " MAIN · revenue −" + amount, "info");
  return { amount };
};

TM.processBotWithdrawals = () => {
  let n = 0, coins = 0;
  (TM.S.bots || []).forEach(b => {
    const r = TM.requestBotWithdraw(b);
    if (r) { n++; coins += r.amount; }
  });
  return { n, coins };
};

TM.botShopTick = () => {
  const s = TM.S;
  const paid = TM.SHOP.filter(x => x.price > 0 && !x.vip);
  for (let i = 0; i < 3; i++) {
    const bot = TM.pick(s.bots);
    const it = TM.pick(paid);
    if (!bot || !it) continue;
    if (bot.bal < it.price) TM.botTopup(bot, "shop-topup");
    if (bot.bal < it.price) continue;
    bot.bal -= it.price;
    bot.skin = it.cat === "skins" ? it.id : bot.skin;
    s.house.shop += it.price;
    s.sinks += it.price;
  }
};

TM.botEconomyTick = () => {
  const s = TM.S;
  s.trade = s.trade || [];
  const bot = TM.pick(s.bots);
  if (!bot) return;
  const roll = Math.random();
  if (roll < .18 && bot.bal >= 75) {
    const price = TM.pick([75, 200, 500]);
    if (bot.bal >= price) { bot.bal -= price; s.house.shop += price; s.sinks += price; }
  } else if (roll < .32 && bot.bal >= 100) {
    const n = 100;
    bot.bal -= n;
    bot.staked = (bot.staked || 0) + n;
  } else if (roll < .44 && (bot.staked || 0) >= 100) {
    const n = 100;
    bot.staked -= n; bot.bal += n + Math.round(n * .01);
  } else if (roll < .56 && bot.bal >= 100) {
    bot.bal -= 100; s.house.shop += 100; s.sinks += 100; bot.tickets = (bot.tickets || 0) + 1;
  } else if (roll < .68 && bot.bal >= 150) {
    bot.bal -= 150; s.house.shop += 150; s.sinks += 150;
  } else if (roll < .8 && bot.bal >= 50) {
    bot.bal -= 50; s.sinks += 50;
    s.social.clan = s.social.clan || { name: "Table Club", treasury: 0, members: [] };
    s.social.clan.treasury += 50;
  } else if (bot.bal >= 200) {
    const p = TM.pick([200, 500, 1000]);
    if (bot.bal >= p) { bot.bal -= p; s.house.shop += p; s.sinks += p; bot.roomTier = p === 1000 ? "cosmic" : p === 500 ? "royal" : "neon"; }
  }
  if (s.trade.length < 6) {
    const it = TM.pick(TM.SHOP.filter(x => x.price > 0));
    if (it) s.trade.push({ id: it.id, name: it.name, price: Math.max(25, Math.round(it.price * .85)), bot: true });
  }
};

TM.botSocialTick = () => {
  const s = TM.S;
  const a = TM.pick(s.bots), b = TM.pick(s.bots.filter(x => x.id !== a?.id));
  if (!a) return;
  s.social.friends = s.social.friends || [];
  if (Math.random() < .45 && b && !s.social.friends.includes(a.id)) {
    /* bot-bot friendship bookkeeping on the bot */
    a.pals = a.pals || [];
    if (!a.pals.includes(b.id)) a.pals.push(b.id);
  }
  if (Math.random() < .35 && s.social.friends.length < 20 && !s.social.friends.includes(a.id)) {
    s.social.friends.push(a.id);
  }
  s.social.chat.push({
    t: Date.now(),
    from: a.name,
    text: TM.pick([
      "Queue looks spicy.","Taking HIGH on Over/Under.","Arcade Plinko hit.","Catalog carry is fat.",
      "Anyone for Bo3?","Just topped MAIN.","Shop neon is live.","Referral landed.",
      "Staking another 100.","Gift incoming.","Room is open.","gg last flip"
    ])
  });
  if (s.social.chat.length > 50) s.social.chat.splice(0, s.social.chat.length - 50);
  if (Math.random() < .35 && b && a.bal >= 50) {
    const amt = TM.pick([50, 100]);
    if (a.bal > amt) {
      const fee = Math.max(1, Math.round(amt * s.config.xferFee));
      a.bal -= amt; b.bal += amt - fee;
      s.house.transfers += fee;
      TM.capPush(s.botTransfers, { t: Date.now(), from: a.name, to: b.name, amount: amt, fee }, 100);
    }
  }
  if (Math.random() < .3) {
    s.rooms = s.rooms || [];
    if (s.rooms.length < 8) {
      s.rooms.push({
        name: a.name + "'s table",
        game: Math.random() < .5 ? "cointoss" : TM.pick(TM.CATALOG).id,
        min: 10, max: 200, code: TM.uid().slice(0, 6).toUpperCase(),
        tier: a.roomTier || "basic", host: a.name
      });
    }
  }
  if (!s.social.clan && Math.random() < .2) {
    s.social.clan = { name: TM.pick(["Night Desk","Coin Circle","Flip House"]), treasury: 0, members: [a.name] };
  }
};

let _tickLock = false;
TM.botTick = async () => {
  if (_tickLock || !TM.S || !TM.S.config.botsOn) return;
  _tickLock = true;
  const turbo = TM.S.settings.turbo || 1;
  const extra = turbo === 1 ? 0 : turbo === 20 ? 40 : turbo === 100 ? 80 : 120;
  try {
    for (let i = 0; i < 50 + extra; i++) {
      TM.botVsBotCoinFast();
      if (i && i % 80 === 0) await new Promise(r => setTimeout(r, 0));
    }
    TM.CATALOG.forEach(g => {
      TM.botVsBotCatalogFast(g.id);
      if (Math.random() < .4) TM.postBotBet("catalog", g.id);
    });
    TM.ARCADE.forEach(g => TM.botArcadeFast(g.id));
    TM.botShopTick();
    TM.botEconomyTick();
    TM.botSocialTick();
    if (Math.random() < .9) TM.postBotBet("coin");
    if (Math.random() < .85) TM.postBotBet("coin");
    // auto-match aging bot bets
    const aged = TM.S.waiting.filter(w => w.owner==="bot" && Date.now()-w.t > 1800);
    for (const w of aged.slice(0, turbo>=20?8:3)) {
      const g = w.kind==="catalog" ? TM.catalogById(w.gameId) : null;
      const other = TM.pick(TM.S.bots.filter(b=>b.id!==w.botId && b.bal>=w.stake));
      if (!other) continue;
      TM.S.waiting = TM.S.waiting.filter(x=>x.id!==w.id);
      other.bal -= w.stake;
      if (w.kind==="coin") {
        const proof = await TM.proofBundle({
          makerSeed:TM.randHex(8), takerSeed:TM.randHex(8), serverSeed:TM.randHex(8),
          gameId:TM.uid(), stake:w.stake, makerSide:w.side, takerSide:w.side==="HEADS"?"TAILS":"HEADS"
        });
        const pot=w.stake*2, fee=feeOf(pot, TM.S.config.fee);
        TM.S.house.fees += fee; other.bal += (proof.first%2===0)=== (w.side==="HEADS") ? 0 : pot-fee;
        const owner = TM.botById(w.botId); if (owner) owner.bal += (proof.first%2===0)===(w.side==="HEADS") ? pot-fee : 0;
        TM.S.stats.total++; TM.S.stats.coin = (TM.S.stats.coin || 0) + 1;
        if (proof.first % 2 === 0) TM.S.stats.heads++; else TM.S.stats.tails++;
      } else if (g) {
        await TM.botVsBotCatalog(g.id);
      }
    }
    TM.S.bots.forEach(b => { if (b.bal < TM.S.config.botTopAt) TM.botTopup(b); });
    if (false) { /* shop moved to botShopTick */ }
    if (Math.random() < .28) {
      const a = TM.pick(TM.S.bots), b = TM.pick(TM.S.bots.filter(x=>x.id!==a.id));
      const amt = TM.pick([50,100,250]);
      if (a.bal > amt+5) {
        const fee = Math.max(1, Math.round(amt*TM.S.config.xferFee));
        a.bal -= amt; b.bal += amt-fee;
        TM.S.house.transfers += fee;
        TM.capPush(TM.S.botTransfers, { t:Date.now(), from:a.name, to:b.name, amount:amt, fee }, 100);
      }
    }
    if (Math.random() < .4 && TM.S.cups.filter(c=>!c.b).length < 8) {
      TM.createCup({ format: TM.pick(["Bo3","Bo5","Bo7","Advantage"]), entry: TM.pick([50,100,150]), by:"bot" });
    }
    const openCup = TM.S.cups.find(c => !c.b && c.a.kind==="bot");
    if (openCup && Math.random() < .5) await TM.joinCup(openCup.id, "bot");
    if (Math.random() < .18 && !TM.S.trnys.some(t=>t.status==="open")) {
      TM.createTrny({ size: TM.pick([4,8,16]), entry: TM.pick([50,100,250]), format: Math.random()<.35?"Bo3":"single", auto:true });
    }
    if (TM.S.config.growthOn && TM.S.bots.length < TM.S.config.growthMax && Math.random() < .22) {
      TM.spawnBot();
    }
    if (Math.random() < .25) {
      TM.S.social.chat.push({ t:Date.now(), from: TM.pick(TM.S.bots).name, text: TM.pick([
        "Queue looks spicy.","Jackpot is waking up.","Anyone for Bo3?","Taking HIGH on Over/Under.",
        "Catalog carry is fat.","gg last flip","Who is climbing VIP?","Delhi night session."
      ]) });
      if (TM.S.social.chat.length > 40) TM.S.social.chat.shift();
    }
    TM.S.session.samples = TM.S.session.samples || [];
    TM.S.session.samples.push({ t:Date.now(), games:TM.S.stats.total, pool:TM.S.jackpot.pool, bots:TM.S.bots.length, fees:TM.S.house.fees });
    if (TM.S.session.samples.length > 48) TM.S.session.samples.shift();
  } finally {
    _tickLock = false;
    TM.save();
  }
};
