window.TM = window.TM || {};
TM.KEY = "tossmatch_v8";
TM.S = null;
let _saveTimer = 0;
let _busy = false;

TM.uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
TM.now = () => Date.now();
TM.clamp = (n, a, b) => Math.max(a, Math.min(b, n));
TM.round = n => Math.round(n);
TM.fmt = n => {
  const x = Math.round(Number(n) || 0);
  return (x < 0 ? "−" : "") + Math.abs(x).toLocaleString("en-IN");
};
TM.delta = n => (n > 0 ? "+" : n < 0 ? "−" : "") + Math.abs(Math.round(n)).toLocaleString("en-IN");
TM.ago = ts => {
  const s = Math.max(0, (Date.now() - ts) / 1000);
  if (s < 60) return Math.floor(s) + "s";
  if (s < 3600) return Math.floor(s / 60) + "m";
  if (s < 86400) return Math.floor(s / 3600) + "h";
  return Math.floor(s / 86400) + "d";
};
TM.pick = arr => arr[Math.floor(Math.random() * arr.length)];
TM.shuffle = arr => {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
};
TM.esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({
  "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
}[c]));
TM.hex = buf => [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, "0")).join("");
TM.bytes = hex => {
  const out = [];
  for (let i = 0; i < hex.length; i += 2) out.push(parseInt(hex.slice(i, i + 2), 16));
  return out;
};
TM.randHex = (n = 32) => {
  const a = new Uint8Array(n);
  crypto.getRandomValues(a);
  return TM.hex(a);
};

TM.sha256 = async str => {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(String(str)));
  return TM.hex(buf);
};

TM.levelOf = xp => Math.floor(Math.sqrt((xp || 0) / 60)) + 1;
TM.xpFor = lv => Math.pow(lv - 1, 2) * 60;
TM.vipIndex = s => {
  const w = s.player.monthWagered || 0;
  const tiers = s.config.vip || TM.VIP;
  let idx = 0;
  tiers.forEach((t, i) => { if (w >= t.wager) idx = i; });
  return idx;
};
TM.vip = s => (s.config.vip || TM.VIP)[TM.vipIndex(s)];
TM.playable = s => s.wallet.main + s.wallet.bonus + s.wallet.referral + s.wallet.rakeback;
TM.maxStake = s => Math.min(1000, 100 + (s.player.level || 1) * 100);

TM.makeBots = (n = 99) => {
  const bots = [];
  for (let i = 0; i < n; i++) {
    const seed = TM.BOT_SEED[i];
    const name = seed ? seed[0] : TM.pick(["Ash","Rio","Ken","Val","Nox","Ivy","Sol","Ren"]) + TM.pick(["ix","or","ae","on","el"]) + (i + 1);
    bots.push({
      id: "bot" + (i + 1),
      name,
      country: seed ? seed[1] : TM.pick(TM.COUNTRIES),
      title: seed ? seed[2] : TM.pick(TM.TITLES),
      bio: seed ? seed[3] : "A regular on the TossMatch tables.",
      glyph: TM.GLYPHS[i % TM.GLYPHS.length],
      bal: 0, bonus: 1000, startBonus: 1000,
      withdrawAt: 3000 + Math.floor(Math.random() * 2001),
      withdraws: 0, withdrawTotal: 0,
      referredBy: i === 0 ? "player" : null,
      referredByName: i === 0 ? "You" : null, referrals: 0,
      wins: Math.floor(Math.random() * 40),
      losses: Math.floor(Math.random() * 40),
      streak: Math.floor(Math.random() * 5),
      level: 1 + Math.floor(Math.random() * 12),
      jackpots: Math.random() < .08 ? 1 : 0,
      net: Math.floor(Math.random() * 800) - 200,
      skin: "skin-classic",
      online: Math.random() < .65,
      topups: 0
    });
  }
  return bots;
};

TM.defaultState = () => {
  const end = new Date();
  end.setUTCMonth(end.getUTCMonth() + 1, 0);
  end.setUTCHours(20, 0, 0, 0);
  return {
    wallet: { main: 0, bonus: 1000, referral: 0, rakeback: 0, bank: 0 },
    player: {
      name: "You", id: "player",
      xp: 0, level: 1, monthWagered: 0, streak: 0, bestStreak: 0, lossStreak: 0,
      games: 0, wins: 0, losses: 0, draws: 0, carries: 0,
      net: 0, wagered: 0, payouts: 0, fees: 0, maxPayout: 0, biggestStake: 0,
      jackpots: 0, cupWins: 0, cupPlays: 0, trnyWins: 0, trnyPlays: 0,
      catalogGames: 0, arcadeGames: 0, friendGames: 0, clanGames: 0,
      transfers: 0, gifts: 0, chatSent: 0, roomsCreated: 0,
      catalogPlayed: {}, owned: ["skin-classic","flag-earth","pers-hero","fr-thin","cc-white","fx-confetti","th-midnight","snd-std"],
      equip: { skins:"skin-classic", flags:"flag-earth", personas:"pers-hero", frames:"fr-thin", chat:"cc-white", fx:"fx-confetti", themes:"th-midnight", sound:"snd-std" },
      achievements: {}, flags: {},
      pendingRake: 0, claimedFirstTopup: false, startBonusGranted: true, referrals: 0,
      loginDay: 0, loginStreak: 0, lastLogin: "",
      prestige: 0, passPremium: false, passXP: 0, claimedPass: {},
      weekly: { wins:0, games:new Set ? undefined : 0, distinct:{}, streak:0 },
      tickets: 0, crafts: 0, roomTier: "basic"
    },
    social: { friends: [], blocked: [], clan: null, chat: [], gifts: [] },
    waiting: [],
    cups: [],
    trnys: [],
    x2: null,
    rooms: [],
    carry: {},
    games: [],
    catalogLog: [],
    arcadeLog: [],
    ledger: [],
    feed: [],
    botTransfers: [],
    reviews: [],
    audit: [],
    bots: TM.makeBots(99),
    jackpot: { pool: 120, armed: true },
    house: { fees: 0, catalogFees: 0, cupRake: 0, trnyRake: 0, shop: 0, transfers: 0, promo: 0, comps: 0, withdrawals: 0, capital: 100000 },
    taps: 1000, sinks: 0,
    withdrawals: { count: 0, amount: 0, log: [] },
    stats: { heads: 0, tails: 0, total: 0, jackpotHits: 0, catalog: 0, arcade: 0, cups: 0, trnys: 0 },
    topups: TM.emptyTopups(),
    config: {
      fee: .05, cupRake: .05, trnyRake: .10, xferFee: .02, xferMin: 10, xferCap: 500,
      jpFund: .10, jpFloor: 1, jpArm: 50, jpPay: .50, nonMainCap: .20,
      firstTopup: true, firstTopupPct: 50, mainShare: .85, startBonus: 1000, wdMin: 3000, wdMax: 5000,
      maintenance: false, botsOn: true, autoMatch: true, questsOn: true, loginOn: true,
      botTopAt: 500, growthOn: true, growthEvery: 15000, growthN: 1, growthMax: 250,
      broadcast: "", vip: JSON.parse(JSON.stringify(TM.VIP)),
      features: { quests: true, login: true, automatch: true, bots: true }
    },
    settings: {
      theme: "", lang: "en", sound: true, instant: false, autoRebet: false, autoRebetStop: -200,
      turbo: 1, favorites: [], arcadeFav: [],
      a11y: { hc:false, reduce:false, scale:100, cv:"standard", hints:true },
      dash: { cards:["wallet","net","jackpot","level","network","wagered","payout","arcade"], hidden:[], sections:["ops","vip","pulse","explore"] },
      presets: [],
      rg: { lossLimit: -500, sessionMin: 0, coolOffUntil: 0, excludeUntil: 0, excludePerm: false,
            depDay: 0, depWeek: 0, depMonth: 0, usedDay: 0, usedWeek: 0, usedMonth: 0, realityMin: 5 }
    },
    session: { start: Date.now(), net: 0, bets: [], lastReality: Date.now(), samples: [] },
    economy: { stake: 0, interestDue: 0, lastWeek: Date.now(), sub: null, boostXP: 0, boostRake: 0 },
    feature: { triviaDay: "", fish: {common:0, uncommon:0, rare:0, legend:0}, wheelDay: "" },
    seasonEnd: end.toISOString(),
    created: Date.now()
  };
};

TM.merge = (saved) => {
  const d = TM.defaultState();
  if (!saved || typeof saved !== "object") return d;
  const deep = (a, b) => {
    if (Array.isArray(b)) return b;
    if (b && typeof b === "object") {
      const o = { ...a };
      Object.keys(b).forEach(k => { o[k] = a && typeof a[k] === "object" && !Array.isArray(a[k]) ? deep(a[k], b[k]) : b[k]; });
      return o;
    }
    return b;
  };
  const s = deep(d, saved);
  if (!Array.isArray(s.bots) || s.bots.length < 99) {
    const extra = TM.makeBots(99);
    const have = new Set((s.bots || []).map(b => b.id));
    extra.forEach(b => { if (!have.has(b.id)) s.bots.push(b); });
  }
  s.player.level = TM.levelOf(s.player.xp);
  if (s.jackpot.pool >= (s.config.jpArm || 50)) s.jackpot.armed = true;
  s.topups = Object.assign(TM.emptyTopups(), s.topups || {});
  s.topups.bot = Object.assign(TM.emptyTopups().bot, s.topups.bot || {});
  s.topups.player = Object.assign(TM.emptyTopups().player, s.topups.player || {});
  s.topups.log = Array.isArray(s.topups.log) ? s.topups.log : [];
  s.stats = Object.assign({ heads:0, tails:0, total:0, jackpotHits:0, coin:0, catalog:0, arcade:0, cups:0, trnys:0 }, s.stats || {});
  if (!s.stats.coin) s.stats.coin = (s.stats.heads || 0) + (s.stats.tails || 0);
  if (s.config.firstTopupPct == null) s.config.firstTopupPct = 50;
  if (s.config.mainShare == null) s.config.mainShare = .85;
  if (s.config.startBonus == null) s.config.startBonus = 1000;
  if (!s.player.startBonusGranted) {
    if ((s.player.games || 0) === 0 && (s.topups?.player.count || 0) === 0) {
      s.wallet.main = 0;
      s.wallet.bonus = s.config.startBonus;
    }
    s.player.startBonusGranted = true;
  }
  (s.bots || []).forEach((b, i) => {
    if (b.bonus == null) {
      b.bonus = s.config.startBonus || 1000;
      if (!b.topups) b.bal = 0;
    }
    if (!b.referredBy && i === 0) { b.referredBy = "player"; b.referredByName = s.player.name; }
  });
  return s;
};

TM.emptyTopups = () => ({
  bot: { count: 0, base: 0, bonus: 0, total: 0 },
  player: { count: 0, amount: 0, bonus: 0 },
  log: []
});

TM.metrics = () => {
  const s = TM.S;
  const topupRev = ((s.topups && s.topups.player.amount) || 0) + ((s.topups && s.topups.bot.total) || 0);
  const houseGross = (s.house.fees||0) + (s.house.catalogFees||0) + (s.house.cupRake||0) + (s.house.trnyRake||0) + (s.house.shop||0) + (s.house.transfers||0) + topupRev;
  const houseCost = (s.house.promo||0) + (s.house.comps||0) + (s.house.withdrawals||0);
  const botBal = s.bots.reduce((a,b)=>a+(b.bal||0),0);
  const botLow = s.bots.filter(b => b.bal < (s.config.botTopAt||500)).length;
  const online = s.bots.filter(b => b.online).length;
  const n = (s.stats.heads||0) + (s.stats.tails||0);
  const z = n ? ((s.stats.heads - n/2) / Math.sqrt(n/4)) : 0;
  const ratio = s.taps ? s.sinks / s.taps : 0;
  const health = ratio > 1.2 ? "Hot sinks" : ratio < .3 ? "Loose taps" : "Balanced";
  const tu = s.topups || TM.emptyTopups();
  const wr = s.player.games ? s.player.wins / s.player.games : 0;
  const roi = s.player.wagered ? s.player.net / s.player.wagered : 0;
  const avgStake = s.player.games ? s.player.wagered / s.player.games : 0;
  const avgPayout = s.player.games ? s.player.payouts / s.player.games : 0;
  const capital = (s.house.capital || 100000) + (houseGross - houseCost);
  return {
    houseGross, houseCost, houseNet: houseGross - houseCost, capital,
    botBal, botLow, online, n, z, ratio, health, tu, wr, roi, avgStake, avgPayout
  };
};

TM.pct1 = n => {
  const x = Number(n) || 0;
  return (Math.round(x * 10) / 10).toFixed(1) + "%";
};

TM.sheetOf = (kind) => {
  const s = TM.S;
  const log = ((s.topups && s.topups.log) || []).filter(x => x.kind === kind);
  const now = Date.now();
  const d7 = now - 7 * 86400000;
  const d30 = now - 30 * 86400000;
  let count = 0, base = 0, bonus = 0, largest = 0, last7 = 0, last30 = 0;
  const uniq = new Set();
  log.forEach(x => {
    const b = +x.base || 0, p = +x.bonus || 0;
    count++;
    base += b;
    bonus += p;
    if (b > largest) largest = b;
    if (x.who) uniq.add(x.who);
    if ((x.t || 0) >= d7) last7 += b;
    if ((x.t || 0) >= d30) last30 += b;
  });
  const totals = s.topups || TM.emptyTopups();
  if (!count && totals[kind]) {
    count = totals[kind].count || 0;
    base = totals[kind].base || totals[kind].amount || 0;
    bonus = totals[kind].bonus || 0;
    last7 = last30 = base;
  }
  const avg = count ? Math.round(base / count) : 0;
  const rate = base ? (bonus / base) * 100 : 0;
  const unique = uniq.size || (kind === "bot" ? s.bots.filter(b => b.topups).length : (count ? 1 : 0));
  return { count, unique, base, bonus, total: base + bonus, avg, largest, last7, last30, rate };
};

TM.sheetHTML = (title, emoji, rows) => `
  <section class="stat-sheet">
    <h3><span class="emoji">${emoji}</span>${title}</h3>
    <dl>
      ${rows.map((r, i) => `<div class="stat-row ${r.cls || ""} ${r.rule ? "rule" : ""} ${i === rows.length - 1 ? "last" : ""}">
        <dt>${r.l}</dt><dd>${r.v}</dd>
      </div>`).join("")}
    </dl>
  </section>`;

TM.playerTopupSheet = () => {
  const p = TM.sheetOf("player");
  return TM.sheetHTML("Player top-up statistics", "🧑", [
    { l: "Top-up count", v: TM.fmt(p.count) },
    { l: "Base volume", v: TM.fmt(p.base) },
    { l: "Bonus / total credited", v: TM.fmt(p.bonus) + " / " + TM.fmt(p.total) },
    { l: "Average / largest base", v: TM.fmt(p.avg) + " / " + TM.fmt(p.largest) },
    { l: "Last 7 / 30 days", v: TM.fmt(p.last7) + " / " + TM.fmt(p.last30) },
    { l: "Bonus rate", v: TM.pct1(p.rate) }
  ]);
};

TM.botTopupSheet = () => {
  const b = TM.sheetOf("bot");
  return TM.sheetHTML("Bot top-up statistics", "🤖", [
    { l: "Top-up count / unique bots", v: TM.fmt(b.count) + " / " + TM.fmt(b.unique) },
    { l: "Base volume", v: TM.fmt(b.base) },
    { l: "Bonus / total credited", v: TM.fmt(b.bonus) + " / " + TM.fmt(b.total) },
    { l: "Average / largest base", v: TM.fmt(b.avg) + " / " + TM.fmt(b.largest) },
    { l: "Last 7 / 30 days", v: TM.fmt(b.last7) + " / " + TM.fmt(b.last30) },
    { l: "Bonus rate", v: TM.pct1(b.rate) }
  ]);
};

TM.gamesSheet = () => {
  const st = TM.S.stats || {};
  const coin = st.coin || ((st.heads || 0) + (st.tails || 0));
  const cat = st.catalog || 0;
  const arc = st.arcade || 0;
  const total = st.total || (coin + cat + arc + (st.cups || 0) + (st.trnys || 0));
  return TM.sheetHTML("Games completed", "🎮", [
    { l: "Total games", v: TM.fmt(total) },
    { l: "Coin Toss", v: TM.fmt(coin) },
    { l: "P2P Catalog", v: TM.fmt(cat) },
    { l: "Arcade+", v: TM.fmt(arc) },
    { l: "Series Cups", v: TM.fmt(st.cups || 0) },
    { l: "Tournaments", v: TM.fmt(st.trnys || 0) }
  ]);
};

TM.withdrawAtFor = (bot) => {
  const lo = TM.S.config.wdMin || 3000;
  const hi = Math.max(lo, TM.S.config.wdMax || 5000);
  if (bot && bot.withdrawAt && bot.withdrawAt >= lo && bot.withdrawAt <= hi) return bot.withdrawAt;
  return lo + Math.floor(Math.random() * (hi - lo + 1));
};

TM.withdrawSheet = () => {
  const w = TM.S.withdrawals || { count: 0, amount: 0, log: [] };
  const log = w.log || [];
  const now = Date.now();
  const d7 = log.filter(x => (x.t || 0) >= now - 7 * 86400000).reduce((a, x) => a + (x.amount || 0), 0);
  const avg = w.count ? Math.round(w.amount / w.count) : 0;
  const largest = log.reduce((m, x) => Math.max(m, x.amount || 0), 0);
  const unique = new Set(log.map(x => x.botId)).size;
  return TM.sheetHTML("Bot withdrawals", "🏦", [
    { l: "Requests paid", v: TM.fmt(w.count) + " / " + TM.fmt(unique) + " bots" },
    { l: "Total withdrawn", v: TM.fmt(w.amount) },
    { l: "Average / largest", v: TM.fmt(avg) + " / " + TM.fmt(largest) },
    { l: "Last 7 days", v: TM.fmt(d7) },
    { l: "Taken from revenue", v: TM.fmt(TM.S.house.withdrawals || 0), cls: "bad" }
  ]);
};

TM.pnlSheet = () => {
  const s = TM.S, m = TM.metrics();
  return TM.sheetHTML("House P&amp;L", "💵", [
    { l: "Coin Toss fees", v: TM.fmt(s.house.fees) },
    { l: "P2P Catalog earnings", v: TM.fmt(s.house.catalogFees) },
    { l: "Series Cup rake", v: TM.fmt(s.house.cupRake) },
    { l: "Tournament rake", v: TM.fmt(s.house.trnyRake) },
    { l: "Shop sales", v: TM.fmt(s.house.shop) },
    { l: "Transfer fees", v: TM.fmt(s.house.transfers) },
    { l: "Player top-ups", v: TM.fmt(s.topups?.player.amount || 0) },
    { l: "Bot top-ups", v: TM.fmt(s.topups?.bot.total || 0) },
    { l: "Gross revenue", v: TM.fmt(m.houseGross), cls: "ok", rule: true },
    { l: "Promo cost (taps)", v: TM.fmt(s.house.promo), cls: "bad" },
    { l: "Comps paid", v: TM.fmt(s.house.comps), cls: "bad" },
    { l: "Net revenue", v: TM.fmt(m.houseNet), cls: "gold", rule: true },
    { l: "House capital", v: TM.fmt(m.capital) }
  ]);
};

TM.needsPlayerTopup = () => {
  const s = TM.S;
  return (s.topups?.player.count || 0) < 1 && s.wallet.main <= 0;
};

TM.botFund = (bot, stake) => {
  if (!bot || stake <= 0) return false;
  const s = TM.S;
  const share = TM.mainShare();
  let mainNeed = Math.ceil(stake * share);
  let bonusNeed = stake - mainNeed;
  if ((bot.bal || 0) < mainNeed) TM.botTopup(bot, "wager-topup");
  if ((bot.bal || 0) < mainNeed) {
    if ((bot.bal || 0) + (bot.bonus || 0) < stake) return false;
    mainNeed = Math.min(bot.bal, stake);
    bonusNeed = stake - mainNeed;
  }
  if ((bot.bonus || 0) < bonusNeed) {
    const extra = bonusNeed - (bot.bonus || 0);
    if ((bot.bal || 0) < mainNeed + extra) TM.botTopup(bot, "wager-topup");
    if ((bot.bal || 0) < mainNeed + extra) return false;
    bot.bal -= mainNeed + extra;
    bot.bonus = 0;
    return true;
  }
  bot.bal -= mainNeed;
  bot.bonus = (bot.bonus || 0) - bonusNeed;
  return true;
};

TM.bootBankrolls = () => {
  const s = TM.S;
  if (!s) return;
  s._lastTopBot = null;
  s.bots.forEach(b => {
    if (b.bonus == null) b.bonus = s.config.startBonus || 1000;
    if ((b.bal || 0) < Math.max(200, s.config.botTopAt || 500)) {
      TM.botTopup(b, "boot-topup");
      s._lastTopBot = null;
    }
  });
};

TM.spawnBot = () => {
  const s = TM.S;
  const i = s.bots.length + 1;
  const viaPlayer = Math.random() < .55 || !s.bots.length;
  const ref = viaPlayer ? null : TM.pick(s.bots);
  const gift = s.config.startBonus || 1000;
  const bot = {
    id: "bot" + i,
    name: TM.pick(["Neo","Ada","Lux","Zen","Kai","Rio","Nox","Ivy"]) + i,
    country: TM.pick(TM.COUNTRIES),
    title: TM.pick(TM.TITLES),
    bio: "Joined through a referral.",
    glyph: TM.pick(TM.GLYPHS),
    bal: 0,
    bonus: gift,
    startBonus: gift,
    referredBy: viaPlayer ? "player" : ref.id,
    referredByName: viaPlayer ? s.player.name : ref.name,
    referrals: 0,
    wins: 0, losses: 0, streak: 0, level: 1, jackpots: 0, net: 0,
    skin: "skin-classic", online: true, topups: 0
  };
  s.bots.push(bot);
  s.taps += gift;
  s.house.promo += gift;
  const reward = 50;
  if (viaPlayer) {
    s.wallet.referral += reward;
    s.taps += reward;
    s.player.referrals = (s.player.referrals || 0) + 1;
    TM.feed(bot.name + " joined on your referral · +" + reward + " REFERRAL", "ok");
  } else {
    ref.bonus = (ref.bonus || 0) + reward;
    ref.referrals = (ref.referrals || 0) + 1;
    s.taps += reward;
    TM.feed(bot.name + " joined via " + ref.name + "'s invite", "ok");
  }
  s._lastTopBot = null;
  TM.botTopup(bot, "new-bot-topup");
  return bot;
};

TM.load = () => {
  try {
    const raw = localStorage.getItem(TM.KEY);
    TM.S = TM.merge(raw ? JSON.parse(raw) : null);
  } catch (e) {
    TM.S = TM.defaultState();
  }
  return TM.S;
};

TM.save = (immediate) => {
  const write = () => {
    try {
      const s = TM.S;
      const slim = { ...s, session: { ...s.session, samples: (s.session.samples || []).slice(-40) } };
      slim.games = (s.games || []).slice(0, 200);
      slim.ledger = (s.ledger || []).slice(0, 200);
      slim.feed = (s.feed || []).slice(0, 60);
      slim.audit = (s.audit || []).slice(0, 50);
      slim.catalogLog = (s.catalogLog || []).slice(0, 100);
      slim.arcadeLog = (s.arcadeLog || []).slice(0, 100);
      slim.botTransfers = (s.botTransfers || []).slice(0, 100);
      slim.withdrawals = { ...(s.withdrawals || { count: 0, amount: 0, log: [] }), log: ((s.withdrawals && s.withdrawals.log) || []).slice(0, 200) };
      localStorage.setItem(TM.KEY, JSON.stringify(slim));
    } catch (e) { /* quota */ }
  };
  if (immediate) return write();
  clearTimeout(_saveTimer);
  _saveTimer = setTimeout(write, TM.S.settings.turbo >= 100 ? 4000 : 250);
};

TM.reset = () => {
  localStorage.removeItem(TM.KEY);
  TM.S = TM.defaultState();
  TM.save(true);
};

TM.capPush = (arr, item, n) => {
  arr.unshift(item);
  if (arr.length > n) arr.length = n;
};

TM.ledger = (type, delta, note, extra = {}) => {
  const s = TM.S;
  TM.capPush(s.ledger, {
    t: Date.now(), type, delta, note, main: s.wallet.main, ...extra
  }, 200);
};

TM.feed = (text, kind = "info") => {
  TM.capPush(TM.S.feed, { t: Date.now(), text, kind }, 60);
};

TM.audit = (text) => {
  TM.capPush(TM.S.audit, { t: Date.now(), text }, 50);
};

TM.toast = (msg, kind) => {
  const wrap = document.getElementById("toasts");
  if (!wrap) return;
  const el = document.createElement("div");
  el.className = "toast";
  el.textContent = msg;
  if (kind === "bad") el.style.borderColor = "rgba(255,107,138,.4)";
  wrap.appendChild(el);
  setTimeout(() => el.remove(), 3200);
};

TM.sound = (kind = "flip") => {
  if (!TM.S?.settings.sound) return;
  try {
    const ctx = TM._ac || (TM._ac = new (window.AudioContext || window.webkitAudioContext)());
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.connect(g); g.connect(ctx.destination);
    const pack = TM.S.player.equip.sound;
    const base = pack === "snd-8bit" ? 220 : pack === "snd-crystal" ? 880 : pack === "snd-synth" ? 110 : 330;
    o.type = pack === "snd-8bit" ? "square" : pack === "snd-orch" ? "triangle" : "sine";
    o.frequency.value = kind === "win" ? base * 2 : kind === "lose" ? base * .7 : base;
    g.gain.value = .05;
    o.start();
    g.gain.exponentialRampToValueAtTime(.0001, ctx.currentTime + .18);
    o.stop(ctx.currentTime + .2);
  } catch (e) {}
};

TM.guard = (stake, opts = {}) => {
  const s = TM.S;
  const rg = s.settings.rg;
  if (s.config.maintenance && !opts.allowMaint) return "Maintenance is on. New bets are paused.";
  if (rg.excludePerm) return "Self-exclusion is permanent on this demo profile.";
  if (rg.excludeUntil && Date.now() < rg.excludeUntil) return "Self-exclusion is still active.";
  if (rg.coolOffUntil && Date.now() < rg.coolOffUntil) return "Session cool-off is active.";
  if (rg.sessionMin > 0 && Date.now() - s.session.start > rg.sessionMin * 60000) {
    rg.coolOffUntil = Date.now() + 60 * 1000;
    return "Session time limit reached. Cool-off started.";
  }
  if (s.session.net <= (rg.lossLimit || -1e9)) return "Session loss limit reached.";
  const recent = (s.session.bets || []).filter(t => Date.now() - t < 60000);
  if (recent.length >= 12) return "Rate limit: 12 player bets per minute.";
  if (stake != null) {
    if (stake < 10) return "Minimum stake is 10 coins.";
    if (stake > TM.maxStake(s)) return "Stake exceeds your level cap (" + TM.maxStake(s) + ").";
    if ((s.topups?.player.count || 0) < 1 && s.wallet.main <= 0)
      return "Top up MAIN first. The 1,000 start is BONUS and cannot open a bet alone.";
    const share = TM.clamp(s.config.mainShare || .85, .8, .9);
    const mainNeed = Math.ceil(stake * share);
    if (s.wallet.main < mainNeed)
      return "Need " + mainNeed + " MAIN (" + Math.round(share * 100) + "% of stake). Top up to play. BONUS covers the rest.";
    if (TM.playable(s) < stake) return "Not enough playable coins.";
  }
  return null;
};

TM.mainShare = () => TM.clamp((TM.S.config.mainShare || .85), .8, .9);

TM.planEscrow = (stake) => {
  const s = TM.S;
  const mainNeed = Math.ceil(stake * TM.mainShare());
  let rest = stake - mainNeed;
  if (s.wallet.main < mainNeed) return null;
  const use = { bonus: 0, referral: 0, rakeback: 0, main: mainNeed };
  const take = k => {
    const v = Math.min(s.wallet[k] || 0, rest);
    use[k] += v; rest -= v;
  };
  take("bonus"); take("referral"); take("rakeback");
  if (rest > 0) {
    if (s.wallet.main - use.main < rest) return null;
    use.main += rest;
  }
  return use;
};

TM.applyEscrow = (use) => {
  const w = TM.S.wallet;
  w.bonus -= use.bonus; w.referral -= use.referral; w.rakeback -= use.rakeback; w.main -= use.main;
};

TM.refund = (use) => {
  if (!use) return;
  const w = TM.S.wallet;
  w.bonus += use.bonus || 0; w.referral += use.referral || 0; w.rakeback += use.rakeback || 0; w.main += use.main || 0;
};

TM.creditMain = (n, note) => {
  TM.S.wallet.main += n;
  if (note) TM.ledger("credit", n, note);
};

TM.debitMain = (n, note) => {
  if (TM.S.wallet.main < n) return false;
  TM.S.wallet.main -= n;
  if (note) TM.ledger("debit", -n, note);
  return true;
};

TM.addXP = (stake) => {
  const s = TM.S;
  let gain = Math.max(1, Math.round(stake / 10));
  if (s.economy.boostXP > Date.now()) gain *= 2;
  if (s.player.prestige) gain = Math.round(gain * (1 + .05 * s.player.prestige));
  const before = s.player.level;
  s.player.xp += gain;
  s.player.level = TM.levelOf(s.player.xp);
  if (s.player.level > before) {
    for (let lv = before + 1; lv <= s.player.level; lv++) {
      const reward = (s.config.levelRewards && s.config.levelRewards[lv]) || TM.LEVEL_REWARD[lv] || lv * 50;
      s.wallet.bonus += reward;
      s.taps += reward;
      s.house.promo += reward;
      TM.feed("Level " + lv + " · +" + reward + " BONUS", "ok");
      if (lv === 30 || lv === 40 || lv === 50) {
        const gift = lv === 30 ? "fr-emerald" : lv === 40 ? "skin-quantum" : "skin-prism";
        if (!s.player.owned.includes(gift)) s.player.owned.push(gift);
      }
    }
    TM.toast("Level up · " + s.player.level);
  }
};

TM.accrueRake = (fee) => {
  const s = TM.S;
  const vip = TM.vip(s);
  let pct = vip.rake;
  if (s.economy.boostRake > Date.now()) pct = Math.min(25, pct + 5);
  const add = Math.round((fee / 2) * (pct / 100));
  s.player.pendingRake += add;
};

TM.recordGame = (rec) => {
  const s = TM.S;
  TM.capPush(s.games, rec, 200);
  s.player.games++;
  s.stats.total++;
  const fam = rec.kind === "catalog" || rec.game && TM.catalogById(rec.game) ? "catalog"
    : rec.kind === "arcade" ? "arcade"
    : rec.kind === "cup" ? "cups"
    : rec.kind === "trny" ? "trnys"
    : "coin";
  if (fam === "catalog") s.stats.catalog = (s.stats.catalog || 0) + 1;
  else if (fam === "arcade") s.stats.arcade = (s.stats.arcade || 0) + 1;
  else if (fam === "cups") s.stats.cups = (s.stats.cups || 0) + 1;
  else if (fam === "trnys") s.stats.trnys = (s.stats.trnys || 0) + 1;
  else s.stats.coin = (s.stats.coin || 0) + 1;
  s.player.wagered += rec.stake || 0;
  s.player.monthWagered += rec.stake || 0;
  s.player.fees += rec.fee || 0;
  if (rec.payout) {
    s.player.payouts += rec.payout;
    s.player.maxPayout = Math.max(s.player.maxPayout, rec.payout);
  }
  s.player.biggestStake = Math.max(s.player.biggestStake, rec.stake || 0);
  s.player.net += rec.delta || 0;
  s.session.net += rec.delta || 0;
  if (rec.result === "win") {
    if (s.player.lossStreak >= 2) s.player.flags.comeback = true;
    s.player.wins++; s.player.streak++; s.player.lossStreak = 0;
    s.player.bestStreak = Math.max(s.player.bestStreak, s.player.streak);
  } else if (rec.result === "lose") {
    s.player.losses++; s.player.streak = 0; s.player.lossStreak++;
  } else if (rec.result === "split") {
    s.player.draws++;
  } else if (rec.result === "carry") {
    s.player.carries++;
  }
  s.player.qGames = (s.player.qGames || 0) + 1;
  if (rec.result === "win") s.player.qWins = (s.player.qWins || 0) + 1;
  TM.checkAchievements();
};

TM.checkAchievements = () => {
  const s = TM.S;
  TM.ACHIEVEMENTS.forEach(a => {
    if (s.player.achievements[a.id]) return;
    try {
      if (a.test(s)) {
        s.player.achievements[a.id] = Date.now();
        s.wallet.bonus += a.reward;
        s.taps += a.reward;
        s.house.promo += a.reward;
        TM.feed("Achievement · " + a.name + " · +" + a.reward + " BONUS", "ok");
        TM.toast("Achievement: " + a.name);
      }
    } catch (e) {}
  });
};

TM.loginTick = () => {
  const s = TM.S;
  if (!s.config.loginOn) return;
  const day = new Date().toDateString();
  if (s.player.lastLogin === day) return;
  const yest = new Date(Date.now() - 86400000).toDateString();
  s.player.loginStreak = s.player.lastLogin === yest ? (s.player.loginStreak || 0) + 1 : 1;
  s.player.lastLogin = day;
  const reward = Math.min(175, 50 + 25 * (s.player.loginStreak - 1));
  s.wallet.bonus += reward;
  s.taps += reward;
  TM.feed("Login streak day " + s.player.loginStreak + " · +" + reward + " BONUS", "ok");
};

TM.proofBundle = async ({ makerSeed, takerSeed, serverSeed, gameId, stake, makerSide, takerSide, catalog, pick, oppPick }) => {
  const makerHash = await TM.sha256([makerSeed, gameId, stake, catalog || "cointoss", pick || makerSide].join(":"));
  const takerHash = await TM.sha256([takerSeed, gameId, stake, catalog || "cointoss", oppPick || takerSide].join(":"));
  const commit = await TM.sha256(serverSeed);
  const combined = (BigInt("0x" + makerHash) + BigInt("0x" + takerHash) + BigInt("0x" + commit)).toString(16);
  const finalHash = await TM.sha256(combined + ":" + gameId);
  const b = TM.bytes(finalHash);
  return { makerSeed, takerSeed, serverSeed, makerHash, takerHash, commit, combined, finalHash, bytes: b, first: b[0] };
};

TM.flips = (bytes, n) => bytes.slice(0, n).map(x => (x % 2 === 0 ? "H" : "T"));
TM.isPrime = n => {
  if (n < 2) return false;
  if (n % 2 === 0) return n === 2;
  for (let i = 3; i * i <= n; i += 2) if (n % i === 0) return false;
  return true;
};
TM.cardRank = b => (b % 13) + 2; // 2..14
TM.rankName = r => ({11:"J",12:"Q",13:"K",14:"A"}[r] || String(r));

TM.busy = {
  get: () => _busy,
  set: v => { _busy = v; }
};

TM.catalogById = id => TM.CATALOG.find(g => g.id === id);
TM.arcadeById = id => TM.ARCADE.find(g => g.id === id);
TM.shopById = id => TM.SHOP.find(x => x.id === id);
TM.botById = id => TM.S.bots.find(b => b.id === id);

TM.applyTheme = () => {
  const s = TM.S;
  const th = TM.shopById(s.player.equip.themes);
  document.documentElement.className = (th && th.theme) || "";
  if (s.settings.a11y.hc) document.documentElement.classList.add("hc");
  if (s.settings.a11y.reduce) document.documentElement.classList.add("reduce");
  document.documentElement.style.fontSize = ((s.settings.a11y.scale || 100) / 100 * 16) + "px";
  const cv = s.settings.a11y.cv;
  document.documentElement.style.filter = cv === "deuteranopia" ? "url(#deut)" : cv === "protanopia" ? "saturate(.7) hue-rotate(-10deg)" : cv === "tritanopia" ? "hue-rotate(20deg)" : "";
};

window.addEventListener("storage", ev => {
  if (ev.key === TM.KEY && ev.newValue) {
    try { TM.S = TM.merge(JSON.parse(ev.newValue)); if (TM.refresh) TM.refresh(); } catch (e) {}
  }
});
