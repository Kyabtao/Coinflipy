window.TM = window.TM || {};

const $ = (s, r=document) => r.querySelector(s);
const $$ = (s, r=document) => [...r.querySelectorAll(s)];
let route = { tab: "home", sub: "" };
let paletteOn = false;

TM.t = (k) => (TM.I18N[TM.S.settings.lang] || TM.I18N.en)[k] || TM.I18N.en[k] || k;

function go(tab, sub="") {
  route = { tab, sub };
  location.hash = "#" + tab + (sub ? "/" + sub : "");
  render();
  $("#view").scrollTop = 0;
}

function parseHash() {
  const h = (location.hash || "#home").slice(1);
  const [tab, sub] = h.split("/");
  route = { tab: tab || "home", sub: sub || "" };
}

TM.refresh = () => render(true);

function render(keep) {
  TM.applyTheme();
  renderChrome();
  const view = $("#view");
  const fn = VIEWS[route.tab] || VIEWS.home;
  view.innerHTML = fn();
  bindView();
  if (TM.S.settings.a11y.hints) {
    const live = $("#live");
    if (live) live.textContent = TM.t(route.tab) || route.tab;
  }
}

function renderChrome() {
  const s = TM.S;
  const vip = TM.vip(s);
  const armed = s.jackpot.armed;
  const pct = Math.min(100, Math.round(s.jackpot.pool / Math.max(s.config.jpArm, 1) * 100));
  $("#jackpotChip").classList.toggle("armed", armed);
  $("#jpVal").textContent = TM.fmt(s.jackpot.pool);
  $("#jpBar").style.width = pct + "%";
  $("#mainChip b").textContent = TM.fmt(s.wallet.main);
  $("#vipChip b").textContent = vip.name;
  $("#vipChip").style.color = vip.color;
  $("#nameChip").textContent = s.player.name;
  $("#turboSel").value = String(s.settings.turbo);
  const q = ($("#navSearch")?.value || "").toLowerCase();
  $("#navGroups").innerHTML = TM.NAV.map(g => {
    const items = g.items.filter(it => !q || it.name.toLowerCase().includes(q) || it.id.includes(q));
    if (!items.length) return "";
    return `<div class="nav-label">${TM.esc(g.g)}</div>` + items.map(it =>
      `<button class="nav-btn ${route.tab===it.id?"active":""}" data-go="${it.id}"><span class="ico">${it.ico}</span>${TM.esc(TM.t(it.id) || it.name)}</button>`
    ).join("");
  }).join("");
  $("#mNav").innerHTML = TM.NAV.flatMap(g=>g.items).map(it =>
    `<button class="btn ${route.tab===it.id?"btn-gold":"btn-ghost"}" data-go="${it.id}">${TM.esc(TM.t(it.id)||it.name)}</button>`
  ).join("");
  const bc = s.config.broadcast;
  const ban = $("#broadcast");
  if (bc) { ban.hidden = false; ban.className = "banner"; ban.textContent = bc; }
  else if (s.config.maintenance) { ban.hidden = false; ban.className = "banner rose"; ban.textContent = "Maintenance — new betting paused. In-flight games can settle."; }
  else if (TM.needsPlayerTopup()) {
    ban.hidden = false; ban.className = "banner";
    ban.innerHTML = "Your 1,000 start is BONUS. Top up MAIN to play. Bets use " + Math.round(TM.mainShare()*100) + "% MAIN + the rest from BONUS. <a href=\"#wallet\">Open wallet →</a>";
  }
  else { ban.hidden = true; ban.className = "banner"; }
  $("#sideTag").textContent = TM.t("tag");
}

function head(title, sub, extra="") {
  return `<div class="view-head"><div><h2>${title}</h2><p>${sub||""}</p></div>${extra}</div>`;
}
function kpi(lbl, val, sub="", cls="") {
  return `<div class="card kpi ${cls}"><div class="lbl">${lbl}</div><div class="val">${val}</div><div class="sub">${sub}</div></div>`;
}

const VIEWS = {
  home() {
    const s = TM.S;
    const vip = TM.vip(s);
    const next = TM.VIP[TM.vipIndex(s)+1];
    const xp0 = TM.xpFor(s.player.level), xp1 = TM.xpFor(s.player.level+1);
    const m = TM.metrics();
    const tu = m.tu;
    const cards = {
      wallet: kpi("Playable wallet", TM.fmt(TM.playable(s)), "MAIN "+TM.fmt(s.wallet.main)),
      net: kpi("Career net", TM.delta(s.player.net), "Session "+TM.delta(s.session.net), s.player.net>=0?"up":"down"),
      jackpot: kpi("Jackpot pool", TM.fmt(s.jackpot.pool), s.jackpot.armed?"Armed":"Arming at "+s.config.jpArm),
      level: kpi("Level "+s.player.level, TM.fmt(s.player.xp)+" XP", "Next "+xp1),
      network: kpi("Live network", s.bots.length, s.bots.filter(b=>b.online).length+" appearing online"),
      wagered: kpi("Lifetime wagered", TM.fmt(s.player.wagered)),
      payout: kpi("Max payout", TM.fmt(s.player.maxPayout)),
      arcade: kpi("Arcade+ plays", s.player.arcadeGames)
    };
    const order = s.settings.dash.cards.filter(id => !s.settings.dash.hidden.includes(id));
    const recs = recsFor();
    const open = s.waiting.slice(-6).reverse();
    return head("Good table, "+TM.esc(s.player.name)+".", "A local play-coin arena. Every match is entrant versus entrant — bots stand in for the other seat.") +
      `<div class="grid g4">${order.map(id=>cards[id]||"").join("")}</div>
      <div class="grid g4" style="margin-top:14px">
        ${kpi("Your top-ups", tu.player.count, TM.fmt(tu.player.amount)+" MAIN · bonus "+TM.fmt(tu.player.bonus))}
        ${kpi("Bot top-ups", tu.bot.count, TM.fmt(tu.bot.total)+" coins of liquidity")}
        ${kpi("Open queue", s.waiting.length, "live seats on this origin")}
        ${kpi("Fees paid", TM.fmt(s.player.fees), "cups "+s.player.cupWins+" · brackets "+s.player.trnyWins)}
      </div>
      <div class="grid g2" style="margin-top:14px">
        <div class="card">
          <h3>Live opportunities</h3>
          ${open.length? `<div class="table-wrap"><table><tr><th>Game</th><th>By</th><th>Stake</th><th></th></tr>${open.map(w=>`<tr>
            <td>${w.kind==="coin"?"Coin Toss":TM.esc(TM.catalogById(w.gameId)?.name||w.gameId)}</td>
            <td>${TM.esc(w.ownerName)}</td><td>${TM.fmt(w.stake)}</td>
            <td>${w.owner==="bot"?`<button class="btn btn-gold" data-take="${w.id}">Take</button>`:"waiting"}</td>
          </tr>`).join("")}</table></div>` : `<p class="disclaimer">Queue is quiet. Post a Coin Toss or open the catalog.</p>`}
          <div class="btn-row" style="margin-top:10px">
            <button class="btn btn-gold" data-go="play">Toss a coin</button>
            <button class="btn" data-go="games">Open catalog</button>
            <button class="btn" data-go="arcade">Arcade+</button>
          </div>
        </div>
        <div class="card">
          <h3>VIP journey · ${TM.esc(vip.name)}</h3>
          <div class="progress"><i style="width:${next? Math.min(100, s.player.monthWagered/next.wager*100):100}%"></i></div>
          <p class="disclaimer">${next? TM.fmt(s.player.monthWagered)+" / "+TM.fmt(next.wager)+" to "+next.name : "Top tier this month."}</p>
          <p>${TM.esc(vip.perk)}</p>
          <div class="progress" style="margin-top:10px"><i style="width:${Math.min(100,(s.player.xp-xp0)/Math.max(1,xp1-xp0)*100)}%"></i></div>
          <p class="disclaimer">Level ${s.player.level} · ${TM.fmt(s.player.xp)} XP</p>
        </div>
      </div>
      <div class="grid g2" style="margin-top:14px">
        <div class="card">
          <h3>Activity pulse</h3>
          <div class="feed">${s.feed.slice(0,8).map(f=>`<div class="feed-item"><time>${TM.ago(f.t)}</time><span>${TM.esc(f.text)}</span></div>`).join("")||"<p class='disclaimer'>The room is still waking up.</p>"}</div>
        </div>
        <div class="card">
          <h3>For you</h3>
          ${recs.map(r=>`<div style="margin:8px 0;display:flex;justify-content:space-between;gap:8px;align-items:center">
            <div><b>${TM.esc(r.name)}</b><div class="disclaimer">${TM.esc(r.why)}</div></div>
            <button class="btn" data-go="${r.go}" data-sub="${r.sub||""}">Open</button>
          </div>`).join("")}
        </div>
      </div>`;
  },

  play() {
    const s = TM.S;
    const last = s.lastResult && s.lastResult.kind==="coin" ? s.lastResult : s.games.find(g=>g.kind==="coin");
    const waitingMine = s.waiting.filter(w=>w.kind==="coin" && w.owner==="player");
    const open = s.waiting.filter(w=>w.kind==="coin");
    const face = last && (last.resolved?.detail||"").includes("TAILS") ? "tails" : "heads";
    return head("Coin Toss", "Pick a side, escrow a stake, and meet the other seat. First proof byte even is HEADS, odd is TAILS. Byte 00 can fire an armed jackpot.") +
      `<div class="grid g2">
        <div class="card stage" id="coinStage">
          <div class="coin3d" id="coin3d" style="--end:${face==="tails"?1260:1080}deg">
            <div class="face heads"><img src="img/coin-heads.jpg" alt="Heads"></div>
            <div class="face tails"><img src="img/coin-tails.jpg" alt="Tails"></div>
          </div>
        </div>
        <div class="card">
          <div class="field"><span>Side</span>
            <div class="seg" id="sideSeg">
              <button data-side="HEADS" class="on">HEADS</button>
              <button data-side="TAILS">TAILS</button>
            </div>
          </div>
          <div class="field" style="margin-top:10px"><span>Stake · min 10 · max ${TM.maxStake(s)}</span>
            <input id="stake" type="number" min="10" max="${TM.maxStake(s)}" value="50">
          </div>
          <div class="field" style="margin-top:10px"><span>Taunt · 24 characters</span>
            <input id="taunt" maxlength="24" placeholder="optional">
          </div>
          <div class="btn-row" style="margin-top:12px">
            <button class="btn btn-gold" id="postPub">Post public</button>
            <button class="btn" id="postPriv">Post private</button>
          </div>
          <div class="btn-row" style="margin-top:8px">
            <button class="btn ${s.settings.sound?"btn-teal":""}" id="togSound">Sound ${s.settings.sound?"on":"off"}</button>
            <button class="btn ${s.settings.instant?"btn-teal":""}" id="togInst">Instant ${s.settings.instant?"on":"off"}</button>
            <button class="btn ${s.settings.autoRebet?"btn-teal":""}" id="togAuto">Auto-rebet ${s.settings.autoRebet?"on":"off"}</button>
          </div>
          <p class="disclaimer" style="margin-top:10px">Stop at session net ${s.settings.autoRebetStop}. Non-main coins can fund ${Math.round(s.config.nonMainCap*100)}% of a stake.</p>
          ${s.x2 && Date.now()<s.x2.t ? `<div class="banner" style="margin-top:12px">×2 room open at ${TM.fmt(s.x2.stake)} until ${new Date(s.x2.t).toLocaleTimeString()}
            <div class="btn-row" style="margin-top:8px"><button class="btn btn-gold" id="x2go">Challenge ×2</button><button class="btn" id="x2no">Cancel</button></div></div>`:""}
          ${waitingMine.map(w=>`<div class="banner mint" style="margin-top:8px">Your ${w.priv?"private":"public"} ${w.side} · ${TM.fmt(w.stake)} waiting
            <button class="btn" data-cancel="${w.id}" style="margin-left:8px">Cancel</button></div>`).join("")}
        </div>
      </div>
      ${last? `<div class="card" style="margin-top:14px">
        <div class="result-splash">
          <p class="big">${TM.esc((last.resolved||last).detail || last.result)}</p>
          <p class="delta ${last.delta>=0?"up":"down"}">${TM.delta(last.delta)} coins</p>
        </div>
        ${last.proof? `<div class="proof">final ${last.proof.finalHash}<br>first byte ${last.proof.first} · commit ${last.proof.commit}</div>
        <button class="btn" style="margin-top:8px" id="toVerify">Send to verifier</button>`:""}
      </div>`:""}
      <div class="card" style="margin-top:14px">
        <h3>Waiting room</h3>
        <div class="table-wrap"><table><tr><th>Player</th><th>Side</th><th>Stake</th><th>Wait</th><th></th></tr>
        ${open.map(w=>`<tr><td>${TM.esc(w.ownerName)}${s.social.friends.includes(w.botId)?' <span class="pill live">FRIEND</span>':""}</td>
          <td>${w.side}</td><td>${TM.fmt(w.stake)}</td><td>${TM.ago(w.t)}</td>
          <td>${w.owner==="bot"?`<button class="btn btn-gold" data-take="${w.id}">Take opposite</button>`: w.owner==="player"?`<button class="btn" data-cancel="${w.id}">Cancel</button>`:""}</td></tr>`).join("")||`<tr><td colspan="5" class="disclaimer">No open Coin Toss bets.</td></tr>`}
        </table></div>
      </div>`;
  },

  games() {
    const s = TM.S;
    if (route.sub) return catalogPlay(route.sub);
    const q = (window._gQ || "").toLowerCase();
    const cat = window._gCat || "all";
    const fav = s.settings.favorites || [];
    let list = TM.CATALOG.slice();
    if (cat === "fav") list = list.filter(g => fav.includes(g.id));
    else if (cat !== "all") list = list.filter(g => g.cat === cat);
    if (q) list = list.filter(g => (g.name+g.code+g.blurb+g.id).toLowerCase().includes(q));
    return head("P2P Catalog", "Thirty-three two-entrant games. Same escrow, waiting room, bot take, and merged-hash proof.") +
      `<div class="card" style="margin-bottom:12px">
        <div class="grid g3">
          <input class="ctrl" id="gSearch" placeholder="Search name, CAT code, rule…" value="${TM.esc(window._gQ||"")}">
          <select id="gCat" class="ctrl">
            <option value="all">All categories</option>
            <option value="fav">Favorites</option>
            ${TM.CATS.map(c=>`<option value="${c.id}" ${cat===c.id?"selected":""}>${c.name}</option>`).join("")}
          </select>
          <select id="gJump" class="ctrl">
            <option value="">Quick jump</option>
            ${TM.CATALOG.map(g=>`<option value="${g.id}">${g.code} · ${g.name}</option>`).join("")}
          </select>
        </div>
        <p class="disclaimer" style="margin:8px 0 0">${list.length} / ${TM.CATALOG.length} games${cat==="fav"?" · favorites":""}</p>
      </div>
      <div class="grid g3">${list.map(g=>`
        <div class="card game-card" data-open-cat="${g.id}">
          <div><div class="code">${g.code} · ${g.cat}</div><h3>${TM.esc(g.name)}</h3></div>
          <p>${TM.esc(g.blurb)}</p>
        </div>`).join("")||`<div class="card">No games match that filter.</div>`}</div>`;
  },

  arcade() {
    if (route.sub) return arcadePlay(route.sub);
    const q = (window._aQ || "").toLowerCase();
    const cat = window._aCat || "all";
    const fav = TM.S.settings.arcadeFav || [];
    let list = TM.ARCADE.slice();
    if (cat==="fav") list = list.filter(g=>fav.includes(g.id));
    else if (cat!=="all") list = list.filter(g=>g.cat===cat);
    if (q) list = list.filter(g => (g.name+g.code+g.blurb).toLowerCase().includes(q));
    return head("Arcade+", "Twenty modes. Direct MAIN stakes, published multipliers, proof-derived outcomes. Still play coins.") +
      `<div class="card" style="margin-bottom:12px">
        <div class="grid g3">
          <input class="ctrl" id="aSearch" placeholder="Search Arcade…" value="${TM.esc(window._aQ||"")}">
          <select id="aCat" class="ctrl">
            <option value="all">All</option><option value="fav">Favorites</option>
            ${TM.ARCADE_CATS.map(c=>`<option value="${c.id}">${c.name}</option>`).join("")}
          </select>
          <select id="aJump" class="ctrl"><option value="">Quick jump</option>${TM.ARCADE.map(g=>`<option value="${g.id}">${g.code} · ${g.name}</option>`).join("")}</select>
        </div>
        <p class="disclaimer">${list.length} / ${TM.ARCADE.length} modes</p>
      </div>
      <div class="grid g3">${list.map(g=>`
        <div class="card game-card" data-open-arc="${g.id}">
          <div class="code">${g.code}</div><h3>${TM.esc(g.name)}</h3><p>${TM.esc(g.blurb)}</p>
        </div>`).join("")}</div>`;
  },

  series() {
    const s = TM.S;
    const open = s.cups.filter(c=>!c.b);
    const done = s.cups.filter(c=>c.status==="done").slice(0,8);
    const tr = s.trnys.slice(0,8);
    return head("Series & tournaments", "Cups are two seats and a flip series. Tournaments fill with bots after a short public window. Champion 75% · runner-up 25% after rake.") +
      `<div class="grid g2">
        <div class="card">
          <h3>Open a Cup</h3>
          <div class="field"><span>Format</span>
            <select id="cupFmt"><option>Bo3</option><option>Bo5</option><option>Bo7</option><option>Advantage</option></select>
          </div>
          <div class="field" style="margin-top:8px"><span>Entry</span><input id="cupEntry" type="number" value="50" min="10"></div>
          <button class="btn btn-gold full" style="margin-top:12px" id="cupGo">Post Cup</button>
          <h3 style="margin-top:18px">Open Cups</h3>
          ${open.map(c=>`<div class="banner mint">${c.format} · ${TM.fmt(c.entry)} · ${TM.esc(c.a.name)}
            ${c.a.kind!=="player"?`<button class="btn" data-joincup="${c.id}">Join</button>`:"waiting for a seat"}</div>`).join("")||"<p class='disclaimer'>No open Cups.</p>"}
        </div>
        <div class="card">
          <h3>Tournaments</h3>
          <div class="grid g3">
            <select id="trSize"><option>4</option><option selected>8</option><option>16</option></select>
            <select id="trFmt"><option value="single">Single flip</option><option value="Bo3">Bo3</option></select>
            <input id="trEntry" type="number" value="100" min="10">
          </div>
          <button class="btn full" style="margin-top:10px" id="trGo">Create bracket</button>
          <div class="table-wrap" style="margin-top:12px"><table><tr><th>Size</th><th>Entry</th><th>Status</th><th></th></tr>
          ${tr.map(t=>`<tr><td>${t.size} · ${t.format}</td><td>${TM.fmt(t.entry)}</td><td>${t.status}${t.champ?" · "+TM.esc(t.champ.name):""}</td>
            <td>${t.status==="open"&&!t.seats.some(x=>x.kind==="player")?`<button class="btn btn-gold" data-jointr="${t.id}">Join</button>`: t.seats.length+"/"+t.size}</td></tr>`).join("")||"<tr><td colspan='4'>None yet.</td></tr>"}
          </table></div>
        </div>
      </div>
      <div class="card" style="margin-top:14px"><h3>Recent Cups</h3>
        ${done.map(c=>`<div class="feed-item"><time>${TM.ago(c.t)}</time><span>${c.format} · ${TM.esc(c.winner)} ${c.score} · ${c.flips?.join(" ")}</span></div>`).join("")||"<p class='disclaimer'>No finished Cups.</p>"}
      </div>`;
  },

  lobby() {
    const s = TM.S;
    return head("Lobby", "Every open Coin Toss and catalog seat, plus the live feed.") +
      `<div class="grid g2">
        <div class="card"><h3>Open queue · ${s.waiting.length}</h3>
          <div class="table-wrap"><table><tr><th>Game</th><th>Player</th><th>Pick</th><th>Stake</th><th></th></tr>
          ${s.waiting.map(w=>`<tr>
            <td>${w.kind==="coin"?"Coin Toss":TM.esc(TM.catalogById(w.gameId)?.name)}</td>
            <td>${TM.esc(w.ownerName)}</td><td>${TM.esc(w.side||w.pick||"—")}</td><td>${TM.fmt(w.stake)}</td>
            <td>${w.owner==="bot"?`<button class="btn btn-gold" data-take="${w.id}">Take</button>`:`<button class="btn" data-cancel="${w.id}">Cancel</button>`}</td>
          </tr>`).join("")||"<tr><td colspan='5'>Empty queue.</td></tr>"}</table></div>
        </div>
        <div class="card"><h3>Feed</h3>
          <div class="feed">${s.feed.map(f=>`<div class="feed-item"><time>${TM.ago(f.t)}</time><span>${TM.esc(f.text)}</span></div>`).join("")}</div>
        </div>
      </div>`;
  },

  leaderboard() {
    const s = TM.S;
    const key = window._lb || "net";
    const rows = [{ name:s.player.name, net:s.player.net, wins:s.player.wins, streak:s.player.streak, level:s.player.level, you:true }]
      .concat(s.bots.map(b => ({ name:b.name, net:b.net, wins:b.wins, streak:b.streak, level:b.level })))
      .sort((a,b)=> (b[key]||0)-(a[key]||0)).slice(0, 40);
    return head("Leaderboard", "Bots and you share one local board. Production must never present bots as human MAU.") +
      `<div class="btn-row" style="margin-bottom:10px">${["net","wins","streak","level"].map(k=>`<button class="btn ${key===k?"btn-gold":""}" data-lb="${k}">${k}</button>`).join("")}</div>
      <div class="card table-wrap"><table><tr><th>#</th><th>Player</th><th>Net</th><th>Wins</th><th>Streak</th><th>Lv</th></tr>
      ${rows.map((r,i)=>`<tr><td>${i+1}</td><td>${TM.esc(r.name)}${r.you?" · you":""}</td><td>${TM.delta(r.net)}</td><td>${r.wins}</td><td>${r.streak}</td><td>${r.level}</td></tr>`).join("")}
      </table></div>`;
  },

  players() {
    const s = TM.S;
    const q = (window._pQ||"").toLowerCase();
    const list = s.bots.filter(b => !q || b.name.toLowerCase().includes(q) || b.country.toLowerCase().includes(q));
    if (route.sub) {
      const b = TM.botById(route.sub);
      if (!b) return head("Missing","No such player.");
      return head(TM.esc(b.name), b.title+" · "+b.country) +
        `<div class="grid g2"><div class="card">
          <div class="player-row"><div class="av">${b.glyph}</div><div><b>${TM.esc(b.name)}</b><div class="disclaimer">${TM.esc(b.bio)}</div></div></div>
          <p>Balance ${TM.fmt(b.bal)} · ${b.wins}–${b.losses} · lv ${b.level} · jackpots ${b.jackpots}</p>
          <div class="btn-row">
            <button class="btn btn-gold" data-friend="${b.id}">${s.social.friends.includes(b.id)?"Remove friend":"Add friend"}</button>
            <button class="btn" data-chal="${b.id}">Challenge Coin Toss</button>
            <button class="btn" data-gift="${b.id}">Gift 50</button>
          </div>
        </div>
        <div class="card"><h3>Form</h3><p class="disclaimer">Local simulation identity. Not a real account.</p></div></div>`;
    }
    return head("Player directory", s.bots.length+" simulated seats on this origin.") +
      `<input class="ctrl" id="pSearch" placeholder="Search name or country" value="${TM.esc(window._pQ||"")}" style="margin-bottom:12px">
      <div class="grid g3">${list.slice(0,48).map(b=>`
        <div class="card game-card" data-go="players" data-sub="${b.id}">
          <div class="player-row"><div class="av">${b.glyph}</div><div><b>${TM.esc(b.name)}</b><div class="disclaimer">${b.country} · ${b.title}</div></div></div>
          <p>${TM.fmt(b.bal)} · ${b.wins}W</p>
        </div>`).join("")}</div>`;
  },

  community() {
    const s = TM.S;
    const sub = route.sub || "chat";
    const tabs = [["chat","Chat"],["friends","Friends"],["rooms","Rooms"],["clans","Clans"],["spectate","Spectate"],["gifts","Gifts"]];
    let body = "";
    if (sub==="chat") body = `<div class="feed" style="min-height:240px">${s.social.chat.slice(-20).map(c=>`<div class="feed-item"><time>${TM.ago(c.t)}</time><span><b>${TM.esc(c.from)}.</b> ${TM.esc(c.text)}</span></div>`).join("")}</div>
      <div class="btn-row" style="margin-top:8px"><input id="chatIn" class="ctrl" placeholder="Say something" style="flex:1"><button class="btn btn-gold" id="chatGo">Send</button></div>`;
    if (sub==="friends") body = (s.social.friends.map(id=>{
      const b=TM.botById(id); if(!b) return "";
      return `<div class="banner mint">${b.glyph} ${TM.esc(b.name)} · ${TM.fmt(b.bal)}
        <button class="btn" data-chal="${b.id}">Challenge</button></div>`;
    }).join("")||"<p class='disclaimer'>Add friends from the directory.</p>");
    if (sub==="rooms") body = `<div class="grid g2">
        <div class="field"><span>Room name</span><input id="rmName" value="Late table"></div>
        <div class="field"><span>Game</span><select id="rmGame"><option value="cointoss">Coin Toss</option>${TM.CATALOG.map(g=>`<option value="${g.id}">${g.name}</option>`).join("")}</select></div>
        <div class="field"><span>Min stake</span><input id="rmMin" type="number" value="10"></div>
        <div class="field"><span>Max stake</span><input id="rmMax" type="number" value="200"></div>
      </div>
      <button class="btn btn-gold" style="margin-top:10px" id="rmGo">Create room</button>
      ${(s.rooms||[]).map(r=>`<div class="banner" style="margin-top:8px">${TM.esc(r.name)} · ${r.game} · ${r.code} · ${r.tier||s.player.roomTier}</div>`).join("")}`;
    if (sub==="clans") body = s.social.clan
      ? `<p><b>${TM.esc(s.social.clan.name)}</b> · treasury ${TM.fmt(s.social.clan.treasury)} · level ${Math.min(10,1+Math.floor((s.social.clan.treasury||0)/1000))}</p>
         <div class="btn-row"><input id="clanPay" type="number" value="100" class="ctrl" style="max-width:140px"><button class="btn" id="clanGive">Contribute MAIN</button>
         <button class="btn" id="clanPlay">Team match</button></div>`
      : `<div class="field"><span>Clan name</span><input id="clanName" placeholder="Found a clan"><button class="btn btn-gold" id="clanMake" style="margin-top:8px">Create</button></div>`;
    if (sub==="spectate") {
      const g = s.games[0];
      body = g ? `<div class="stage" style="min-height:200px"><div class="result-splash"><p class="big">${TM.esc(g.game)}</p><p>${TM.esc(g.detail||"")}</p><p>${TM.esc(g.opp)} · pot ${TM.fmt((g.stake||0)*2)}</p></div></div>` : "<p class='disclaimer'>No live match to watch yet. Play one.</p>";
    }
    if (sub==="gifts") body = `<p class="disclaimer">Gift MAIN to a friend. 2% fee, daily cap applies.</p>
      <div class="btn-row"><select id="giftWho" class="ctrl">${s.social.friends.map(id=>{const b=TM.botById(id);return b?`<option value="${b.id}">${b.name}</option>`:""}).join("")}</select>
      <input id="giftAmt" type="number" value="50" class="ctrl" style="max-width:120px"><button class="btn btn-gold" id="giftGo">Send gift</button></div>`;
    return head("Social Hub", "Friends, rooms, clans, chat. All local, all play coins.") +
      `<div class="btn-row" style="margin-bottom:12px">${tabs.map(t=>`<button class="btn ${sub===t[0]?"btn-gold":""}" data-go="community" data-sub="${t[0]}">${t[1]}</button>`).join("")}</div>
      <div class="card">${body}</div>`;
  },

  shop() {
    const s = TM.S;
    const cat = route.sub || "skins";
    const items = TM.SHOP.filter(i => i.cat===cat);
    return head("Cosmetics shop", "Purchases debit MAIN and stay on this browser. VIP discounts apply at Black Diamond and above.") +
      `<div class="btn-row" style="margin-bottom:12px">${TM.SHOP_CATS.map(c=>`<button class="btn ${cat===c.id?"btn-gold":""}" data-go="shop" data-sub="${c.id}">${c.name}</button>`).join("")}</div>
      <div class="grid g4">${items.map(it=>{
        const own = s.player.owned.includes(it.id);
        const eq = s.player.equip[it.cat]===it.id;
        return `<div class="card shop-item">
          <div class="swatch" style="background:${it.swatch||"#1c2233"};display:grid;place-items:center;font-size:28px">${it.glyph||""}</div>
          <b>${TM.esc(it.name)}</b>
          <div class="price">${it.price? TM.fmt(it.price)+" MAIN":"Free"}</div>
          <button class="btn ${eq?"btn-teal":"btn-gold"}" data-buy="${it.id}">${eq?"Equipped": own?"Equip":"Buy"}</button>
        </div>`;
      }).join("")}</div>`;
  },

  season() {
    const s = TM.S;
    const vip = TM.vip(s);
    const unlocked = Object.keys(s.player.achievements).length;
    return head("VIP, quests, season", "Monthly wager sets your tier. Rakeback accrues from Coin Toss and catalog fees.") +
      `<div class="grid g3">
        ${kpi(vip.name, TM.fmt(s.player.monthWagered), "wagered this UTC month")}
        ${kpi("Pending rakeback", TM.fmt(s.player.pendingRake), `<button class='btn' id='claimRake'>Claim</button>`)}
        ${kpi("Login streak", (s.player.loginStreak||0)+" days", "Season ends "+new Date(s.seasonEnd).toUTCString())}
      </div>
      <div class="card" style="margin-top:14px"><h3>Quests</h3>
        ${TM.QUESTS.map(q=>{
          const n = s.player[q.key]||0;
          const done = n>=q.target;
          const claimed = s.player.claimedQ&&s.player.claimedQ[q.id];
          return `<div style="display:flex;justify-content:space-between;align-items:center;margin:8px 0">
            <div><b>${q.name}</b> · ${Math.min(n,q.target)}/${q.target}<div class="progress"><i style="width:${Math.min(100,n/q.target*100)}%"></i></div></div>
            <button class="btn ${claimed?"btn-teal":"btn-gold"}" data-quest="${q.id}" ${!done||claimed?"disabled":""}>${claimed?"Claimed":"+"+q.reward}</button>
          </div>`;
        }).join("")}
      </div>
      <div class="card" style="margin-top:14px"><h3>Achievements · ${unlocked}/${TM.ACHIEVEMENTS.length}</h3>
        <div class="grid g3">${TM.ACHIEVEMENTS.map(a=>`<div class="card" style="padding:10px;box-shadow:none">
          <b style="color:${s.player.achievements[a.id]?"var(--gold)":"var(--muted)"}">${TM.esc(a.name)}</b>
          <div class="disclaimer">${TM.esc(a.hint)} · +${a.reward}</div>
        </div>`).join("")}</div>
      </div>`;
  },

  plus() {
    const s = TM.S;
    const sub = route.sub || "pass";
    const tabs = [["pass","Battle Pass"],["cal","Login calendar"],["weekly","Weekly"],["prestige","Prestige"],["skill","Skill"]];
    let body = "";
    if (sub==="pass") body = `<p>Monthly free track. Premium is 400 MAIN and doubles later nodes in this demo.</p>
      <button class="btn btn-gold" id="buyPass" ${s.player.passPremium?"disabled":""}>${s.player.passPremium?"Premium owned":"Buy premium · 400"}</button>
      <div class="grid g4" style="margin-top:12px">${[1,2,3,4,5,6,7,8].map(i=>{
        const need = i*80; const ok = s.player.xp>=need;
        const claimed = s.player.claimedPass[i];
        return `<div class="card"><b>Node ${i}</b><div class="disclaimer">${need} XP</div>
          <button class="btn" data-pass="${i}" ${!ok||claimed?"disabled":""}>${claimed?"Done":"+ "+(20*i)}</button></div>`;
      }).join("")}</div>`;
    if (sub==="cal") body = `<div class="grid g4">${[1,2,3,4,5,6,7].map(d=>`<div class="card ${s.player.loginStreak>=d?"kpi up":""}"><b>Day ${d}</b><div>${Math.min(175,50+25*(d-1))} BONUS</div></div>`).join("")}</div><p class="disclaimer">Day 7 also grants a cosmetic in the full design. Streak is already paying BONUS on login.</p>`;
    if (sub==="weekly") body = `<p>Win 5 · play 3 distinct games · hold a 3-streak.</p>
      <p>Wins ${s.player.qWins||0}/5 · catalog variety ${Object.keys(s.player.catalogPlayed).length} · streak ${s.player.streak}</p>
      <button class="btn btn-gold" id="weekClaim">Claim 200 BONUS if complete</button>`;
    if (sub==="prestige") body = `<p>From level 10 you may reset to 1 for a permanent +5% XP badge and the Rainbow frame. Current prestige ${s.player.prestige}.</p>
      <button class="btn btn-rose" id="prestigeGo">Prestige now</button>`;
    if (sub==="skill") {
      const tiers = ["Rookie","Bronze","Silver","Gold","Elite"];
      const idx = Math.min(4, Math.floor(s.player.wins/15));
      body = `<p>Preferred bot matching uses ${tiers[idx]} based on wins. Fallback still fills any seat.</p>`;
    }
    return head("Progress+", "Battle Pass, calendar, weekly goals, prestige, skill tiers.") +
      `<div class="btn-row" style="margin-bottom:12px">${tabs.map(t=>`<button class="btn ${sub===t[0]?"btn-gold":""}" data-go="plus" data-sub="${t[0]}">${t[1]}</button>`).join("")}</div>
      <div class="card">${body}</div>`;
  },

  econ() {
    const s = TM.S;
    const sub = route.sub || "crates";
    const tabs = [["crates","Crates"],["trade","Trading Post"],["stake","Staking"],["sub","Subscriptions"],["boost","Boosters"],["util","Coin utilities"]];
    let body = "";
    if (sub==="crates") body = [["Common",75],["Rare",200],["Epic",500],["Legendary",1000]].map(([n,p])=>
      `<button class="btn" data-crate="${p}" style="margin:4px">${n} · ${p}</button>`).join("") + `<p class="disclaimer">Grants 1–3 cosmetics at that rarity floor.</p>`;
    if (sub==="trade") {
      const listings = (s.trade || seedTrade());
      body = listings.map((L,i)=>`<div class="banner">${TM.esc(L.name)} · ${L.price} MAIN <button class="btn" data-trade="${i}">Buy</button></div>`).join("");
    }
    if (sub==="stake") body = `<p>Staked ${TM.fmt(s.economy.stake)} · interest due ${TM.fmt(s.economy.interestDue)}</p>
      <div class="btn-row"><input id="stkN" type="number" value="100" class="ctrl" style="max-width:120px">
      <button class="btn" id="stkIn">Stake</button><button class="btn" id="stkOut">Unstake</button>
      <button class="btn" id="stkWeek">Advance 7 days</button><button class="btn btn-gold" id="stkClaim">Claim interest</button></div>`;
    if (sub==="sub") body = [["Plus",300],["Pro",700],["Elite",1500]].map(([n,p])=>
      `<button class="btn" data-subbuy="${p}" style="margin:4px">${n} · ${p} / 30d</button>`).join("") +
      `<p class="disclaimer">${s.economy.sub? "Active until "+new Date(s.economy.sub.until).toDateString(): "No subscription."}</p>`;
    if (sub==="boost") body = `<button class="btn" id="bXP">2× XP · 1 hour · 200</button>
      <button class="btn" id="bRK">+5% rakeback · 24h · 300</button>
      <p class="disclaimer">XP boost ${s.economy.boostXP>Date.now()?"live":"off"} · rake boost ${s.economy.boostRake>Date.now()?"live":"off"}</p>`;
    if (sub==="util") body = `<h3>Crafting</h3>
      <button class="btn" data-craft="150">Uncommon 150</button>
      <button class="btn" data-craft="400">Rare 400</button>
      <button class="btn" data-craft="800">Epic 800</button>
      <h3 style="margin-top:12px">Event tickets · you have ${s.player.tickets}</h3>
      <button class="btn" data-tix="1,100">1 / 100</button>
      <button class="btn" data-tix="3,250">3 / 250</button>
      <button class="btn" data-tix="7,500">7 / 500</button>
      <h3 style="margin-top:12px">Room upgrades</h3>
      ${[["basic",0],["neon",200],["royal",500],["cosmic",1000]].map(([n,p])=>`<button class="btn" data-room="${n},${p}">${n} · ${p||"free"}</button>`).join("")}
      <p class="disclaimer">Clan treasury lives under Social Hub. Utilities never change odds.</p>`;
    return head("Economy+", "Crates, trade, staking, subscriptions, boosters, and non-wager coin sinks.") +
      `<div class="btn-row" style="margin-bottom:12px">${tabs.map(t=>`<button class="btn ${sub===t[0]?"btn-gold":""}" data-go="econ" data-sub="${t[0]}">${t[1]}</button>`).join("")}</div>
      <div class="card">${body}</div>`;
  },

  wallet() {
    const s = TM.S;
    const w = s.wallet;
    const tu = (s.topups || TM.emptyTopups());
    return head("Wallet", "The 1,000 welcome grant is BONUS. You must top up MAIN before any bet. Each stake is " + Math.round(TM.mainShare()*100) + "% MAIN and the rest BONUS.") +
      `<div class="grid g5">
        ${kpi("MAIN", TM.fmt(w.main),"winnings & spend")}
        ${kpi("BONUS", TM.fmt(w.bonus),"capped stake")}
        ${kpi("REFERRAL", TM.fmt(w.referral),"capped stake")}
        ${kpi("RAKEBACK", TM.fmt(w.rakeback),"claimed VIP")}
        ${kpi("BANK", TM.fmt(w.bank),"parked")}
      </div>
      <div class="grid g2" style="margin-top:14px">
        ${TM.playerTopupSheet()}
        ${TM.botTopupSheet()}
      </div>
      <div class="grid g2" style="margin-top:14px">
        <div class="card">
          <h3>Top up play coins</h3>
          <p class="disclaimer">${s.config.firstTopup && !s.player.claimedFirstTopup ? "First top-up currently grants +"+(s.config.firstTopupPct||50)+"% BONUS." : "Promo unavailable or already claimed."}</p>
          <div class="btn-row"><input id="tuAmt" type="number" value="200" min="100" class="ctrl" style="max-width:140px"><button class="btn btn-gold" id="tuGo">Top up</button></div>
        </div>
        <div class="card">
          <h3>Park / unpark</h3>
          <div class="btn-row"><input id="pkAmt" type="number" value="100" class="ctrl" style="max-width:120px">
            <button class="btn" id="pkIn">Park</button><button class="btn" id="pkOut">Unpark</button></div>
          <h3 style="margin-top:14px">Transfer</h3>
          <div class="btn-row">
            <select id="xfWho" class="ctrl">${s.bots.slice(0,30).map(b=>`<option value="${b.id}">${b.name}</option>`).join("")}</select>
            <input id="xfAmt" type="number" value="50" class="ctrl" style="max-width:100px">
            <button class="btn" id="xfGo">Send</button>
          </div>
        </div>
      </div>
      <div class="card" style="margin-top:14px"><h3>Recent top-ups</h3>
        <div class="table-wrap"><table><tr><th>When</th><th>Who</th><th>Kind</th><th>Base</th><th>Bonus</th><th>Total</th></tr>
        ${(tu.log||[]).slice(0,8).map(x=>`<tr><td>${TM.ago(x.t)}</td><td>${TM.esc(x.name)}</td><td>${x.kind}</td><td>${TM.fmt(x.base)}</td><td>${TM.fmt(x.bonus)}</td><td>${TM.fmt(x.total)}</td></tr>`).join("")||"<tr><td colspan='6'>None yet. Top up here, or leave the tables open so bots refill.</td></tr>"}
        </table></div>
      </div>
      <div class="card" style="margin-top:14px"><h3>Ledger</h3>
        <div class="table-wrap"><table><tr><th>When</th><th>Type</th><th>Δ</th><th>Note</th></tr>
        ${s.ledger.slice(0,16).map(l=>`<tr><td>${TM.ago(l.t)}</td><td>${l.type}</td><td>${TM.delta(l.delta)}</td><td>${TM.esc(l.note)}</td></tr>`).join("")}
        </table></div>
      </div>`;
  },

  stats() {
    const s = TM.S;
    const wr = s.player.games ? Math.round(s.player.wins/s.player.games*100) : 0;
    const roi = s.player.wagered ? Math.round(s.player.net/s.player.wagered*100) : 0;
    const n = s.stats.heads + s.stats.tails;
    const z = n ? ((s.stats.heads - n/2) / Math.sqrt(n/4)).toFixed(2) : "0.00";
    const bars = s.games.slice(0,30).reverse().map(g=>{
      const h = Math.min(40, Math.abs(g.delta||0)/20);
      return `<i title="${g.delta}" style="display:inline-block;width:8px;margin:0 2px;height:${Math.max(4,h)}px;background:${(g.delta||0)>=0?"var(--mint)":"var(--rose)"};vertical-align:bottom"></i>`;
    }).join("");
    return head("Statistics", "Career totals plus the same top-up and house sheets as the admin desk.") +
      `<div class="grid g4">
        ${kpi("Games", s.player.games, wr+"% win")}
        ${kpi("Net", TM.delta(s.player.net), "ROI "+roi+"%", s.player.net>=0?"up":"down")}
        ${kpi("Wagered", TM.fmt(s.player.wagered), "fees "+TM.fmt(s.player.fees))}
        ${kpi("Global z", z, s.stats.heads+"H / "+s.stats.tails+"T")}
      </div>
      <div class="grid g2" style="margin-top:14px">
        ${TM.gamesSheet()}
        ${TM.pnlSheet()}
      </div>
      <div class="grid g3" style="margin-top:14px">
        ${TM.playerTopupSheet()}
        ${TM.botTopupSheet()}
        ${TM.withdrawSheet()}
      </div>
      <div class="card" style="margin-top:14px"><h3>Last 30 results</h3><div style="height:56px;display:flex;align-items:flex-end">${bars||"—"}</div></div>`;
  },

  history() {
    const s = TM.S;
    const cat = route.sub || "all";
    const tabs = [["all","All Games"],["catalog","Catalog"],["arcade","Arcade+"],["social","Social"]];
    let rows = s.games;
    if (cat==="catalog") rows = s.games.filter(g=>g.kind==="catalog");
    if (cat==="arcade") rows = s.games.filter(g=>g.kind==="arcade");
    if (cat==="social") rows = s.games.filter(g=>g.kind==="cup"||g.kind==="trny");
    return head("History", "Searchable local records. Export writes JSON from this browser.") +
      `<div class="btn-row" style="margin-bottom:10px">${tabs.map(t=>`<button class="btn ${cat===t[0]?"btn-gold":""}" data-go="history" data-sub="${t[0]}">${t[1]}</button>`).join("")}
        <button class="btn" id="histEx">Export JSON</button></div>
      <div class="card table-wrap"><table><tr><th>When</th><th>Game</th><th>Opp</th><th>Stake</th><th>Result</th><th>Δ</th></tr>
      ${rows.slice(0,40).map(g=>`<tr>
        <td>${TM.ago(g.t)}</td><td>${TM.esc(g.game)}</td><td>${TM.esc(g.opp||"—")}</td>
        <td>${TM.fmt(g.stake)}</td><td><span class="pill ${g.result}">${g.result}</span></td>
        <td>${TM.delta(g.delta)}</td></tr>`).join("")}
      </table></div>`;
  },

  verify() {
    const last = TM.S.games.find(g => g.proof);
    return head("Fairness verifier", "Recompute the merged SHA-256 locally. Seeds in this demo are generated in the same browser — educational, not a production commit service.") +
      `<div class="card grid" style="gap:10px">
        <div class="field"><span>Server seed</span><textarea id="vSeed">${last?.proof?.serverSeed||""}</textarea></div>
        <div class="field"><span>Maker hash</span><input id="vM" value="${last?.proof?.makerHash||""}"></div>
        <div class="field"><span>Taker hash</span><input id="vT" value="${last?.proof?.takerHash||""}"></div>
        <div class="field"><span>Game ID</span><input id="vG" value="${last?.proof?.gameId||""}"></div>
        <button class="btn btn-gold" id="vGo">Recompute</button>
        <div id="vOut" class="proof">${last?.proof? "Loaded last retained proof. Game IDs in history may differ from the internal id — paste the four values from a result card.":""}</div>
      </div>`;
  },

  services() {
    const s = TM.S;
    const a = s.settings.a11y;
    const rg = s.settings.rg;
    return head("Safety & Services", "Responsible-gaming controls, accessibility, language, and demo platform tools.") +
      `<div class="grid g2">
        <div class="card">
          <h3>Responsible gaming</h3>
          <div class="field"><span>Session loss limit</span><input id="rgLoss" type="number" value="${rg.lossLimit}"></div>
          <div class="field"><span>Auto-rebet stop</span><input id="rgAuto" type="number" step="50" value="${s.settings.autoRebetStop}"></div>
          <div class="field"><span>Session minutes (0 = off)</span><input id="rgSes" type="number" value="${rg.sessionMin}"></div>
          <div class="field"><span>Daily top-up cap (0 = off)</span><input id="rgDay" type="number" value="${rg.depDay}"></div>
          <div class="btn-row" style="margin-top:10px">
            <button class="btn" id="rgSave">Save limits</button>
            <button class="btn" id="rgEx60">Exclude 60s</button>
            <button class="btn btn-rose" id="rgPerm">Permanent exclude</button>
          </div>
          <p class="disclaimer">Demo locks live in localStorage. Production RG must be server-enforced.</p>
        </div>
        <div class="card">
          <h3>Accessibility</h3>
          <label class="disclaimer"><input type="checkbox" id="axHC" ${a.hc?"checked":""}> High contrast</label><br>
          <label class="disclaimer"><input type="checkbox" id="axRM" ${a.reduce?"checked":""}> Reduced motion</label><br>
          <label class="disclaimer"><input type="checkbox" id="axHint" ${a.hints?"checked":""}> Screen-reader hints</label>
          <div class="field" style="margin-top:8px"><span>Text scale</span>
            <select id="axSc">${[90,100,110,120,130].map(n=>`<option ${a.scale===n?"selected":""}>${n}</option>`).join("")}</select></div>
          <div class="field"><span>Colour vision</span>
            <select id="axCV">${["standard","deuteranopia","protanopia","tritanopia"].map(n=>`<option ${a.cv===n?"selected":""}>${n}</option>`).join("")}</select></div>
          <button class="btn" style="margin-top:8px" id="axGo">Apply</button>
          <h3 style="margin-top:16px">Language</h3>
          <div class="seg">${["en","hi"].map(l=>`<button data-lang="${l}" class="${s.settings.lang===l?"on":""}">${l.toUpperCase()}</button>`).join("")}</div>
        </div>
      </div>
      <div class="card" style="margin-top:14px">
        <h3>Presets</h3>
        <div class="btn-row"><input id="prName" placeholder="Name" class="ctrl" style="max-width:160px">
          <input id="prStake" type="number" value="50" class="ctrl" style="max-width:100px">
          <button class="btn" id="prSave">Save Coin Toss preset</button></div>
        ${(s.settings.presets||[]).map((p,i)=>`<div class="banner" style="margin-top:6px">${TM.esc(p.name)} · ${p.stake}
          <button class="btn" data-pr="${i}">Apply</button>
          <button class="btn" data-prd="${i}">Delete</button></div>`).join("")}
      </div>`;
  },

  updates() {
    return head("What's on the table", "A condensed tour of the playable demo. Suggested production work stays on the roadmap.") +
      `<div class="grid g3">${TM.DIRECTORY.map(d=>`<div class="card">
        <div class="code">${d[1]} · ${d[0]}</div>
        <h3>${TM.esc(d[2])}</h3>
        <span class="pill ${d[3]==="Implemented"?"win":d[3]==="Suggested"?"carry":"split"}">${d[3]}</span>
        <p>${TM.esc(d[4])}</p>
        ${d[5]?`<button class="btn" data-go="${d[5]}">Open</button>`:"<span class='disclaimer'>Roadmap item</span>"}
      </div>`).join("")}</div>
      <p class="disclaimer" style="margin-top:16px">${TM.t("playcoins")}</p>`;
  }
};

function catalogPlay(id) {
  const g = TM.catalogById(id);
  if (!g) return head("Missing", "Unknown catalog game.");
  const s = TM.S;
  const fav = (s.settings.favorites||[]).includes(id);
  const open = s.waiting.filter(w => w.kind==="catalog" && w.gameId===id);
  const hist = s.games.filter(x => x.game===id).slice(0,6);
  let pickUI = "";
  if (g.pick.type==="none") pickUI = `<p class="disclaimer">No pick required. Two seats, proof decides.</p>`;
  else if (g.pick.type==="number") pickUI = `<div class="field"><span>Your number · ${g.pick.min}–${g.pick.max}</span>
    <input id="cPick" type="number" min="${g.pick.min}" max="${g.pick.max}" value="${g.pick.min}"></div>`;
  else pickUI = `<div class="pick-grid" id="cPicks">${g.pick.list.map((p,i)=>`<button class="pick ${i===0?"on":""}" data-pick="${TM.esc(p)}">${TM.esc(p)}</button>`).join("")}</div>`;
  return `<div class="view-head"><div>
      <div class="code">${g.code}</div>
      <h2>${TM.esc(g.name)}</h2>
      <p>${TM.esc(g.blurb)} ${TM.esc(g.edge||"")}</p>
    </div>
    <div class="btn-row">
      <button class="btn" id="favCat">${fav?"★ Favorited":"☆ Favorite"}</button>
      <button class="btn" data-go="games">All games</button>
    </div></div>
    <div class="grid g2">
      <div class="card">
        ${pickUI}
        <div class="field" style="margin-top:10px"><span>Stake</span><input id="cStake" type="number" min="10" value="50"></div>
        <button class="btn btn-gold full" style="margin-top:12px" id="cPost">Post to waiting room</button>
        <p class="disclaimer">Carry pool ${TM.fmt(s.carry[id]||0)}</p>
      </div>
      <div class="card">
        <h3>Waiting room</h3>
        ${open.map(w=>`<div class="banner mint">${TM.esc(w.ownerName)} · ${TM.esc(String(w.pick||"—"))} · ${TM.fmt(w.stake)}
          ${w.owner==="bot"?`<button class="btn" data-take="${w.id}">Take</button>`:`<button class="btn" data-cancel="${w.id}">Cancel</button>`}
        </div>`).join("")||"<p class='disclaimer'>Empty. Your post will auto-match a bot.</p>"}
        <h3 style="margin-top:12px">Recent</h3>
        ${hist.map(h=>`<div class="feed-item"><time>${TM.ago(h.t)}</time><span class="pill ${h.result}">${h.result}</span> ${TM.esc(h.detail||"")} · ${TM.delta(h.delta)}</div>`).join("")||"<p class='disclaimer'>No local history yet.</p>"}
      </div>
    </div>`;
}

function arcadePlay(id) {
  const g = TM.arcadeById(id);
  if (!g) return head("Missing","Unknown Arcade game.");
  const fav = (TM.S.settings.arcadeFav||[]).includes(id);
  let extra = `<div class="field"><span>Stake</span><input id="arStake" type="number" min="10" value="50"></div>`;
  if (id==="dice") extra += `<div class="seg" id="diceMode"><button class="on" data-mode="HIGH">HIGH 8–12</button><button data-mode="LOW">LOW 2–6</button><button data-mode="DOUBLE">DOUBLE 30×</button></div>`;
  if (id==="scratch") extra = `<div class="seg" id="scTier"><button class="on" data-st="25">Common 25</button><button data-st="75">Rare 75</button><button data-st="200">Epic 200</button></div>`;
  if (id==="keno") extra += `<div id="kenoBoard" class="pick-grid">${Array.from({length:20},(_,i)=>`<button class="pick" data-k="${i+1}">${i+1}</button>`).join("")}</div>`;
  if (id==="treasure") extra += `<div class="pick-grid">${Array.from({length:9},(_,i)=>`<button class="pick" data-tile="${i+1}">${i+1}</button>`).join("")}</div>`;
  if (id==="dropball") extra += `<div class="field"><span>Column 1–7</span><input id="dbCol" type="number" min="1" max="7" value="4"></div>`;
  if (id==="tower") extra += `<div class="seg" id="twF"><button class="on" data-fl="3">3 · 1.6×</button><button data-fl="5">5 · 3×</button><button data-fl="7">7 · 7×</button></div>`;
  if (id==="penalty") extra += `<div class="seg" id="penD"><button class="on" data-dir="LEFT">LEFT</button><button data-dir="CENTER">CENTER</button><button data-dir="RIGHT">RIGHT</button></div>`;
  if (id==="vault") extra += `<div class="pick-grid">${[1,2,3,4,5].map(n=>`<button class="pick" data-key="${n}">Key ${n}</button>`).join("")}</div>`;
  if (id==="fishing") extra += `<div class="seg" id="bait"><button class="on" data-bait="Basic">Basic</button><button data-bait="Shiny">Shiny</button><button data-bait="Legend">Legend</button></div>`;
  if (id==="trivia") extra += `<div id="trivQ" class="disclaimer">Press play to draw today's question.</div>`;
  if (id==="wheel") extra += `<button class="btn" id="freeSpin">Daily free spin</button>`;
  if (id==="ladder") extra += `<div class="field"><span>Target rung 1–8</span><input id="ladR" type="number" min="1" max="8" value="3"></div>`;
  const last = TM.S.arcadeLog.find(x=>x.game===id);
  return `<div class="view-head"><div><div class="code">${g.code}</div><h2>${TM.esc(g.name)}</h2><p>${TM.esc(g.blurb)}</p></div>
    <div class="btn-row"><button class="btn" id="favArc">${fav?"★ Favorited":"☆ Favorite"}</button><button class="btn" data-go="arcade">All Arcade</button></div></div>
    <div class="grid g2">
      <div class="card">${extra}<button class="btn btn-gold full" style="margin-top:12px" id="arGo">Play</button></div>
      <div class="card"><h3>Last result</h3>${last?`<p>${TM.esc(last.detail)}</p><p class="delta ${last.delta>=0?"up":"down"}">${TM.delta(last.delta)}</p><div class="proof">${last.proof}</div>`:"<p class='disclaimer'>No play yet.</p>"}
        <p class="disclaimer">Collection ${JSON.stringify(TM.S.feature.fish)}</p>
      </div>
    </div>`;
}

function recsFor() {
  const s = TM.S;
  const out = [];
  const fav = s.settings.favorites[0];
  if (fav) { const g=TM.catalogById(fav); if(g) out.push({name:g.name, why:"Saved catalog favorite", go:"games", sub:g.id}); }
  const unplayed = TM.CATALOG.find(g => !s.player.catalogPlayed[g.id]);
  if (unplayed) out.push({name:unplayed.name, why:"Unplayed catalog variety", go:"games", sub:unplayed.id});
  if (s.feature.triviaDay !== new Date().toDateString()) out.push({name:"Daily Trivia", why:"Today's attempt is still open", go:"arcade", sub:"trivia"});
  out.push({name:"Fishing Reel", why:"Grow the collection", go:"arcade", sub:"fishing"});
  return out.slice(0,4);
}

function seedTrade() {
  TM.S.trade = TM.shuffle(TM.SHOP.filter(i=>i.price>0)).slice(0,5).map(i => ({ id:i.id, name:i.name, price: Math.max(25, Math.round(i.price*.8)), bot:true }));
  return TM.S.trade;
}

function bindView() {
  $$("[data-go]").forEach(b => b.onclick = () => go(b.dataset.go, b.dataset.sub||""));
  $$("[data-take]").forEach(b => b.onclick = async () => {
    const r = await TM.takeWaiting(b.dataset.take, "player");
    if (r?.err) TM.toast(r.err,"bad"); else { TM.toast("Match settled"); render(); }
  });
  $$("[data-cancel]").forEach(b => b.onclick = () => { TM.cancelWaiting(b.dataset.cancel); render(); });
  $$("[data-buy]").forEach(b => b.onclick = () => { const r=TM.buyItem(b.dataset.buy); TM.toast(r.err||"Done", r.err?"bad":""); render(); });
  $$("[data-open-cat]").forEach(b => b.onclick = () => go("games", b.dataset.openCat));
  $$("[data-open-arc]").forEach(b => b.onclick = () => go("arcade", b.dataset.openArc));
  $$("[data-lb]").forEach(b => b.onclick = () => { window._lb=b.dataset.lb; render(); });
  $$("[data-friend]").forEach(b => b.onclick = () => {
    const id=b.dataset.friend; const f=TM.S.social.friends;
    const i=f.indexOf(id); if(i>=0) f.splice(i,1); else f.push(id);
    TM.checkAchievements(); TM.save(); render();
  });
  $$("[data-chal]").forEach(b => b.onclick = async () => {
    go("play");
    $("#stake") && ($("#stake").value = 50);
    TM.toast("Posted a public toss — a friend-aware bot will sit down.");
    await TM.postCoin({ side:"HEADS", stake:50, priv:false, taunt:"challenge" });
    render();
  });
  $$("[data-gift]").forEach(b => b.onclick = () => { const r=TM.transferTo(b.dataset.gift, 50); if(!r.err) TM.S.player.gifts++; TM.toast(r.err||"Gift sent", r.err?"bad":""); render(); });
  $$("[data-joincup]").forEach(b => b.onclick = async () => { const r=await TM.joinCup(b.dataset.joincup,"player"); TM.toast(r.err||"Cup settled", r.err?"bad":""); render(); });
  $$("[data-jointr]").forEach(b => b.onclick = () => { const r=TM.joinTrny(b.dataset.jointr); TM.toast(r.err||"Seat taken", r.err?"bad":""); render(); });
  $$("[data-quest]").forEach(b => b.onclick = () => { const r=TM.claimQuest(b.dataset.quest); TM.toast(r.err||"Quest claimed", r.err?"bad":""); render(); });
  $$("[data-lang]").forEach(b => b.onclick = () => { TM.S.settings.lang=b.dataset.lang; TM.save(); render(); });
  $$(".pick").forEach(p => p.onclick = () => {
    if (p.dataset.k) {
      p.classList.toggle("on");
      return;
    }
    p.parentElement.querySelectorAll(".pick").forEach(x=>x.classList.remove("on"));
    p.classList.add("on");
  });
  $$(".seg button").forEach(b => {
    if (b.dataset.side || b.dataset.mode || b.dataset.st || b.dataset.fl || b.dataset.dir || b.dataset.bait || b.dataset.lang) {
      b.onclick = () => { b.parentElement.querySelectorAll("button").forEach(x=>x.classList.remove("on")); b.classList.add("on"); };
    }
  });

  $("#gSearch") && ($("#gSearch").oninput = e => { window._gQ=e.target.value; render(); });
  $("#gCat") && ($("#gCat").onchange = e => { window._gCat=e.target.value; render(); });
  $("#gJump") && ($("#gJump").onchange = e => { if (e.target.value) go("games", e.target.value); });
  $("#aSearch") && ($("#aSearch").oninput = e => { window._aQ=e.target.value; render(); });
  $("#aCat") && ($("#aCat").onchange = e => { window._aCat=e.target.value; render(); });
  $("#aJump") && ($("#aJump").onchange = e => { if (e.target.value) go("arcade", e.target.value); });
  $("#pSearch") && ($("#pSearch").oninput = e => { window._pQ=e.target.value; render(); });

  $("#postPub") && ($("#postPub").onclick = () => postCoin(false));
  $("#postPriv") && ($("#postPriv").onclick = () => postCoin(true));
  $("#togSound") && ($("#togSound").onclick = () => { TM.S.settings.sound=!TM.S.settings.sound; TM.save(); render(); });
  $("#togInst") && ($("#togInst").onclick = () => { TM.S.settings.instant=!TM.S.settings.instant; TM.save(); render(); });
  $("#togAuto") && ($("#togAuto").onclick = () => { TM.S.settings.autoRebet=!TM.S.settings.autoRebet; TM.save(); render(); });
  $("#x2go") && ($("#x2go").onclick = async () => {
    const x = TM.S.x2; if(!x) return;
    const r = await TM.postCoin({ side: x.side, stake: x.stake, priv:false, taunt:"×2" });
    TM.S.x2 = null;
    if (r.err) TM.toast(r.err,"bad"); render();
  });
  $("#x2no") && ($("#x2no").onclick = () => { TM.S.x2=null; TM.save(); render(); });
  $("#toVerify") && ($("#toVerify").onclick = () => go("verify"));
  $("#cPost") && ($("#cPost").onclick = postCat);
  $("#favCat") && ($("#favCat").onclick = () => {
    const f = TM.S.settings.favorites; const i=f.indexOf(route.sub);
    if (i>=0) f.splice(i,1); else f.push(route.sub); TM.save(); render();
  });
  $("#favArc") && ($("#favArc").onclick = () => {
    const f = TM.S.settings.arcadeFav; const i=f.indexOf(route.sub);
    if (i>=0) f.splice(i,1); else f.push(route.sub); TM.save(); render();
  });
  $("#arGo") && ($("#arGo").onclick = playArc);
  $("#freeSpin") && ($("#freeSpin").onclick = async () => {
    const r = await TM.playArcade("wheel", { free:true });
    TM.toast(r.err || r.rec.detail, r.err?"bad":""); render();
  });
  $("#cupGo") && ($("#cupGo").onclick = () => {
    const r = TM.createCup({ format: $("#cupFmt").value, entry: +$("#cupEntry").value, by:"player" });
    TM.toast(r.err||"Cup posted", r.err?"bad":""); render();
  });
  $("#trGo") && ($("#trGo").onclick = () => { TM.createTrny({ size:+$("#trSize").value, entry:+$("#trEntry").value, format:$("#trFmt").value }); TM.toast("Bracket opened"); render(); });
  $("#claimRake") && ($("#claimRake").onclick = () => { const r=TM.claimRake(); TM.toast(r.err||("Claimed "+r.n), r.err?"bad":""); render(); });
  $("#tuGo") && ($("#tuGo").onclick = () => { const r=TM.topup(+$("#tuAmt").value); TM.toast(r.err||("Topped up"+(r.bonus?" +"+r.bonus+" BONUS":"")), r.err?"bad":""); render(); });
  $("#pkIn") && ($("#pkIn").onclick = () => { const r=TM.park(+$("#pkAmt").value); TM.toast(r.err||"Parked", r.err?"bad":""); render(); });
  $("#pkOut") && ($("#pkOut").onclick = () => { const r=TM.unpark(+$("#pkAmt").value); TM.toast(r.err||"Returned", r.err?"bad":""); render(); });
  $("#xfGo") && ($("#xfGo").onclick = () => { const r=TM.transferTo($("#xfWho").value, +$("#xfAmt").value); TM.toast(r.err||"Sent", r.err?"bad":""); render(); });
  $("#vGo") && ($("#vGo").onclick = async () => {
    const r = await TM.verifyProof({
      serverSeed: $("#vSeed").value.trim(),
      makerHash: $("#vM").value.trim(),
      takerHash: $("#vT").value.trim(),
      gameId: $("#vG").value.trim()
    });
    $("#vOut").textContent = r.err || (`commit ${r.commit}\ncombined ${r.combined}\nfinal ${r.finalHash}\nfirst ${r.first} → ${r.result}${r.jackpot?" · jackpot byte":""}`);
  });
  $("#chatGo") && ($("#chatGo").onclick = () => {
    const t = $("#chatIn").value.trim(); if(!t) return;
    TM.S.social.chat.push({ t:Date.now(), from:TM.S.player.name, text:t.slice(0,140) });
    TM.S.player.chatSent++;
    TM.S.social.chat.push({ t:Date.now(), from: TM.pick(TM.S.bots).name, text: TM.pick(["nice","copy that","taking the next seat","gg"]) });
    TM.checkAchievements(); TM.save(); render();
  });
  $("#rmGo") && ($("#rmGo").onclick = () => {
    TM.S.rooms = TM.S.rooms || [];
    TM.S.rooms.push({ name:$("#rmName").value, game:$("#rmGame").value, min:+$("#rmMin").value, max:+$("#rmMax").value, code: TM.uid().slice(0,6).toUpperCase(), tier: TM.S.player.roomTier });
    TM.S.player.roomsCreated++; TM.checkAchievements(); TM.save(); render();
  });
  $("#clanMake") && ($("#clanMake").onclick = () => {
    const n = $("#clanName").value.trim() || "Table Club";
    TM.S.social.clan = { name:n, treasury:0, members:[TM.S.player.name] };
    TM.save(); render();
  });
  $("#clanGive") && ($("#clanGive").onclick = () => {
    const n = Math.max(50, +$("#clanPay").value||50);
    if (!TM.debitMain(n, "Clan treasury")) return TM.toast("Need MAIN","bad");
    TM.S.social.clan.treasury += n; TM.S.sinks += n; TM.save(); render();
  });
  $("#clanPlay") && ($("#clanPlay").onclick = () => {
    TM.S.player.clanGames++; TM.checkAchievements();
    TM.S.wallet.bonus += 20; TM.toast("Team match simulated · +20 BONUS"); TM.save(); render();
  });
  $("#giftGo") && ($("#giftGo").onclick = () => {
    const id = $("#giftWho")?.value; if(!id) return TM.toast("Add a friend first","bad");
    const r = TM.transferTo(id, +$("#giftAmt").value);
    if (!r.err) TM.S.player.gifts++;
    TM.toast(r.err||"Gift sent", r.err?"bad":""); render();
  });
  $("#buyPass") && ($("#buyPass").onclick = () => {
    if (!TM.debitMain(400,"Battle Pass")) return TM.toast("Need 400 MAIN","bad");
    TM.S.player.passPremium = true; TM.S.house.shop += 400; TM.S.sinks += 400; TM.save(); render();
  });
  $$("[data-pass]").forEach(b => b.onclick = () => {
    const i=+b.dataset.pass, rew=20*i*(TM.S.player.passPremium?2:1);
    TM.S.player.claimedPass[i]=true; TM.S.wallet.bonus += rew; TM.save(); render();
  });
  $("#weekClaim") && ($("#weekClaim").onclick = () => {
    if ((TM.S.player.qWins||0)>=5 && Object.keys(TM.S.player.catalogPlayed).length>=3 && TM.S.player.bestStreak>=3) {
      if (TM.S.player.weekClaimed) return TM.toast("Already claimed","bad");
      TM.S.player.weekClaimed = true; TM.S.wallet.bonus += 200; TM.toast("+200 BONUS"); TM.save(); render();
    } else TM.toast("Weekly goals incomplete","bad");
  });
  $("#prestigeGo") && ($("#prestigeGo").onclick = () => {
    if (TM.S.player.level<10) return TM.toast("Reach level 10","bad");
    TM.S.player.prestige++; TM.S.player.xp=0; TM.S.player.level=1;
    if (!TM.S.player.owned.includes("fr-rain")) TM.S.player.owned.push("fr-rain");
    TM.S.player.equip.frames="fr-rain"; TM.save(); render();
  });
  $$("[data-crate]").forEach(b => b.onclick = () => {
    const p=+b.dataset.crate;
    if (!TM.debitMain(p,"Crate")) return TM.toast("Need MAIN","bad");
    TM.S.house.shop+=p; TM.S.sinks+=p;
    const pool = TM.SHOP.filter(i=>i.price>0);
    const n = p>=500? 2+Math.floor(Math.random()*2) : 1+Math.floor(Math.random()*3);
    for (let i=0;i<n;i++){ const it=TM.pick(pool); if(!TM.S.player.owned.includes(it.id)) TM.S.player.owned.push(it.id); }
    TM.toast("Crate opened · "+n+" items"); TM.save(); render();
  });
  $$("[data-trade]").forEach(b => b.onclick = () => {
    const L = TM.S.trade[+b.dataset.trade];
    if (!L || !TM.debitMain(L.price,"Trading Post")) return TM.toast("Need MAIN","bad");
    const fee = Math.round(L.price*.1);
    TM.S.house.transfers += fee; TM.S.sinks += fee;
    if (!TM.S.player.owned.includes(L.id)) TM.S.player.owned.push(L.id);
    TM.S.trade.splice(+b.dataset.trade,1); TM.save(); render();
  });
  $("#stkIn") && ($("#stkIn").onclick = () => {
    const n=+$("#stkN").value; if(n<100) return TM.toast("Min 100","bad");
    if(!TM.debitMain(n,"Stake")) return TM.toast("Need MAIN","bad");
    TM.S.economy.stake += n; TM.save(); render();
  });
  $("#stkOut") && ($("#stkOut").onclick = () => {
    const n=+$("#stkN").value; if(n>TM.S.economy.stake) return TM.toast("Not enough staked","bad");
    TM.S.economy.stake -= n; TM.S.wallet.main += n; TM.save(); render();
  });
  $("#stkWeek") && ($("#stkWeek").onclick = () => {
    TM.S.economy.interestDue += Math.round(TM.S.economy.stake * .01);
    TM.save(); render();
  });
  $("#stkClaim") && ($("#stkClaim").onclick = () => {
    const n = Math.min(500, TM.S.economy.interestDue);
    if(!n) return TM.toast("Nothing due","bad");
    TM.S.economy.interestDue -= n; TM.S.wallet.bonus += n; TM.S.taps += n; TM.S.house.promo += n; TM.save(); render();
  });
  $$("[data-subbuy]").forEach(b => b.onclick = () => {
    const p=+b.dataset.subbuy;
    if(!TM.debitMain(p,"Subscription")) return TM.toast("Need MAIN","bad");
    TM.S.house.shop+=p; TM.S.sinks+=p;
    const until = Math.max(Date.now(), TM.S.economy.sub?.until||0) + 30*86400000;
    TM.S.economy.sub = { tier:p, until }; TM.save(); render();
  });
  $("#bXP") && ($("#bXP").onclick = () => {
    if(!TM.debitMain(200,"XP booster")) return TM.toast("Need MAIN","bad");
    TM.S.house.shop+=200; TM.S.sinks+=200;
    TM.S.economy.boostXP = Math.max(Date.now(), TM.S.economy.boostXP) + 3600000; TM.save(); render();
  });
  $("#bRK") && ($("#bRK").onclick = () => {
    if(!TM.debitMain(300,"Rake booster")) return TM.toast("Need MAIN","bad");
    TM.S.house.shop+=300; TM.S.sinks+=300;
    TM.S.economy.boostRake = Math.max(Date.now(), TM.S.economy.boostRake) + 86400000; TM.save(); render();
  });
  $$("[data-craft]").forEach(b => b.onclick = () => {
    const p=+b.dataset.craft;
    if(!TM.debitMain(p,"Craft")) return TM.toast("Need MAIN","bad");
    TM.S.house.shop+=p; TM.S.sinks+=p; TM.S.player.crafts++;
    const it = TM.pick(TM.SHOP.filter(i=>i.price >= (p===800?200:p===400?80:0)));
    if(it && !TM.S.player.owned.includes(it.id)) TM.S.player.owned.push(it.id);
    TM.toast("Crafted "+(it?.name||"item")); TM.save(); render();
  });
  $$("[data-tix]").forEach(b => b.onclick = () => {
    const [n,p] = b.dataset.tix.split(",").map(Number);
    if(!TM.debitMain(p,"Tickets")) return TM.toast("Need MAIN","bad");
    TM.S.house.shop+=p; TM.S.sinks+=p; TM.S.player.tickets += n; TM.save(); render();
  });
  $$("[data-room]").forEach(b => b.onclick = () => {
    const [n,p] = b.dataset.room.split(",");
    if(+p && !TM.debitMain(+p,"Room upgrade")) return TM.toast("Need MAIN","bad");
    if(+p){ TM.S.house.shop+=+p; TM.S.sinks+=+p; }
    TM.S.player.roomTier = n; TM.save(); render();
  });
  $("#rgSave") && ($("#rgSave").onclick = () => {
    TM.S.settings.rg.lossLimit = +$("#rgLoss").value;
    TM.S.settings.autoRebetStop = +$("#rgAuto").value;
    TM.S.settings.rg.sessionMin = +$("#rgSes").value;
    TM.S.settings.rg.depDay = +$("#rgDay").value;
    TM.save(); TM.toast("Limits saved");
  });
  $("#rgEx60") && ($("#rgEx60").onclick = () => { TM.S.settings.rg.excludeUntil = Date.now()+60000; TM.save(); TM.toast("Excluded for 60s"); });
  $("#rgPerm") && ($("#rgPerm").onclick = () => { TM.S.settings.rg.excludePerm = true; TM.save(); TM.toast("Permanent exclusion set"); });
  $("#axGo") && ($("#axGo").onclick = () => {
    TM.S.settings.a11y = { hc:$("#axHC").checked, reduce:$("#axRM").checked, hints:$("#axHint").checked, scale:+$("#axSc").value, cv:$("#axCV").value };
    TM.save(); TM.applyTheme(); TM.toast("Accessibility applied");
  });
  $("#prSave") && ($("#prSave").onclick = () => {
    TM.S.settings.presets.unshift({ name: $("#prName").value||"Preset", kind:"coin", stake:+$("#prStake").value });
    TM.S.settings.presets = TM.S.settings.presets.slice(0,20); TM.save(); render();
  });
  $$("[data-pr]").forEach(b => b.onclick = () => {
    const p = TM.S.settings.presets[+b.dataset.pr];
    go("play"); setTimeout(()=>{ const st=$("#stake"); if(st) st.value=p.stake; TM.toast("Preset filled · confirm to post"); }, 0);
  });
  $$("[data-prd]").forEach(b => b.onclick = () => { TM.S.settings.presets.splice(+b.dataset.prd,1); TM.save(); render(); });
  $("#histEx") && ($("#histEx").onclick = () => {
    const blob = new Blob([JSON.stringify(TM.S.games,null,2)], {type:"application/json"});
    const a = document.createElement("a"); a.href=URL.createObjectURL(blob); a.download="tossmatch-history.json"; a.click();
  });
}

async function postCoin(priv) {
  const side = $("#sideSeg .on")?.dataset.side || "HEADS";
  const stake = +$("#stake").value;
  const taunt = $("#taunt").value;
  const r = await TM.postCoin({ side, stake, priv, taunt });
  if (r.err) return TM.toast(r.err,"bad");
  TM.toast(priv ? "Private bet posted" : "Public bet posted");
  TM.sound("flip");
  const coin = $("#coin3d");
  if (coin && !priv && !TM.S.settings.instant) {
    coin.style.setProperty("--end", side === "TAILS" ? "1260deg" : "1080deg");
    coin.classList.remove("spin");
    void coin.offsetWidth;
    coin.classList.add("spin");
    setTimeout(() => render(), 1200);
  } else {
    render();
  }
}

async function postCat() {
  const g = TM.catalogById(route.sub);
  let pick = "";
  if (g.pick.type==="number") pick = +$("#cPick").value;
  else if (g.pick.type!=="none") pick = $("#cPicks .on")?.dataset.pick || g.pick.list[0];
  const r = await TM.postCatalog({ gameId: g.id, pick, stake: +$("#cStake").value });
  TM.toast(r.err || "Posted to waiting room", r.err?"bad":"");
  render();
}

async function playArc() {
  const id = route.sub;
  const opts = { stake: +($("#arStake")?.value || 50) };
  if (id==="dice") opts.mode = $("#diceMode .on")?.dataset.mode;
  if (id==="scratch") opts.stake = +($("#scTier .on")?.dataset.st || 25);
  if (id==="keno") opts.picks = $$("#kenoBoard .on").map(b=>+b.dataset.k);
  if (id==="treasure") opts.tile = +($(".pick.on")?.dataset.tile || 1);
  if (id==="dropball") opts.col = +$("#dbCol").value;
  if (id==="tower") opts.floor = +($("#twF .on")?.dataset.fl || 3);
  if (id==="penalty") opts.dir = $("#penD .on")?.dataset.dir;
  if (id==="vault") opts.key = +($("[data-key].on")?.dataset.key || 1);
  if (id==="fishing") opts.bait = $("#bait .on")?.dataset.bait;
  if (id==="ladder") opts.rung = +$("#ladR").value;
  if (id==="trivia") {
    const q = TM.TRIVIA[Math.floor(Math.random()*TM.TRIVIA.length)];
    const choice = prompt(q.q+"\n"+q.a.map((x,i)=>i+") "+x).join("\n"), "0");
    opts.choice = +choice; opts.stake = 20;
  }
  const r = await TM.playArcade(id, opts);
  TM.toast(r.err || r.rec.detail, r.err?"bad":"");
  render();
}

function openPalette() {
  if (paletteOn) { $("#palette")?.remove(); paletteOn=false; return; }
  paletteOn = true;
  const box = document.createElement("div");
  box.className = "palette"; box.id = "palette";
  const entries = [
    ...TM.NAV.flatMap(g=>g.items).map(it=>({name:it.name, dest:it.id, sub:"", info:g.g})),
    ...TM.CATALOG.map(g=>({name:g.name, dest:"games", sub:g.id, info:g.code})),
    ...TM.ARCADE.map(g=>({name:g.name, dest:"arcade", sub:g.id, info:g.code}))
  ];
  box.innerHTML = `<input id="palQ" placeholder="Jump anywhere · ${entries.length} destinations" autofocus><div id="palHits"></div>`;
  document.body.appendChild(box);
  const draw = () => {
    const q = $("#palQ").value.toLowerCase();
    const hits = entries.filter(e => (e.name+e.info+e.dest).toLowerCase().includes(q)).slice(0,12);
    $("#palHits").innerHTML = hits.map((e,i)=>`<button class="hit ${i===0?"on":""}" data-d="${e.dest}" data-s="${e.sub}"><span>${TM.esc(e.name)}</span><span class="disclaimer">${TM.esc(e.info)}</span></button>`).join("");
    $$("#palHits .hit").forEach(b => b.onclick = () => { openPalette(); go(b.dataset.d, b.dataset.s); });
  };
  $("#palQ").oninput = draw;
  $("#palQ").onkeydown = e => {
    if (e.key==="Enter") { const h=$("#palHits .hit.on")||$("#palHits .hit"); if(h){ openPalette(); go(h.dataset.d,h.dataset.s);} }
    if (e.key==="Escape") openPalette();
  };
  draw();
}

function bootPlayer() {
  TM.load();
  TM.bootBankrolls();
  TM.loginTick();
  TM.applyTheme();
  if ("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(()=>{});
  parseHash();
  render();
  window.addEventListener("hashchange", () => { parseHash(); render(); });
  document.addEventListener("click", e => {
    const el = e.target.closest("[data-go]");
    if (!el || el.closest("#palette")) return;
    e.preventDefault();
    go(el.dataset.go, el.dataset.sub || "");
  });
  $("#navSearch").addEventListener("input", () => { renderChrome(); });
  $("#turboSel").addEventListener("change", e => { TM.S.settings.turbo = +e.target.value; TM.save(); TM.toast("Turbo "+e.target.value+"×"); });
  document.addEventListener("click", e => {
    const b = e.target.closest("[data-go]");
    if (b && e.currentTarget) { /* handled in bind */ }
  });
  document.addEventListener("keydown", e => {
    if ((e.metaKey||e.ctrlKey) && e.key.toLowerCase()==="k") { e.preventDefault(); openPalette(); }
    if (e.key==="/" && document.activeElement.tagName!=="INPUT" && document.activeElement.tagName!=="TEXTAREA") { e.preventDefault(); openPalette(); }
    if (e.key==="Escape") { $("#palette")?.remove(); paletteOn=false; }
  });
  setInterval(() => TM.botTick().then(() => {
    if (document.hidden) return;
    if (["home","lobby","play","games","series"].includes(route.tab)) render();
    else renderChrome();
  }), 1000);
  setInterval(() => {
    const s = TM.S;
    if (Date.now() - s.session.lastReality > (s.settings.rg.realityMin||5)*60000) {
      s.session.lastReality = Date.now();
      TM.toast("Reality check · session net "+TM.delta(s.session.net));
    }
    if (s.settings.autoRebet && route.tab==="play" && !s.waiting.some(w=>w.owner==="player") && s.session.net > s.settings.autoRebetStop) {
      postCoin(false);
    }
  }, 30000);
}

document.addEventListener("DOMContentLoaded", bootPlayer);
