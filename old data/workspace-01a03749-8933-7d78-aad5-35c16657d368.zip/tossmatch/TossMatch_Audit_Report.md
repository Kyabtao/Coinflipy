# TossMatch v10.8 — Project Audit Report

**Audit date:** 25 August 2026  
**Audit status:** **PASS WITH WARNINGS**  
**Release:** Bot Starting Wallet  
**Target:** Local play-coin demonstration

---

## 1. Executive conclusion

TossMatch v10.8 passes the scoped bot-wallet initialization, one-time migration, starting-bonus accounting, first-top-up allocation, promotion-paused, eligibility, cross-tab regression, syntax, documentation and delivery checks.

The selected behavior is implemented exactly:

- Every bot starts at **0 MAIN**.
- Every bot receives exactly **1,000 BONUS** in a separate `bonusBalance`.
- The required first top-up still occurs before play.
- Its varied 400–1,600 base credits MAIN only.
- Its optional +50% first-top-up promotion credits BONUS only.
- Existing saved bots migrate once through `walletVersion=2`.
- Auto-created and Admin-created bots use the same starting wallet.
- Player bot profiles and Admin show MAIN, BONUS and total wallet separately.
- Analytics/history/CSV separate starting BONUS from first-promo BONUS.

Starting BONUS and first-promo BONUS are demo taps plus promotion cost. MAIN top-ups are demo taps. No bot wallet credit is a human deposit, payment or house revenue.

Unchanged inventory: **33 Catalog, 20 Arcade+, 53 exact games, 72 Player commands, 19 Player screens, 12 Admin screens, 8 VIP tiers, 49 achievements, 134 shop items and 101 Feature Directory records (90 Implemented / 3 Partial / 8 Suggested).**

### Scorecard

| Area | Result |
|---|---:|
| All 99 runtime seed MAIN balances | PASS — 0 |
| Fresh bot starting BONUS | PASS — 1,000 |
| Auto-created bot wallet | PASS — 0 MAIN / 1,000 BONUS |
| Admin-created bot wallet | PASS — 0 MAIN / 1,000 BONUS |
| Existing bot one-time migration | PASS |
| Migration does not repeat | PASS |
| Starting BONUS accounting once | PASS |
| First top-up base → MAIN | PASS |
| First promotion → BONUS | PASS |
| Paused promotion retains 1,000 BONUS | PASS |
| Required-first-top-up-before-play regression | PASS |
| Live Admin leader/failover regression | PASS |
| Player/Admin JavaScript syntax | PASS |
| Player tabs/panels | PASS — 19 / 19 |
| Admin tabs/panels | PASS — 12 / 12 |
| Specification/runtime registries | PASS — 33 / 20 / 8 / 49 / 134 / 101 |
| DOCX integrity/open | PASS — 687 paragraphs / 130 tables / 2 sections |
| Exact HTTP delivery | PASS |
| Production readiness | WARNING |

---

## 2. Build fingerprints

| File | Size | SHA-256 |
|---|---:|---|
| `index.html` | 459,027 bytes | `b810956c441c29e4d29977593c4dbf2a1f2261ae050e3ff6cccf7b10af5f5d25` |
| `admin.html` | 161,423 bytes | `f98c555dd76b1545c876d2649edd468ceb80d2bb19c11fb3cd2b81ac75f19011` |
| `TossMatch_Project_Documentation.docx` | 134,508 bytes | `a7e6445cac23e1dc0172596a8e52ad01490413f99cdb9ab4066347d17d30b83d` |
| `TossMatch_Complete_Feature_and_Rules_Specification.md` | 66,646 bytes | `00710665f6ec54db936f5bc9f5636b9ede10e1d1446a6202e364426993245c71` |
| `TossMatch_Feature_Register.md` | 35,501 bytes | `9b50a030f0607aa72119d02b92366fd06d2894788dbc248fae36b35d270fe6b2` |
| `TossMatch_Cons_and_Roadmap.md` | 16,515 bytes | `9ecad7dbdfc865e15db5bad3f94fb7fe949c9e654e4668ac60ea82e7726aa14d` |
| `CHANGELOG.md` | 20,065 bytes | `0ec0024b81dfa364dfaf21aa9e702f9b1ae98db6c738bfd47bf9980d7e53e866` |
| `sw.js` | 841 bytes | `7b2a7956cebc0c019b53af9393a889d73a9b608cb6ff71c1961adcce1aef708b` |

---

## 3. Static verification

### Player

- Version: **10.8**
- Static IDs: **170**
- Duplicate IDs: **0**
- Unique literal `$()` references: **237**
- Missing referenced IDs: **0**
- Tabs/panels: **19 / 19**
- CSS braces: **652 / 652**
- Closing HTML tags: **1**

### Admin

- Version: **10.8**
- Static IDs: **248**
- Duplicate IDs: **0**
- Unique literal `$()` references: **184**
- Missing referenced IDs: **0**
- Tabs/panels: **12 / 12**
- CSS braces: **299 / 299**
- Closing HTML tags: **1**

### Support

- Manifest/OpenAPI parse: PASS.
- Service-worker cache: **`tossmatch-v10.8`**.

---

## 4. Source roster verification

The full runtime `BOTS_SEED` was evaluated after procedural generation:

- Runtime bots: **99**.
- Bots with nonzero source MAIN: **0**.
- Hand-authored `balance` values: all 0.
- Procedural generation `balance`: 0.

Fresh default state adds these wallet fields to every bot:

| Field | Initial value |
|---|---:|
| `balance` | 0 MAIN |
| `bonusBalance` | 1,000 BONUS |
| `walletVersion` | 2 |
| `startingBonus` | 1,000 |
| `startingBonusAccounted` | false until engine accounting |
| `firstTopupDone` | false |

---

## 5. One-time migration verification

A synthetic legacy bot began with 9,000 MAIN, no wallet version and prior first-top-up state.

First `initializeBotStartingWallet` pass verified:

- MAIN reset to 0.
- BONUS set to 1,000.
- `walletVersion=2`.
- First-top-up state reset to pending.
- Previous top-up counters/base reset for the new model.

After changing the migrated bot to 777 MAIN / 1,222 BONUS, a second initializer pass preserved both values. This proves migration is one-time rather than a per-load reset.

---

## 6. Credit allocation verification

### Promotion enabled

Starting state: 0 MAIN / 1,000 BONUS.

After required first top-up:

- MAIN equals the varied base and remains within 400–1,600.
- BONUS equals 1,000 plus rounded 50% of the base.
- `startingBonusAccounted=true`.
- Taps equal starting bonus + base + first promo.
- Promotion cost equals starting bonus + first promo.
- Record `walletCredit` equals base + starting bonus + first promo.
- Required/pre-play flags remain true.

### Promotion paused

Verified:

- MAIN receives the varied required base.
- BONUS remains exactly 1,000.
- First-promo field is 0.
- Bot still becomes eligible before play.

Calling starting-bonus accounting again created no additional tap or promotion cost.

---

## 7. Creation-path verification

| Bot path | v10.8 initialization |
|---|---|
| Default seeded bot | 0 MAIN + 1,000 BONUS |
| Procedural seed bot | 0 MAIN + 1,000 BONUS |
| Existing/imported bot | One-time migration to 0 MAIN + 1,000 BONUS |
| Auto-created bot | 0 MAIN + 1,000 BONUS, then immediate required first MAIN top-up |
| Admin-created bot | 0 MAIN + 1,000 BONUS, then next live engine pulse completes first MAIN top-up |

The v10.7 first-top-up gate remains in front of all game/activity paths.

---

## 8. Player and Admin verification

### Player bot profile

Verified separate cards for:

- MAIN balance
- BONUS balance
- Total wallet

Profile text states the 0 MAIN / 1,000 BONUS starting model.

### Admin Live Operations

Verified cards for:

- First top-up complete
- Blocked before play
- All bot top-ups
- Aggregate bot MAIN balance
- Aggregate bot BONUS balance

### Top-up Analytics and exports

Verified:

- Starting bonus and first-promo totals are separate.
- Complete wallet credit includes base + starting bonus + first promo.
- Recent bot rows label MAIN, starting BONUS and promo BONUS separately.
- Bot history includes MAIN top-up, Starting BONUS, Promo BONUS, Wallet credit and Reason.
- CSV contains separate Starting bonus, First promo, Campaign bonus, Total bonus and Credited columns.

---

## 9. Accounting boundary

| Credit | Accounting |
|---|---|
| Starting 1,000 BONUS | Tap + promotion cost |
| Required first MAIN base | Tap |
| Optional first-promo BONUS | Tap + promotion cost |
| Later MAIN top-up | Tap |
| House revenue | Never |

The initial roster creates a one-time 99,000 BONUS tap before first-promo values. This is intentional for the requested demo wallet model and must remain excluded from human deposits/revenue.

---

## 10. Registry and documentation verification

Runtime extraction matched the v10.8 specification:

- 33 Catalog
- 20 Arcade+
- 8 VIP
- 49 achievements
- 134 shop items
- 101 Feature Directory records
- Status 90 / 3 / 8

Updated WAL-2 and WAL-4 descriptions match Admin runtime data. DOCX metadata/map are current and Appendix Z is the controlling v10.8 delta.

---

## 11. Production warnings

The bot wallets remain mutable browser state. Production requires server-authoritative segmented wallets, explicit BONUS spending rules, idempotent migration/onboarding, budget controls, reconciliation, bot/human analytics separation and audited liquidity classification.

---

## 12. Release recommendation

### Local demo

**Approved.** Every bot begins with 0 MAIN and exactly 1,000 BONUS, then completes its required first MAIN top-up before play.

### Production / real-value use

**Not approved** until local wallets and accounting are replaced by authoritative backend services.

---

**Final result: PASS WITH WARNINGS for TossMatch v10.8 local demo.**
